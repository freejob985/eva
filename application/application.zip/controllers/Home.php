<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array( 
            'website/about_model',
            'website/home_model',
            'website/department_model',
            'website/testimonial_model',
            'website/appointment_instruction_model',
            'website/partner_model',
            'website/doctor_model',
            'website/news_model',
            'website/menu_model'
        ));  
    }  
  
    public function index()
    {


        $data['title'] = display('home'); 
        #-----------Setting-------------# 
        $data['setting'] = $this->home_model->setting(); 
        // redirect if website status is disabled
        if ($data['setting']->status == 0) 
            redirect(base_url('login'));
        $data['basics'] = $this->home_model->basic_setting();  
        #-----------Section-------------# 
        $sections = $this->home_model->sections();
        $dataSection = array();
        if(!empty($sections)):
            foreach ($sections as $section) {
                $dataSection[$section->name] = array(
                    'name'            => $section->name,
                    'title'           => $section->title,
                    'description'     => $section->description
                );
            }
        endif; 
        $data['section'] = $dataSection;

       #--------get all home data---------#
       $data['languageList'] = $this->home_model->languageList(); 
       $data['parent_menu'] = $this->menu_model->get_parent_menu();
       $data['about'] = $this->about_model->read();
       $data['sliders'] = $this->home_model->get_sliders();
       $data['departments'] = $this->department_model->read();
       $data['deptsFooter'] = $this->department_model->read_footer();
       $data['sliderDepart'] = $this->department_model->read_home_slider();
       $data['department_list'] = $this->department_model->department_list();
       $data['testimonial'] = $this->testimonial_model->read_active();
       $data['instruction'] = $this->appointment_instruction_model->read_active_instuction();
       $data['partners'] = $this->partner_model->read_active();
       $data['doctors'] = $this->doctor_model->read_home();  
       $data['latest_news'] = $this->news_model->read_news();
       #-----------------------------------#

       $data['content'] = $this->load->view('website/includes/home',$data,true);
       $this->load->view('website/index', $data);
    }

// =================================================================================================

//   public function submit_appointment() {
//         // Set validation rules
//         $this->form_validation->set_rules('branch', 'الفرع', 'required');
//         $this->form_validation->set_rules('service', 'الخدمة', 'required');
//         $this->form_validation->set_rules('doctor', 'الطبيب', 'required');
//         $this->form_validation->set_rules('appointment_time', 'وقت الموعد', 'required');
//         $this->form_validation->set_rules('fullName', 'الاسم الكامل', 'required');
//         $this->form_validation->set_rules('phone', 'الهاتف', 'required');
//         $this->form_validation->set_rules('email', 'البريد الإلكتروني', 'required|valid_email');
//         $this->form_validation->set_rules('birthday', 'عيد الميلاد', 'required');
//         $this->form_validation->set_rules('payment', 'طريقة الدفع', 'required');

//         if ($this->form_validation->run() == FALSE) {
//             // Validation failed, return to form with errors
//             $this->load->view('appointment_form');
//         } else {
//             // Validation passed, process the form data
//             $appointment_data = array(
//                 'appointment_id' => uniqid(), // Generate a unique ID
//                 'patient_id' => $this->session->userdata('user_id') ?? null, // Assuming you have user sessions
//                 'department_id' => null, // You may need to add this field to your form
//                 'doctor_id' => $this->input->post('doctor'),
//                 'schedule_id' => null, // You may need to generate this based on the selected time
//                 'serial_no' => null, // You may need to generate this
//                 'date' => date('Y-m-d', strtotime($this->input->post('appointment_time'))),
//                 'problem' => $this->input->post('notes'),
//                 'created_by' => $this->session->userdata('user_id') ?? 1, // Assuming you have user sessions
//                 'create_date' => date('Y-m-d H:i:s'),
//                 'status' => 'pending',
//                 'branch_id' => $this->input->post('branch'),
//                 'service_id' => $this->input->post('service'),
//                 'appointment_time' => $this->input->post('appointment_time'),
//                 'patient_name' => $this->input->post('fullName'),
//                 'phone' => $this->input->post('phone'),
//                 'email' => $this->input->post('email'),
//                 'birthday' => $this->input->post('birthday'),
//                 'payment_method' => $this->input->post('payment')
//             );

//             // Insert the appointment using Query Builder
//             $this->db->insert('appointment', $appointment_data);
//             $insert_id = $this->db->insert_id();

//             if ($insert_id) {
//                 // Successful insertion, redirect to home page
//                 $this->session->set_flashdata('success', 'تم حجز الموعد بنجاح.');
//                 redirect('home');
//             } else {
//                 // Failed insertion
//                 $this->session->set_flashdata('error', 'فشل في حجز الموعد. يرجى المحاولة مرة أخرى.');
//                 $this->load->view('appointment_form');
//             }
//         }
//     }

public function submit_appointment() {
    // Set validation rules
    $this->form_validation->set_rules('branch', 'الفرع', 'required');
    $this->form_validation->set_rules('service', 'الخدمة', 'required');
    $this->form_validation->set_rules('doctor', 'الطبيب', 'required');
    $this->form_validation->set_rules('appointment_time', 'وقت الموعد', 'required');
    $this->form_validation->set_rules('fullName', 'الاسم الكامل', 'required');
    $this->form_validation->set_rules('phone', 'الهاتف', 'required');
    $this->form_validation->set_rules('email', 'البريد الإلكتروني', 'required|valid_email');
    $this->form_validation->set_rules('birthday', 'عيد الميلاد', 'required');
    $this->form_validation->set_rules('payment', 'طريقة الدفع', 'required');

    if ($this->form_validation->run() == FALSE) {
        // Validation failed, return to form with errors
        $this->load->view('website/index');
    } else {
        // Prepare patient data
        $postPatient = array(
            'patient_id' => uniqid('P'), // Generate a unique patient ID
            'firstname' => explode(' ', $this->input->post('fullName'))[0],
            'lastname' => explode(' ', $this->input->post('fullName'), 2)[1] ?? '',
            'mobile' => $this->input->post('phone'),
            'email' => $this->input->post('email'),
            'birthday' => $this->input->post('birthday'),
            'create_date' => date('Y-m-d'),
            'created_by' => $this->session->userdata('user_id') ?? 1,
            'status' => 1
        );

        // Insert patient data
        if ($this->patient_model->create($postPatient)) {
            // Prepare appointment data
            $appointment_data = array(
                'appointment_id' => uniqid(), // Generate a unique ID
                'patient_id' => $postPatient['patient_id'],
                'doctor_id' => $this->input->post('doctor'),
                'schedule_id' => $this->generate_schedule_id($this->input->post('appointment_time'), $this->input->post('doctor')), // Generate schedule_id based on selected time and doctor
                'serial_no' => $this->generate_serial_no($this->input->post('appointment_time'), $this->input->post('doctor')), // Generate serial number
                'date' => date('Y-m-d', strtotime($this->input->post('appointment_time'))),
                'problem' => $this->input->post('notes'),
                'created_by' => $this->session->userdata('user_id') ?? 1,
                'create_date' => date('Y-m-d H:i:s'),
                'status' => 'pending',
                'branch_id' => $this->input->post('branch'),
                'service_id' => $this->input->post('service'),
                'appointment_time' => $this->input->post('appointment_time'),
                'payment_method' => $this->input->post('payment')
            );

            // Check if the appointment already exists
            $appointment_exists = $this->check_appointment_exists($appointment_data['doctor_id'], $appointment_data['schedule_id'], $appointment_data['date']);
            if ($appointment_exists) {
                $this->session->set_flashdata('error', 'تم حجز هذا الموعد مسبقًا.');
                $this->load->view('website/index');
                return;
            }

            // Insert the appointment using Query Builder
            $this->db->insert('appointment', $appointment_data);
            $insert_id = $this->db->insert_id();

            if ($insert_id) {
                // Successful insertion, send confirmation SMS
                // $this->send_confirmation_sms($appointment_data);

                // Set success message and redirect to home page
                $this->session->set_flashdata('success', 'تم حجز الموعد بنجاح.');
                redirect('home');
            } else {
                // Failed insertion
                $this->session->set_flashdata('error', 'فشل في حجز الموعد. يرجى المحاولة مرة أخرى.');
                $this->load->view('website/index');
            }
        } else {
            // Failed to create patient
            $this->session->set_flashdata('error', 'فشل في إضافة بيانات المريض. يرجى المحاولة مرة أخرى.');
            $this->load->view('website/index');
        }
    }
}

private function generate_schedule_id($appointment_time, $doctor_id) {
    // Generate a unique schedule ID based on appointment time and doctor
    return md5($appointment_time . $doctor_id);
}

private function generate_serial_no($appointment_time, $doctor_id) {
    // Generate a serial number based on appointment time and doctor
    return substr(md5($appointment_time . $doctor_id), 0, 10);
}

private function check_appointment_exists($doctor_id, $schedule_id, $date) {
    // Check if an appointment already exists for the given doctor, schedule, and date
    $query = $this->db->get_where('appointment', array(
        'doctor_id' => $doctor_id,
        'schedule_id' => $schedule_id,
        'date' => $date
    ));
    return $query->num_rows() > 0;
}

private function send_confirmation_sms($appointment_data) {
    // Load SMS gateway settings
    $gateway = $this->db->select('*')->from('sms_gateway')->where('default_status', 1)->get()->row();

    if ($gateway) {
        $this->load->library('smsgateway');

        // Create SMS template
        $message = "تم حجز موعدك بنجاح مع د. " . $appointment_data['doctor_id'] . " في " . $appointment_data['appointment_time'];

        // Send SMS
        $this->smsgateway->send([
            'apiProvider' => $gateway->provider_name,
            'username' => $gateway->user,
            'password' => $gateway->password,
            'from' => $gateway->authentication,
            'to' => $appointment_data['phone'],
            'message' => $message
        ]);

        // Log SMS info
        $this->db->insert('sms_info', array(
            'doctor_id' => $appointment_data['doctor_id'],
            'patient_id' => $appointment_data['patient_id'],
            'phone_no' => $appointment_data['phone'],
            'appointment_id' => $appointment_data['appointment_id'],
            'appointment_date' => $appointment_data['date'],
            'status' => 0,
            'sms_counter' => 0
        ));
    }
}

// ===============================================================================================
    public function testx()
    {
        $data['title'] = display('home'); 
        #-----------Setting-------------# 
        $data['setting'] = $this->home_model->setting(); 
        // redirect if website status is disabled
        if ($data['setting']->status == 0) 
            redirect(base_url('login'));
        $data['basics'] = $this->home_model->basic_setting();  
        #-----------Section-------------# 
        $sections = $this->home_model->sections();
        $dataSection = array();
        if(!empty($sections)):
            foreach ($sections as $section) {
                $dataSection[$section->name] = array(
                    'name'            => $section->name,
                    'title'           => $section->title,
                    'description'     => $section->description
                );
            }
        endif; 
        $data['section'] = $dataSection;

       #--------get all home data---------#
       $data['languageList'] = $this->home_model->languageList(); 
       $data['parent_menu'] = $this->menu_model->get_parent_menu();
       $data['about'] = $this->about_model->read();
       $data['sliders'] = $this->home_model->get_sliders();
       $data['departments'] = $this->department_model->read();
       $data['deptsFooter'] = $this->department_model->read_footer();
       $data['sliderDepart'] = $this->department_model->read_home_slider();
       $data['department_list'] = $this->department_model->department_list();
       $data['testimonial'] = $this->testimonial_model->read_active();
       $data['instruction'] = $this->appointment_instruction_model->read_active_instuction();
       $data['partners'] = $this->partner_model->read_active();
       $data['doctors'] = $this->doctor_model->read_home();  
       $data['latest_news'] = $this->news_model->read_news();
       #-----------------------------------#

       $data['content'] = $this->load->view('website/includes/home',$data,true);
       $this->load->view('website/index', $data);
    }


    public function sub_menu($id=null){
      return $this->db->select("ws_menu.id, content.url, ws_menu.name, ws_menu.parent_id")
                      ->from('ws_page_content as content')
                      ->join('ws_menu', 'ws_menu.id=content.menu_id', 'left')
                      ->where('ws_menu.status', 1)
                      ->where('ws_menu.parent_id', $id)
                      ->order_by('ws_menu.position','asc')
                      ->get()
                      ->result();
    }


    public function chane_language(){

      $language = $this->input->post('userLang');
          $cookie = array(
              'name'   => 'Lng',
              'value'  => $language,
              'expire' => 31536000,
              'domain' => ''
          );
          $this->input->set_cookie($cookie);
    }

    public function deleteCookie(){
          delete_cookie('Lng');
    }


}
