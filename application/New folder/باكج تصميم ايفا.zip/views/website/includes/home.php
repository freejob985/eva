<div class="content-wrapper">
        <!-- slider -->
        <?php @$this->load->view('website/includes/slider');?>
        <!-- /.End of slider -->
        
        <!-- Service Section -->
        <?php @$this->load->view('website/includes/service');?>
        <!-- /Service Section -->
    </div>
    <!-- about -->
    <?php @$this->load->view('website/includes/about');?>
    <!-- /.about us -->

    <?php @$this->load->view('website/includes/department');?>
    <!-- /.department -->
    
    <?php @$this->load->view('website/includes/testimonial');?>
    <!-- /.testimonial -->
    
    <?php @$this->load->view('website/includes/appointment');?>
    <!-- /.appointment content -->
    
    <?php @$this->load->view('website/includes/partner');?>
    <!-- /.partners -->
    
    <?php @$this->load->view('website/includes/doctor');?>
    <!-- /.doctor list -->
    
    <?php @$this->load->view('website/includes/news');?>
    <!-- /.blog -->