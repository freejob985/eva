             <div class="top_bar_left clearfix">
                           <div class="logo"><a id="logo" href="https://evaclinics.com.sa/" title="EVA"
                              data-height="105" data-padding="14"><img class="logo-main scale-with-grid "
                              src="assets_web/EVA_files/eva2.png"
                              data-retina="https://ninjawarriorarabia.com/wp-content/uploads/2024/07/eva2.png#240"
                              data-height="230" alt="eva2" data-no-retina=""><img
                              class="logo-sticky scale-with-grid " src="assets_web/EVA_files/eva2.png"
                              data-retina="https://ninjawarriorarabia.com/wp-content/uploads/2024/07/eva2.png#240"
                              data-height="230" alt="eva2" data-no-retina=""><img
                              class="logo-mobile scale-with-grid " src="assets_web/EVA_files/eva2.png"
                              data-retina="https://ninjawarriorarabia.com/wp-content/uploads/2024/07/eva2.png#240"
                              data-height="230" alt="eva2" data-no-retina=""><img
                              class="logo-mobile-sticky scale-with-grid "
                              src="assets_web/EVA_files/eva2.png"
                              data-retina="https://ninjawarriorarabia.com/wp-content/uploads/2024/07/eva2.png#240"
                              data-height="230" alt="eva2" data-no-retina=""></a></div>
                           <div class="menu_wrapper">
                              <a class="responsive-menu-toggle " href="https://evaclinics.com.sa/#"
                                 aria-label="mobile menu"><i class="icon-menu-fine" aria-hidden="true"></i></a>
                              <nav id="menu" role="navigation" aria-expanded="false" aria-label="Main menu">
                                 <ul id="menu-main-menu" class="menu menu-main">
                                    <li id="menu-item-7"
                                       class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item">
                                       <a href="https://evaclinics.com.sa/"><span>الرئيسية</span></a>
                                    </li>
                                    <li id="menu-item-21"
                                       class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                       href="https://evaclinics.com.sa/about-us/"><span>عن ايفا</span></a>
                                    </li>
                                    <li id="menu-item-294"
                                       class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children submenu">
                                       <a href="https://evaclinics.com.sa/#"><span>الاقسام و الخدمات</span></a>
                                       <ul class="sub-menu">
                                          <li id="menu-item-293"
                                             class="menu-item menu-item-type-post_type menu-item-object-page">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%ac%d9%84%d8%af%d9%8a%d8%a9-%d9%88%d8%a7%d9%84%d8%aa%d8%ac%d9%85%d9%8a%d9%84/"><span>الجلدية
                                             والتجميل</span></a>
                                          </li>
                                          <li id="menu-item-295"
                                             class="menu-item menu-item-type-post_type menu-item-object-page">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%a7%d9%84%d9%84%d9%8a%d8%b2%d8%b1/"><span>الليزر</span></a>
                                          </li>
                                          <li id="menu-item-296"
                                             class="menu-item menu-item-type-post_type menu-item-object-page">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%ac%d8%b1%d8%a7%d8%ad%d8%a7%d8%aa-%d8%a7%d9%84%d8%aa%d8%ac%d9%85%d9%8a%d9%84/"><span>جراحات
                                             التجميل ( قريبا )</span></a>
                                          </li>
                                          <li id="menu-item-297"
                                             class="menu-item menu-item-type-post_type menu-item-object-page">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%b2%d8%b1%d8%a7%d8%b9%d8%a7%d8%aa-%d8%a7%d9%84%d8%b4%d8%b9%d8%b1/"><span>زراعات
                                             الشعر ( قريبا )</span></a>
                                          </li>
                                          <li id="menu-item-298"
                                             class="menu-item menu-item-type-post_type menu-item-object-page last-item">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%b7%d8%a8-%d9%88%d8%aa%d9%82%d9%88%d9%8a%d9%85-%d8%a7%d9%84%d8%a3%d8%b3%d9%86%d8%a7%d9%86/"><span>طب
                                             وتقويم الأسنان</span></a>
                                          </li>
                                       </ul>
                                       <a class="menu-toggle" href="https://evaclinics.com.sa/#" role="link"
                                          aria-label="Toggle submenu"></a>
                                    </li>
                                    <li id="menu-item-219"
                                       class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children submenu">
                                       <a
                                          href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%a3%d8%b7%d8%a8%d8%a7%d8%a1/"><span>الأطباء</span></a>
                                       <ul class="sub-menu">
                                          <li id="menu-item-352"
                                             class="menu-item menu-item-type-post_type menu-item-object-page last-item">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%a3%d9%86%d8%b6%d9%85%d8%a7%d9%85-%d9%84%d9%81%d8%b1%d9%8a%d9%82-%d8%a7%d9%84%d8%b9%d9%85%d9%84/"><span>الأنضمام
                                             لفريق العمل</span></a>
                                          </li>
                                       </ul>
                                       <a class="menu-toggle" href="https://evaclinics.com.sa/#" role="link"
                                          aria-label="Toggle submenu"></a>
                                    </li>
                                    <li id="menu-item-18"
                                       class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                       href="https://evaclinics.com.sa/%d8%a7%d9%84%d9%81%d8%b1%d9%88%d8%b9-2/"><span>الفروع</span></a>
                                    </li>
                                    <li id="menu-item-439"
                                       class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children submenu">
                                       <a href="https://evaclinics.com.sa/#"><span>العروض</span></a>
                                       <ul class="sub-menu">
                                          <li id="menu-item-229"
                                             class="menu-item menu-item-type-post_type menu-item-object-page">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%b9%d8%b1%d9%88%d9%88%d8%b6-%d8%a7%d9%84%d8%a8%d8%b4%d8%b1%d9%87-%d9%88-%d8%a7%d9%84%d9%84%d9%8a%d8%b2%d8%b1/"><span>عرووض
                                             البشره و الليزر</span></a>
                                          </li>
                                          <li id="menu-item-443"
                                             class="menu-item menu-item-type-post_type menu-item-object-page last-item">
                                             <a
                                                href="https://evaclinics.com.sa/%d8%b9%d8%b1%d9%88%d9%88%d8%b6-%d8%a7%d9%84%d8%a7%d8%b3%d9%86%d8%a7%d9%86/"><span>عرووض
                                             الاسنان</span></a>
                                          </li>
                                       </ul>
                                       <a class="menu-toggle" href="https://evaclinics.com.sa/#" role="link"
                                          aria-label="Toggle submenu"></a>
                                    </li>
                                    <li id="menu-item-235"
                                       class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                       href="https://evaclinics.com.sa/%d8%b4%d8%b1%d9%83%d8%a7%d8%a1-%d8%a7%d9%84%d9%86%d8%ac%d8%a7%d8%ad/"><span>شركاء
                                       النجاح</span></a>
                                    </li>
                                    <li id="menu-item-497"
                                       class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                       href="https://evaclinics.com.sa/%d8%a7%d9%84%d9%85%d8%af%d9%88%d9%86%d8%a9/"><span>المدونة</span></a>
                                    </li>
                                    <li id="menu-item-490"
                                       class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                       href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%ad%d8%ac%d8%b2/"><span>الحجز</span></a>
                                    </li>
                                    <li id="menu-item-238"
                                       class="menu-item menu-item-type-post_type menu-item-object-page last"><a
                                       href="https://evaclinics.com.sa/%d8%a7%d8%aa%d8%b5%d9%84-%d8%a8%d9%86%d8%a7/"><span>اتصل
                                       بنا</span></a>
                                    </li>
                                    <li id="menu-item-173"
                                       class="menu-item menu-item-type-post_type menu-item-object-page last"><a
                                       href="https://evaclinics.com.sa/%d8%aa%d8%b3%d8%ac%d9%8a%d9%84-%d8%a7%d9%84%d8%af%d8%ae%d9%88%d9%84/"><span>تسجيل
                                       الدخول</span></a>
                                    </li>
                                 </ul>
                              </nav>
                           </div>
                           <div class="secondary_menu_wrapper">
                           </div>
                        </div>