<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <link rel="alternate" hreflang="ar" href="https://evaclinics.com.sa/">
   <!-- Meta Pixel Code -->
   <script async="true" src="assets_web/EVA_files/fb3b512a-33f7-4474-98a1-a4ea4eb59d1c.js.download"
      crossorigin="anonymous"></script>
   <script type="text/javascript" async="" src="assets_web/EVA_files/identify_c2008b8c.js.download"></script>
   <script type="text/javascript" async="" src="assets_web/EVA_files/main.MWFhNzU2YTY5MQ.js.download"
      data-id="CQJR3BBC77UE89C5KTU0"></script>
   <script type="text/javascript" async="" src="assets_web/EVA_files/events.js.download"></script>
   <script async="" src="assets_web/EVA_files/scevent.min.js.download"></script>
   <script type="text/javascript" async="" src="assets_web/EVA_files/destination"></script>
   <script type="text/javascript" async="" src="assets_web/EVA_files/js"></script>
   <script async="" src="assets_web/EVA_files/gtm.js.download"></script>
   <script src="assets_web/EVA_files/712534031007060" async=""></script>
   <script src="assets_web/EVA_files/1200772941064074" async=""></script>
   <script async="" src="assets_web/EVA_files/fbevents.js.download"></script>
   <script>
      ! function (f, b, e, v, n, t, s) {
         if (f.fbq) return;
         n = f.fbq = function () {
            n.callMethod ?
               n.callMethod.apply(n, arguments) : n.queue.push(arguments)
         };
         if (!f._fbq) f._fbq = n;
         n.push = n;
         n.loaded = !0;
         n.version = '2.0';
         n.queue = [];
         t = b.createElement(e);
         t.async = !0;
         t.src = v;
         s = b.getElementsByTagName(e)[0];
         s.parentNode.insertBefore(t, s)
      }(window, document, 'script',
         'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '1200772941064074');
      fbq('track', 'PageView');
   </script>
   <noscript><img height="1" width="1" style="display:none"
         src="https://www.facebook.com/tr?id=1200772941064074&ev=PageView&noscript=1" /></noscript>
   <!-- End Meta Pixel Code -->
   <title>EVA</title>
   <meta name="robots" content="max-image-preview:large">
   <meta name="format-detection" content="telephone=no">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link rel="shortcut icon" href="https://ninjawarriorarabia.com/wp-content/uploads/2024/06/eva.png#100"
      type="image/x-icon">
   <meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)">
   <meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: dark)">
   <link rel="dns-prefetch" href="https://fonts.googleapis.com/">
   <link rel="alternate" type="application/rss+xml" title="EVA « الخلاصة" href="https://evaclinics.com.sa/feed/">
   <link rel="alternate" type="application/rss+xml" title="EVA « خلاصة التعليقات"
      href="https://evaclinics.com.sa/comments/feed/">
   <link rel="alternate" type="application/rss+xml" title="EVA « Home خلاصة التعليقات"
      href="https://evaclinics.com.sa/home/feed/">
   <style id="wp-emoji-styles-inline-css" type="text/css">
      img.wp-smiley,
      img.emoji {
         display: inline !important;
         border: none !important;
         box-shadow: none !important;
         height: 1em !important;
         width: 1em !important;
         margin: 0 0.07em !important;
         vertical-align: -0.1em !important;
         background: none !important;
         padding: 0 !important;
      }
   </style>
   <link rel="stylesheet" id="wp-block-library-rtl-css" href="assets_web/EVA_files/style-rtl.min.css" type="text/css"
      media="all">
   <style id="classic-theme-styles-inline-css" type="text/css">
      /*! This file is auto-generated */
      .wp-block-button__link {
         color: #fff;
         background-color: #32373c;
         border-radius: 9999px;
         box-shadow: none;
         text-decoration: none;
         padding: calc(.667em + 2px) calc(1.333em + 2px);
         font-size: 1.125em
      }

      .wp-block-file__button {
         background: #32373c;
         color: #fff;
         text-decoration: none
      }
   </style>
   <style id="global-styles-inline-css" type="text/css">
      :root {
         --wp--preset--aspect-ratio--square: 1;
         --wp--preset--aspect-ratio--4-3: 4/3;
         --wp--preset--aspect-ratio--3-4: 3/4;
         --wp--preset--aspect-ratio--3-2: 3/2;
         --wp--preset--aspect-ratio--2-3: 2/3;
         --wp--preset--aspect-ratio--16-9: 16/9;
         --wp--preset--aspect-ratio--9-16: 9/16;
         --wp--preset--color--black: #000000;
         --wp--preset--color--cyan-bluish-gray: #abb8c3;
         --wp--preset--color--white: #ffffff;
         --wp--preset--color--pale-pink: #f78da7;
         --wp--preset--color--vivid-red: #cf2e2e;
         --wp--preset--color--luminous-vivid-orange: #ff6900;
         --wp--preset--color--luminous-vivid-amber: #fcb900;
         --wp--preset--color--light-green-cyan: #7bdcb5;
         --wp--preset--color--vivid-green-cyan: #00d084;
         --wp--preset--color--pale-cyan-blue: #8ed1fc;
         --wp--preset--color--vivid-cyan-blue: #0693e3;
         --wp--preset--color--vivid-purple: #9b51e0;
         --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
         --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
         --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
         --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
         --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
         --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
         --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
         --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
         --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
         --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
         --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
         --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
         --wp--preset--font-size--small: 13px;
         --wp--preset--font-size--medium: 20px;
         --wp--preset--font-size--large: 36px;
         --wp--preset--font-size--x-large: 42px;
         --wp--preset--font-family--inter: "Inter", sans-serif;
         --wp--preset--font-family--cardo: Cardo;
         --wp--preset--spacing--20: 0.44rem;
         --wp--preset--spacing--30: 0.67rem;
         --wp--preset--spacing--40: 1rem;
         --wp--preset--spacing--50: 1.5rem;
         --wp--preset--spacing--60: 2.25rem;
         --wp--preset--spacing--70: 3.38rem;
         --wp--preset--spacing--80: 5.06rem;
         --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
         --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
         --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
         --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
         --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
      }

      :where(.is-layout-flex) {
         gap: 0.5em;
      }

      :where(.is-layout-grid) {
         gap: 0.5em;
      }

      body .is-layout-flex {
         display: flex;
      }

      .is-layout-flex {
         flex-wrap: wrap;
         align-items: center;
      }

      .is-layout-flex> :is(*, div) {
         margin: 0;
      }

      body .is-layout-grid {
         display: grid;
      }

      .is-layout-grid> :is(*, div) {
         margin: 0;
      }

      :where(.wp-block-columns.is-layout-flex) {
         gap: 2em;
      }

      :where(.wp-block-columns.is-layout-grid) {
         gap: 2em;
      }

      :where(.wp-block-post-template.is-layout-flex) {
         gap: 1.25em;
      }

      :where(.wp-block-post-template.is-layout-grid) {
         gap: 1.25em;
      }

      .has-black-color {
         color: var(--wp--preset--color--black) !important;
      }

      .has-cyan-bluish-gray-color {
         color: var(--wp--preset--color--cyan-bluish-gray) !important;
      }

      .has-white-color {
         color: var(--wp--preset--color--white) !important;
      }

      .has-pale-pink-color {
         color: var(--wp--preset--color--pale-pink) !important;
      }

      .has-vivid-red-color {
         color: var(--wp--preset--color--vivid-red) !important;
      }

      .has-luminous-vivid-orange-color {
         color: var(--wp--preset--color--luminous-vivid-orange) !important;
      }

      .has-luminous-vivid-amber-color {
         color: var(--wp--preset--color--luminous-vivid-amber) !important;
      }

      .has-light-green-cyan-color {
         color: var(--wp--preset--color--light-green-cyan) !important;
      }

      .has-vivid-green-cyan-color {
         color: var(--wp--preset--color--vivid-green-cyan) !important;
      }

      .has-pale-cyan-blue-color {
         color: var(--wp--preset--color--pale-cyan-blue) !important;
      }

      .has-vivid-cyan-blue-color {
         color: var(--wp--preset--color--vivid-cyan-blue) !important;
      }

      .has-vivid-purple-color {
         color: var(--wp--preset--color--vivid-purple) !important;
      }

      .has-black-background-color {
         background-color: var(--wp--preset--color--black) !important;
      }

      .has-cyan-bluish-gray-background-color {
         background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
      }

      .has-white-background-color {
         background-color: var(--wp--preset--color--white) !important;
      }

      .has-pale-pink-background-color {
         background-color: var(--wp--preset--color--pale-pink) !important;
      }

      .has-vivid-red-background-color {
         background-color: var(--wp--preset--color--vivid-red) !important;
      }

      .has-luminous-vivid-orange-background-color {
         background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
      }

      .has-luminous-vivid-amber-background-color {
         background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
      }

      .has-light-green-cyan-background-color {
         background-color: var(--wp--preset--color--light-green-cyan) !important;
      }

      .has-vivid-green-cyan-background-color {
         background-color: var(--wp--preset--color--vivid-green-cyan) !important;
      }

      .has-pale-cyan-blue-background-color {
         background-color: var(--wp--preset--color--pale-cyan-blue) !important;
      }

      .has-vivid-cyan-blue-background-color {
         background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
      }

      .has-vivid-purple-background-color {
         background-color: var(--wp--preset--color--vivid-purple) !important;
      }

      .has-black-border-color {
         border-color: var(--wp--preset--color--black) !important;
      }

      .has-cyan-bluish-gray-border-color {
         border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
      }

      .has-white-border-color {
         border-color: var(--wp--preset--color--white) !important;
      }

      .has-pale-pink-border-color {
         border-color: var(--wp--preset--color--pale-pink) !important;
      }

      .has-vivid-red-border-color {
         border-color: var(--wp--preset--color--vivid-red) !important;
      }

      .has-luminous-vivid-orange-border-color {
         border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
      }

      .has-luminous-vivid-amber-border-color {
         border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
      }

      .has-light-green-cyan-border-color {
         border-color: var(--wp--preset--color--light-green-cyan) !important;
      }

      .has-vivid-green-cyan-border-color {
         border-color: var(--wp--preset--color--vivid-green-cyan) !important;
      }

      .has-pale-cyan-blue-border-color {
         border-color: var(--wp--preset--color--pale-cyan-blue) !important;
      }

      .has-vivid-cyan-blue-border-color {
         border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
      }

      .has-vivid-purple-border-color {
         border-color: var(--wp--preset--color--vivid-purple) !important;
      }

      .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
         background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
      }

      .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
         background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
      }

      .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
         background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
      }

      .has-luminous-vivid-orange-to-vivid-red-gradient-background {
         background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
      }

      .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
         background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
      }

      .has-cool-to-warm-spectrum-gradient-background {
         background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
      }

      .has-blush-light-purple-gradient-background {
         background: var(--wp--preset--gradient--blush-light-purple) !important;
      }

      .has-blush-bordeaux-gradient-background {
         background: var(--wp--preset--gradient--blush-bordeaux) !important;
      }

      .has-luminous-dusk-gradient-background {
         background: var(--wp--preset--gradient--luminous-dusk) !important;
      }

      .has-pale-ocean-gradient-background {
         background: var(--wp--preset--gradient--pale-ocean) !important;
      }

      .has-electric-grass-gradient-background {
         background: var(--wp--preset--gradient--electric-grass) !important;
      }

      .has-midnight-gradient-background {
         background: var(--wp--preset--gradient--midnight) !important;
      }

      .has-small-font-size {
         font-size: var(--wp--preset--font-size--small) !important;
      }

      .has-medium-font-size {
         font-size: var(--wp--preset--font-size--medium) !important;
      }

      .has-large-font-size {
         font-size: var(--wp--preset--font-size--large) !important;
      }

      .has-x-large-font-size {
         font-size: var(--wp--preset--font-size--x-large) !important;
      }

      :where(.wp-block-post-template.is-layout-flex) {
         gap: 1.25em;
      }

      :where(.wp-block-post-template.is-layout-grid) {
         gap: 1.25em;
      }

      :where(.wp-block-columns.is-layout-flex) {
         gap: 2em;
      }

      :where(.wp-block-columns.is-layout-grid) {
         gap: 2em;
      }

      :root :where(.wp-block-pullquote) {
         font-size: 1.5em;
         line-height: 1.6;
      }
   </style>
   <link rel="stylesheet" id="chaty-front-css-css" href="assets_web/EVA_files/chaty-front.min.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="contact-form-7-css" href="assets_web/EVA_files/styles.css" type="text/css" media="all">
   <link rel="stylesheet" id="contact-form-7-rtl-css" href="assets_web/EVA_files/styles-rtl.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="woocommerce-layout-rtl-css" href="assets_web/EVA_files/woocommerce-layout-rtl.css"
      type="text/css" media="all">
   <link rel="stylesheet" id="woocommerce-smallscreen-rtl-css"
      href="assets_web/EVA_files/woocommerce-smallscreen-rtl.css" type="text/css"
      media="only screen and (max-width: 768px)">
   <link rel="stylesheet" id="woocommerce-general-rtl-css" href="assets_web/EVA_files/woocommerce-rtl.css"
      type="text/css" media="all">
   <style id="woocommerce-inline-inline-css" type="text/css">
      .woocommerce form .form-row .required {
         visibility: visible;
      }
   </style>
   <link rel="stylesheet" id="bookly-ladda.min.css-css" href="assets_web/EVA_files/ladda.min.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="bookly-tailwindreset.css-css" href="assets_web/EVA_files/tailwindreset.css"
      type="text/css" media="all">
   <link rel="stylesheet" id="bookly-tailwind.css-css" href="assets_web/EVA_files/tailwind.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="bookly-bootstrap-icons.min.css-css" href="assets_web/EVA_files/bootstrap-icons.min.css"
      type="text/css" media="all">
   <link rel="stylesheet" id="bookly-intlTelInput.css-css" href="assets_web/EVA_files/intlTelInput.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="bookly-bookly-main.css-css" href="assets_web/EVA_files/bookly-main.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="bookly-bookly-rtl.css-css" href="assets_web/EVA_files/bookly-rtl.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="bookly-bootstrap.min.css-css" href="assets_web/EVA_files/bootstrap.min.css"
      type="text/css" media="all">
   <link rel="stylesheet" id="bookly-customer-profile.css-css" href="assets_web/EVA_files/customer-profile.css"
      type="text/css" media="all">
   <link rel="stylesheet" id="if-menu-site-css-css" href="assets_web/EVA_files/if-menu-site.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="mfn-be-css" href="assets_web/EVA_files/be.css" type="text/css" media="all">
   <link rel="stylesheet" id="mfn-animations-css" href="assets_web/EVA_files/animations.min.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="mfn-font-awesome-css" href="assets_web/EVA_files/fontawesome.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="mfn-jplayer-css" href="assets_web/EVA_files/jplayer.blue.monday.min.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="mfn-responsive-css" href="assets_web/EVA_files/responsive.css" type="text/css"
      media="all">
   <link rel="stylesheet" id="mfn-fonts-css" href="assets_web/EVA_files/css" type="text/css" media="all">
   <link rel="stylesheet" id="mfn-woo-css" href="assets_web/EVA_files/woocommerce.css" type="text/css" media="all">
   <style id="mfn-dynamic-inline-css" type="text/css">
      body:not(.template-slider) #Header_wrapper {
         background-image: url(https://ninjawarriorarabia.com/wp-content/uploads/2019/05/lab2_pic42.jpg)
      }

      html {
         background-color: #ffffff
      }

      #Wrapper,
      #Content,
      .mfn-popup .mfn-popup-content,
      .mfn-off-canvas-sidebar .mfn-off-canvas-content-wrapper,
      .mfn-cart-holder,
      .mfn-header-login,
      #Top_bar .search_wrapper,
      #Top_bar .top_bar_right .mfn-live-search-box,
      .column_livesearch .mfn-live-search-wrapper,
      .column_livesearch .mfn-live-search-box {
         background-color: #ffffff
      }

      .layout-boxed.mfn-bebuilder-header.mfn-ui #Wrapper .mfn-only-sample-content {
         background-color: #ffffff
      }

      body:not(.template-slider) #Header {
         min-height: 133px
      }

      body.header-below:not(.template-slider) #Header {
         padding-top: 133px
      }

      #Subheader {
         padding: 240px 0 110px
      }

      #Footer .widgets_wrapper {
         padding: 20px 0 10px
      }

      .has-search-overlay.search-overlay-opened #search-overlay {
         background-color: rgba(0, 0, 0, 0.6)
      }

      .elementor-page.elementor-default #Content .the_content .section_wrapper {
         max-width: 100%
      }

      .elementor-page.elementor-default #Content .section.the_content {
         width: 100%
      }

      .elementor-page.elementor-default #Content .section_wrapper .the_content_wrapper {
         margin-left: 0;
         margin-right: 0;
         width: 100%
      }

      body,
      button,
      span.date_label,
      .timeline_items li h3 span,
      input[type="submit"],
      input[type="reset"],
      input[type="button"],
      input[type="date"],
      input[type="text"],
      input[type="password"],
      input[type="tel"],
      input[type="email"],
      textarea,
      select,
      .offer_li .title h3,
      .mfn-menu-item-megamenu {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      #menu>ul>li>a,
      a.action_button,
      #overlay-menu ul li a {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      #Subheader .title {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      h1,
      h2,
      h3,
      h4,
      .text-logo #logo {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      h5,
      h6 {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      blockquote {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      .chart_box .chart .num,
      .counter .desc_wrapper .number-wrapper,
      .how_it_works .image .number,
      .pricing-box .plan-header .price,
      .quick_fact .number-wrapper,
      .woocommerce .product div.entry-summary .price {
         font-family: "Cairo", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif
      }

      body,
      .mfn-menu-item-megamenu {
         font-size: 15px;
         line-height: 27px;
         font-weight: 400;
         letter-spacing: 0px
      }

      .big {
         font-size: 16px;
         line-height: 28px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #menu>ul>li>a,
      a.action_button,
      #overlay-menu ul li a {
         font-size: 14px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #overlay-menu ul li a {
         line-height: 21px
      }

      #Subheader .title {
         font-size: 80px;
         line-height: 80px;
         font-weight: 700;
         letter-spacing: 0px
      }

      h1,
      .text-logo #logo {
         font-size: 48px;
         line-height: 50px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h2 {
         font-size: 60px;
         line-height: 70px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h3,
      .woocommerce ul.products li.product h3,
      .woocommerce #customer_login h2 {
         font-size: 40px;
         line-height: 50px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h4,
      .woocommerce .woocommerce-order-details__title,
      .woocommerce .wc-bacs-bank-details-heading,
      .woocommerce .woocommerce-customer-details h2 {
         font-size: 22px;
         line-height: 32px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h5 {
         font-size: 17px;
         line-height: 27px;
         font-weight: 500;
         letter-spacing: 0px
      }

      h6 {
         font-size: 17px;
         line-height: 29px;
         font-weight: 600;
         letter-spacing: 0px
      }

      #Intro .intro-title {
         font-size: 70px;
         line-height: 70px;
         font-weight: 400;
         letter-spacing: 0px
      }

      <blade media|%20only%20screen%20and%20(min-width%3A768px)%20and%20(max-width%3A959px)%20%7B%0D>body,
      .mfn-menu-item-megamenu {
         font-size: 13px;
         line-height: 23px;
         font-weight: 400;
         letter-spacing: 0px
      }

      .big {
         font-size: 14px;
         line-height: 24px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #menu>ul>li>a,
      a.action_button,
      #overlay-menu ul li a {
         font-size: 13px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #overlay-menu ul li a {
         line-height: 19.5px
      }

      #Subheader .title {
         font-size: 68px;
         line-height: 68px;
         font-weight: 700;
         letter-spacing: 0px
      }

      h1,
      .text-logo #logo {
         font-size: 41px;
         line-height: 43px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h2 {
         font-size: 51px;
         line-height: 60px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h3,
      .woocommerce ul.products li.product h3,
      .woocommerce #customer_login h2 {
         font-size: 34px;
         line-height: 43px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h4,
      .woocommerce .woocommerce-order-details__title,
      .woocommerce .wc-bacs-bank-details-heading,
      .woocommerce .woocommerce-customer-details h2 {
         font-size: 19px;
         line-height: 27px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h5 {
         font-size: 14px;
         line-height: 23px;
         font-weight: 500;
         letter-spacing: 0px
      }

      h6 {
         font-size: 14px;
         line-height: 25px;
         font-weight: 600;
         letter-spacing: 0px
      }

      #Intro .intro-title {
         font-size: 60px;
         line-height: 60px;
         font-weight: 400;
         letter-spacing: 0px
      }

      blockquote {
         font-size: 15px
      }

      .chart_box .chart .num {
         font-size: 45px;
         line-height: 45px
      }

      .counter .desc_wrapper .number-wrapper {
         font-size: 45px;
         line-height: 45px
      }

      .counter .desc_wrapper .title {
         font-size: 14px;
         line-height: 18px
      }

      .faq .question .title {
         font-size: 14px
      }

      .fancy_heading .title {
         font-size: 38px;
         line-height: 38px
      }

      .offer .offer_li .desc_wrapper .title h3 {
         font-size: 32px;
         line-height: 32px
      }

      .offer_thumb_ul li.offer_thumb_li .desc_wrapper .title h3 {
         font-size: 32px;
         line-height: 32px
      }

      .pricing-box .plan-header h2 {
         font-size: 27px;
         line-height: 27px
      }

      .pricing-box .plan-header .price>span {
         font-size: 40px;
         line-height: 40px
      }

      .pricing-box .plan-header .price sup.currency {
         font-size: 18px;
         line-height: 18px
      }

      .pricing-box .plan-header .price sup.period {
         font-size: 14px;
         line-height: 14px
      }

      .quick_fact .number-wrapper {
         font-size: 80px;
         line-height: 80px
      }

      .trailer_box .desc h2 {
         font-size: 27px;
         line-height: 27px
      }

      .widget>h3 {
         font-size: 17px;
         line-height: 20px
      }
      }

      <blade media|%20only%20screen%20and%20(min-width%3A480px)%20and%20(max-width%3A767px)%20%7B%0D>body,
      .mfn-menu-item-megamenu {
         font-size: 13px;
         line-height: 20px;
         font-weight: 400;
         letter-spacing: 0px
      }

      .big {
         font-size: 13px;
         line-height: 21px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #menu>ul>li>a,
      a.action_button,
      #overlay-menu ul li a {
         font-size: 13px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #overlay-menu ul li a {
         line-height: 19.5px
      }

      #Subheader .title {
         font-size: 60px;
         line-height: 60px;
         font-weight: 700;
         letter-spacing: 0px
      }

      h1,
      .text-logo #logo {
         font-size: 36px;
         line-height: 38px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h2 {
         font-size: 45px;
         line-height: 53px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h3,
      .woocommerce ul.products li.product h3,
      .woocommerce #customer_login h2 {
         font-size: 30px;
         line-height: 38px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h4,
      .woocommerce .woocommerce-order-details__title,
      .woocommerce .wc-bacs-bank-details-heading,
      .woocommerce .woocommerce-customer-details h2 {
         font-size: 17px;
         line-height: 24px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h5 {
         font-size: 13px;
         line-height: 20px;
         font-weight: 500;
         letter-spacing: 0px
      }

      h6 {
         font-size: 13px;
         line-height: 22px;
         font-weight: 600;
         letter-spacing: 0px
      }

      #Intro .intro-title {
         font-size: 53px;
         line-height: 53px;
         font-weight: 400;
         letter-spacing: 0px
      }

      blockquote {
         font-size: 14px
      }

      .chart_box .chart .num {
         font-size: 40px;
         line-height: 40px
      }

      .counter .desc_wrapper .number-wrapper {
         font-size: 40px;
         line-height: 40px
      }

      .counter .desc_wrapper .title {
         font-size: 13px;
         line-height: 16px
      }

      .faq .question .title {
         font-size: 13px
      }

      .fancy_heading .title {
         font-size: 34px;
         line-height: 34px
      }

      .offer .offer_li .desc_wrapper .title h3 {
         font-size: 28px;
         line-height: 28px
      }

      .offer_thumb_ul li.offer_thumb_li .desc_wrapper .title h3 {
         font-size: 28px;
         line-height: 28px
      }

      .pricing-box .plan-header h2 {
         font-size: 24px;
         line-height: 24px
      }

      .pricing-box .plan-header .price>span {
         font-size: 34px;
         line-height: 34px
      }

      .pricing-box .plan-header .price sup.currency {
         font-size: 16px;
         line-height: 16px
      }

      .pricing-box .plan-header .price sup.period {
         font-size: 13px;
         line-height: 13px
      }

      .quick_fact .number-wrapper {
         font-size: 70px;
         line-height: 70px
      }

      .trailer_box .desc h2 {
         font-size: 24px;
         line-height: 24px
      }

      .widget>h3 {
         font-size: 16px;
         line-height: 19px
      }
      }

      <blade media|%20only%20screen%20and%20(max-width%3A479px)%20%7B%0D>body,
      .mfn-menu-item-megamenu {
         font-size: 13px;
         line-height: 19px;
         font-weight: 400;
         letter-spacing: 0px
      }

      .big {
         font-size: 13px;
         line-height: 19px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #menu>ul>li>a,
      a.action_button,
      #overlay-menu ul li a {
         font-size: 13px;
         font-weight: 400;
         letter-spacing: 0px
      }

      #overlay-menu ul li a {
         line-height: 19.5px
      }

      #Subheader .title {
         font-size: 48px;
         line-height: 48px;
         font-weight: 700;
         letter-spacing: 0px
      }

      h1,
      .text-logo #logo {
         font-size: 29px;
         line-height: 30px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h2 {
         font-size: 36px;
         line-height: 42px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h3,
      .woocommerce ul.products li.product h3,
      .woocommerce #customer_login h2 {
         font-size: 24px;
         line-height: 30px;
         font-weight: 600;
         letter-spacing: -1px
      }

      h4,
      .woocommerce .woocommerce-order-details__title,
      .woocommerce .wc-bacs-bank-details-heading,
      .woocommerce .woocommerce-customer-details h2 {
         font-size: 13px;
         line-height: 19px;
         font-weight: 400;
         letter-spacing: 0px
      }

      h5 {
         font-size: 13px;
         line-height: 19px;
         font-weight: 500;
         letter-spacing: 0px
      }

      h6 {
         font-size: 13px;
         line-height: 19px;
         font-weight: 600;
         letter-spacing: 0px
      }

      #Intro .intro-title {
         font-size: 42px;
         line-height: 42px;
         font-weight: 400;
         letter-spacing: 0px
      }

      blockquote {
         font-size: 13px
      }

      .chart_box .chart .num {
         font-size: 35px;
         line-height: 35px
      }

      .counter .desc_wrapper .number-wrapper {
         font-size: 35px;
         line-height: 35px
      }

      .counter .desc_wrapper .title {
         font-size: 13px;
         line-height: 26px
      }

      .faq .question .title {
         font-size: 13px
      }

      .fancy_heading .title {
         font-size: 30px;
         line-height: 30px
      }

      .offer .offer_li .desc_wrapper .title h3 {
         font-size: 26px;
         line-height: 26px
      }

      .offer_thumb_ul li.offer_thumb_li .desc_wrapper .title h3 {
         font-size: 26px;
         line-height: 26px
      }

      .pricing-box .plan-header h2 {
         font-size: 21px;
         line-height: 21px
      }

      .pricing-box .plan-header .price>span {
         font-size: 32px;
         line-height: 32px
      }

      .pricing-box .plan-header .price sup.currency {
         font-size: 14px;
         line-height: 14px
      }

      .pricing-box .plan-header .price sup.period {
         font-size: 13px;
         line-height: 13px
      }

      .quick_fact .number-wrapper {
         font-size: 60px;
         line-height: 60px
      }

      .trailer_box .desc h2 {
         font-size: 21px;
         line-height: 21px
      }

      .widget>h3 {
         font-size: 15px;
         line-height: 18px
      }
      }

      .with_aside .sidebar.columns {
         width: 23%
      }

      .with_aside .sections_group {
         width: 77%
      }

      .aside_both .sidebar.columns {
         width: 18%
      }

      .aside_both .sidebar.sidebar-1 {
         margin-left: -82%
      }

      .aside_both .sections_group {
         width: 64%;
         margin-left: 18%
      }

      <blade media|%20only%20screen%20and%20(min-width%3A1240px)%20%7B%0D>#Wrapper,
      .with_aside .content_wrapper {
         max-width: 1200px
      }

      body.layout-boxed.mfn-header-scrolled .mfn-header-tmpl.mfn-sticky-layout-width {
         max-width: 1200px;
         left: 0;
         right: 0;
         margin-left: auto;
         margin-right: auto
      }

      body.layout-boxed:not(.mfn-header-scrolled) .mfn-header-tmpl.mfn-header-layout-width,
      body.layout-boxed .mfn-header-tmpl.mfn-header-layout-width:not(.mfn-hasSticky) {
         max-width: 1200px;
         left: 0;
         right: 0;
         margin-left: auto;
         margin-right: auto
      }

      body.layout-boxed.mfn-bebuilder-header.mfn-ui .mfn-only-sample-content {
         max-width: 1200px;
         margin-left: auto;
         margin-right: auto
      }

      .section_wrapper,
      .container {
         max-width: 1180px
      }

      .layout-boxed.header-boxed #Top_bar.is-sticky {
         max-width: 1200px
      }
      }

      <blade media|%20only%20screen%20and%20(max-width%3A767px)%20%7B%0D>#Wrapper {
         max-width: calc(100% - 67px)
      }

      .content_wrapper .section_wrapper,
      .container,
      .four.columns .widget-area {
         max-width: 550px !important;
         padding-left: 33px;
         padding-right: 33px
      }
      }

      .button-default .button,
      .button-flat .button,
      .button-round .button {
         background-color: #f7f7f7;
         color: #747474
      }

      .button-stroke .button {
         border-color: #f7f7f7;
         color: #747474
      }

      .button-stroke .button:hover {
         background-color: #f7f7f7;
         color: #fff
      }

      .button-default .button_theme,
      .button-default button,
      .button-default input[type="button"],
      .button-default input[type="reset"],
      .button-default input[type="submit"],
      .button-flat .button_theme,
      .button-flat button,
      .button-flat input[type="button"],
      .button-flat input[type="reset"],
      .button-flat input[type="submit"],
      .button-round .button_theme,
      .button-round button,
      .button-round input[type="button"],
      .button-round input[type="reset"],
      .button-round input[type="submit"],
      .woocommerce #respond input#submit,
      .woocommerce a.button:not(.default),
      .woocommerce button.button,
      .woocommerce input.button,
      .woocommerce #respond input#submit:hover,
      .woocommerce a.button:hover,
      .woocommerce button.button:hover,
      .woocommerce input.button:hover {
         color: #ffffff
      }

      .button-default #respond input#submit.alt.disabled,
      .button-default #respond input#submit.alt.disabled:hover,
      .button-default #respond input#submit.alt:disabled,
      .button-default #respond input#submit.alt:disabled:hover,
      .button-default #respond input#submit.alt:disabled[disabled],
      .button-default #respond input#submit.alt:disabled[disabled]:hover,
      .button-default a.button.alt.disabled,
      .button-default a.button.alt.disabled:hover,
      .button-default a.button.alt:disabled,
      .button-default a.button.alt:disabled:hover,
      .button-default a.button.alt:disabled[disabled],
      .button-default a.button.alt:disabled[disabled]:hover,
      .button-default button.button.alt.disabled,
      .button-default button.button.alt.disabled:hover,
      .button-default button.button.alt:disabled,
      .button-default button.button.alt:disabled:hover,
      .button-default button.button.alt:disabled[disabled],
      .button-default button.button.alt:disabled[disabled]:hover,
      .button-default input.button.alt.disabled,
      .button-default input.button.alt.disabled:hover,
      .button-default input.button.alt:disabled,
      .button-default input.button.alt:disabled:hover,
      .button-default input.button.alt:disabled[disabled],
      .button-default input.button.alt:disabled[disabled]:hover,
      .button-default #respond input#submit.alt,
      .button-default a.button.alt,
      .button-default button.button.alt,
      .button-default input.button.alt,
      .button-default #respond input#submit.alt:hover,
      .button-default a.button.alt:hover,
      .button-default button.button.alt:hover,
      .button-default input.button.alt:hover,
      .button-flat #respond input#submit.alt.disabled,
      .button-flat #respond input#submit.alt.disabled:hover,
      .button-flat #respond input#submit.alt:disabled,
      .button-flat #respond input#submit.alt:disabled:hover,
      .button-flat #respond input#submit.alt:disabled[disabled],
      .button-flat #respond input#submit.alt:disabled[disabled]:hover,
      .button-flat a.button.alt.disabled,
      .button-flat a.button.alt.disabled:hover,
      .button-flat a.button.alt:disabled,
      .button-flat a.button.alt:disabled:hover,
      .button-flat a.button.alt:disabled[disabled],
      .button-flat a.button.alt:disabled[disabled]:hover,
      .button-flat button.button.alt.disabled,
      .button-flat button.button.alt.disabled:hover,
      .button-flat button.button.alt:disabled,
      .button-flat button.button.alt:disabled:hover,
      .button-flat button.button.alt:disabled[disabled],
      .button-flat button.button.alt:disabled[disabled]:hover,
      .button-flat input.button.alt.disabled,
      .button-flat input.button.alt.disabled:hover,
      .button-flat input.button.alt:disabled,
      .button-flat input.button.alt:disabled:hover,
      .button-flat input.button.alt:disabled[disabled],
      .button-flat input.button.alt:disabled[disabled]:hover,
      .button-flat #respond input#submit.alt,
      .button-flat a.button.alt,
      .button-flat button.button.alt,
      .button-flat input.button.alt,
      .button-flat #respond input#submit.alt:hover,
      .button-flat a.button.alt:hover,
      .button-flat button.button.alt:hover,
      .button-flat input.button.alt:hover,
      .button-round #respond input#submit.alt.disabled,
      .button-round #respond input#submit.alt.disabled:hover,
      .button-round #respond input#submit.alt:disabled,
      .button-round #respond input#submit.alt:disabled:hover,
      .button-round #respond input#submit.alt:disabled[disabled],
      .button-round #respond input#submit.alt:disabled[disabled]:hover,
      .button-round a.button.alt.disabled,
      .button-round a.button.alt.disabled:hover,
      .button-round a.button.alt:disabled,
      .button-round a.button.alt:disabled:hover,
      .button-round a.button.alt:disabled[disabled],
      .button-round a.button.alt:disabled[disabled]:hover,
      .button-round button.button.alt.disabled,
      .button-round button.button.alt.disabled:hover,
      .button-round button.button.alt:disabled,
      .button-round button.button.alt:disabled:hover,
      .button-round button.button.alt:disabled[disabled],
      .button-round button.button.alt:disabled[disabled]:hover,
      .button-round input.button.alt.disabled,
      .button-round input.button.alt.disabled:hover,
      .button-round input.button.alt:disabled,
      .button-round input.button.alt:disabled:hover,
      .button-round input.button.alt:disabled[disabled],
      .button-round input.button.alt:disabled[disabled]:hover,
      .button-round #respond input#submit.alt,
      .button-round a.button.alt,
      .button-round button.button.alt,
      .button-round input.button.alt,
      .button-round #respond input#submit.alt:hover,
      .button-round a.button.alt:hover,
      .button-round button.button.alt:hover,
      .button-round input.button.alt:hover {
         background-color: #6d3579;
         color: #ffffff
      }

      .button-stroke.woocommerce a.button:not(.default),
      .button-stroke .woocommerce a.button:not(.default),
      .button-stroke #respond input#submit.alt.disabled,
      .button-stroke #respond input#submit.alt.disabled:hover,
      .button-stroke #respond input#submit.alt:disabled,
      .button-stroke #respond input#submit.alt:disabled:hover,
      .button-stroke #respond input#submit.alt:disabled[disabled],
      .button-stroke #respond input#submit.alt:disabled[disabled]:hover,
      .button-stroke a.button.alt.disabled,
      .button-stroke a.button.alt.disabled:hover,
      .button-stroke a.button.alt:disabled,
      .button-stroke a.button.alt:disabled:hover,
      .button-stroke a.button.alt:disabled[disabled],
      .button-stroke a.button.alt:disabled[disabled]:hover,
      .button-stroke button.button.alt.disabled,
      .button-stroke button.button.alt.disabled:hover,
      .button-stroke button.button.alt:disabled,
      .button-stroke button.button.alt:disabled:hover,
      .button-stroke button.button.alt:disabled[disabled],
      .button-stroke button.button.alt:disabled[disabled]:hover,
      .button-stroke input.button.alt.disabled,
      .button-stroke input.button.alt.disabled:hover,
      .button-stroke input.button.alt:disabled,
      .button-stroke input.button.alt:disabled:hover,
      .button-stroke input.button.alt:disabled[disabled],
      .button-stroke input.button.alt:disabled[disabled]:hover,
      .button-stroke #respond input#submit.alt,
      .button-stroke a.button.alt,
      .button-stroke button.button.alt,
      .button-stroke input.button.alt {
         border-color: #6d3579;
         background: none;
         color: #6d3579
      }

      .button-stroke.woocommerce a.button:not(.default):hover,
      .button-stroke .woocommerce a.button:not(.default):hover,
      .button-stroke #respond input#submit.alt:hover,
      .button-stroke a.button.alt:hover,
      .button-stroke button.button.alt:hover,
      .button-stroke input.button.alt:hover,
      .button-stroke a.action_button:hover {
         background-color: #6d3579;
         color: #ffffff
      }

      .action_button,
      .action_button:hover {
         background-color: #01cd61;
         color: #ffffff
      }

      .button-stroke a.action_button {
         border-color: #01cd61
      }

      .footer_button {
         color: #65666C !important;
         background-color: transparent;
         box-shadow: none !important
      }

      .footer_button:after {
         display: none !important
      }

      .button-custom.woocommerce .button,
      .button-custom .button,
      .button-custom .action_button,
      .button-custom .footer_button,
      .button-custom button,
      .button-custom button.button,
      .button-custom input[type="button"],
      .button-custom input[type="reset"],
      .button-custom input[type="submit"],
      .button-custom .woocommerce #respond input#submit,
      .button-custom .woocommerce a.button,
      .button-custom .woocommerce button.button,
      .button-custom .woocommerce input.button,
      .button-custom:where(body:not(.woocommerce-block-theme-has-button-styles)) .woocommerce button.button:disabled[disabled] {
         font-family: Roboto;
         font-size: 14px;
         line-height: 14px;
         font-weight: 400;
         letter-spacing: 0px;
         padding: 12px 20px 12px 20px;
         border-width: 0px;
         border-radius: 0px;
         border-color: transparent
      }

      body.button-custom .button {
         color: #626262;
         background-color: #dbdddf;
         border-color: transparent
      }

      body.button-custom .button:hover {
         color: #626262;
         background-color: #d3d3d3;
         border-color: transparent
      }

      body .button-custom .button_theme,
      body.button-custom .button_theme,
      .button-custom button,
      .button-custom input[type="button"],
      .button-custom input[type="reset"],
      .button-custom input[type="submit"],
      .button-custom .woocommerce #respond input#submit,
      body.button-custom.woocommerce a.button:not(.default),
      .button-custom .woocommerce button.button,
      .button-custom .woocommerce input.button,
      .button-custom .woocommerce a.button_theme:not(.default) {
         color: #ffffff;
         background-color: #0095eb;
         border-color: transparent;
         box-shadow: unset
      }

      body .button-custom .button_theme:hover,
      body.button-custom .button_theme:hover,
      .button-custom button:hover,
      .button-custom input[type="button"]:hover,
      .button-custom input[type="reset"]:hover,
      .button-custom input[type="submit"]:hover,
      .button-custom .woocommerce #respond input#submit:hover,
      body.button-custom.woocommerce .button:not(.default):hover,
      body.button-custom.woocommerce a.button:not(.default):hover,
      .button-custom .woocommerce button.button:hover,
      .button-custom .woocommerce input.button:hover,
      .button-custom .woocommerce a.button_theme:not(.default):hover {
         color: #ffffff;
         background-color: #007cc3;
         border-color: transparent
      }

      body.button-custom .action_button {
         color: #626262;
         background-color: #dbdddf;
         border-color: transparent;
         box-shadow: unset
      }

      body.button-custom .action_button:hover {
         color: #626262;
         background-color: #d3d3d3;
         border-color: transparent
      }

      .button-custom #respond input#submit.alt.disabled,
      .button-custom #respond input#submit.alt.disabled:hover,
      .button-custom #respond input#submit.alt:disabled,
      .button-custom #respond input#submit.alt:disabled:hover,
      .button-custom #respond input#submit.alt:disabled[disabled],
      .button-custom #respond input#submit.alt:disabled[disabled]:hover,
      .button-custom a.button.alt.disabled,
      .button-custom a.button.alt.disabled:hover,
      .button-custom a.button.alt:disabled,
      .button-custom a.button.alt:disabled:hover,
      .button-custom a.button.alt:disabled[disabled],
      .button-custom a.button.alt:disabled[disabled]:hover,
      .button-custom button.button.alt.disabled,
      .button-custom button.button.alt.disabled:hover,
      .button-custom button.button.alt:disabled,
      .button-custom button.button.alt:disabled:hover,
      .button-custom button.button.alt:disabled[disabled],
      .button-custom button.button.alt:disabled[disabled]:hover,
      .button-custom input.button.alt.disabled,
      .button-custom input.button.alt.disabled:hover,
      .button-custom input.button.alt:disabled,
      .button-custom input.button.alt:disabled:hover,
      .button-custom input.button.alt:disabled[disabled],
      .button-custom input.button.alt:disabled[disabled]:hover,
      .button-custom #respond input#submit.alt,
      .button-custom a.button.alt,
      .button-custom button.button.alt,
      .button-custom input.button.alt {
         line-height: 14px;
         padding: 12px 20px 12px 20px;
         color: #ffffff;
         background-color: #0095eb;
         font-family: Roboto;
         font-size: 14px;
         font-weight: 400;
         letter-spacing: 0px;
         border-width: 0px;
         border-radius: 0px
      }

      .button-custom #respond input#submit.alt:hover,
      .button-custom a.button.alt:hover,
      .button-custom button.button.alt:hover,
      .button-custom input.button.alt:hover,
      .button-custom a.action_button:hover {
         color: #ffffff;
         background-color: #007cc3
      }

      #Top_bar #logo,
      .header-fixed #Top_bar #logo,
      .header-plain #Top_bar #logo,
      .header-transparent #Top_bar #logo {
         height: 105px;
         line-height: 105px;
         padding: 14px 0
      }

      .logo-overflow #Top_bar:not(.is-sticky) .logo {
         height: 133px
      }

      #Top_bar .menu>li>a {
         padding: 36.5px 0
      }

      .menu-highlight:not(.header-creative) #Top_bar .menu>li>a {
         margin: 41.5px 0
      }

      .header-plain:not(.menu-highlight) #Top_bar .menu>li>a span:not(.description) {
         line-height: 133px
      }

      .header-fixed #Top_bar .menu>li>a {
         padding: 51.5px 0
      }

      <blade media|%20only%20screen%20and%20(max-width%3A767px)%20%7B%0D>.mobile-header-mini #Top_bar #logo {
         height: 50px !important;
         line-height: 50px !important;
         margin: 5px 0
      }
      }

      #Top_bar #logo img.svg {
         width: 100px
      }

      .image_frame,
      .wp-caption {
         border-width: 0px
      }

      .alert {
         border-radius: 0px
      }

      #Top_bar .top_bar_right .top-bar-right-input input {
         width: 200px
      }

      .mfn-live-search-box .mfn-live-search-list {
         max-height: 300px
      }

      #Side_slide {
         right: -250px;
         width: 250px
      }

      #Side_slide.left {
         left: -250px
      }

      .blog-teaser li .desc-wrapper .desc {
         background-position-y: -1px
      }

      .mfn-free-delivery-info {
         --mfn-free-delivery-bar: #6d3579;
         --mfn-free-delivery-bg: rgba(0, 0, 0, 0.1);
         --mfn-free-delivery-achieved: #6d3579
      }

      <blade media|%20only%20screen%20and%20(max-width%3A767px)%20%7B%7D%0D><blade media|%20only%20screen%20and%20(min-width%3A1240px)%20%7B%0D>body:not(.header-simple) #Top_bar #menu {
         display: block !important
      }

      .tr-menu #Top_bar #menu {
         background: none !important
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li {
         float: left
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-1 {
         width: 100%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-2 {
         width: 50%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-3 {
         width: 33.33%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-4 {
         width: 25%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-5 {
         width: 20%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li.mfn-megamenu-cols-6 {
         width: 16.66%
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li>ul {
         display: block !important;
         position: inherit;
         left: auto;
         top: auto;
         border-width: 0 1px 0 0
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li:last-child>ul {
         border: 0
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li>ul li {
         width: auto
      }

      #Top_bar .menu>li>ul.mfn-megamenu a.mfn-megamenu-title {
         text-transform: uppercase;
         font-weight: 400;
         background: none
      }

      #Top_bar .menu>li>ul.mfn-megamenu a .menu-arrow {
         display: none
      }

      .menuo-right #Top_bar .menu>li>ul.mfn-megamenu {
         left: 0;
         width: 98% !important;
         margin: 0 1%;
         padding: 20px 0
      }

      .menuo-right #Top_bar .menu>li>ul.mfn-megamenu-bg {
         box-sizing: border-box
      }

      #Top_bar .menu>li>ul.mfn-megamenu-bg {
         padding: 20px 166px 20px 20px;
         background-repeat: no-repeat;
         background-position: right bottom
      }

      .rtl #Top_bar .menu>li>ul.mfn-megamenu-bg {
         padding-left: 166px;
         padding-right: 20px;
         background-position: left bottom
      }

      #Top_bar .menu>li>ul.mfn-megamenu-bg>li {
         background: none
      }

      #Top_bar .menu>li>ul.mfn-megamenu-bg>li a {
         border: none
      }

      #Top_bar .menu>li>ul.mfn-megamenu-bg>li>ul {
         background: none !important;
         -webkit-box-shadow: 0 0 0 0;
         -moz-box-shadow: 0 0 0 0;
         box-shadow: 0 0 0 0
      }

      .mm-vertical #Top_bar .container {
         position: relative
      }

      .mm-vertical #Top_bar .top_bar_left {
         position: static
      }

      .mm-vertical #Top_bar .menu>li ul {
         box-shadow: 0 0 0 0 transparent !important;
         background-image: none
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu {
         padding: 20px 0
      }

      .mm-vertical.header-plain #Top_bar .menu>li>ul.mfn-megamenu {
         width: 100% !important;
         margin: 0
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li {
         display: table-cell;
         float: none !important;
         width: 10%;
         padding: 0 15px;
         border-right: 1px solid rgba(0, 0, 0, 0.05)
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li:last-child {
         border-right-width: 0
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li.hide-border {
         border-right-width: 0
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li a {
         border-bottom-width: 0;
         padding: 9px 15px;
         line-height: 120%
      }

      .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu a.mfn-megamenu-title {
         font-weight: 700
      }

      .rtl .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li:first-child {
         border-right-width: 0
      }

      .rtl .mm-vertical #Top_bar .menu>li>ul.mfn-megamenu>li:last-child {
         border-right-width: 1px
      }

      body.header-shop #Top_bar #menu {
         display: flex !important;
         background-color: transparent
      }

      .header-shop #Top_bar.is-sticky .top_bar_row_second {
         display: none
      }

      .header-plain:not(.menuo-right) #Header .top_bar_left {
         width: auto !important
      }

      .header-stack.header-center #Top_bar #menu {
         display: inline-block !important
      }

      .header-simple #Top_bar #menu {
         display: none;
         height: auto;
         width: 300px;
         bottom: auto;
         top: 100%;
         right: 1px;
         position: absolute;
         margin: 0
      }

      .header-simple #Header a.responsive-menu-toggle {
         display: block;
         right: 10px
      }

      .header-simple #Top_bar #menu>ul {
         width: 100%;
         float: left
      }

      .header-simple #Top_bar #menu ul li {
         width: 100%;
         padding-bottom: 0;
         border-right: 0;
         position: relative
      }

      .header-simple #Top_bar #menu ul li a {
         padding: 0 20px;
         margin: 0;
         display: block;
         height: auto;
         line-height: normal;
         border: none
      }

      .header-simple #Top_bar #menu ul li a:not(.menu-toggle):after {
         display: none
      }

      .header-simple #Top_bar #menu ul li a span {
         border: none;
         line-height: 44px;
         display: inline;
         padding: 0
      }

      .header-simple #Top_bar #menu ul li.submenu .menu-toggle {
         display: block;
         position: absolute;
         right: 0;
         top: 0;
         width: 44px;
         height: 44px;
         line-height: 44px;
         font-size: 30px;
         font-weight: 300;
         text-align: center;
         cursor: pointer;
         color: #444;
         opacity: 0.33;
         transform: unset
      }

      .header-simple #Top_bar #menu ul li.submenu .menu-toggle:after {
         content: "+";
         position: static
      }

      .header-simple #Top_bar #menu ul li.hover>.menu-toggle:after {
         content: "-"
      }

      .header-simple #Top_bar #menu ul li.hover a {
         border-bottom: 0
      }

      .header-simple #Top_bar #menu ul.mfn-megamenu li .menu-toggle {
         display: none
      }

      .header-simple #Top_bar #menu ul li ul {
         position: relative !important;
         left: 0 !important;
         top: 0;
         padding: 0;
         margin: 0 !important;
         width: auto !important;
         background-image: none
      }

      .header-simple #Top_bar #menu ul li ul li {
         width: 100% !important;
         display: block;
         padding: 0
      }

      .header-simple #Top_bar #menu ul li ul li a {
         padding: 0 20px 0 30px
      }

      .header-simple #Top_bar #menu ul li ul li a .menu-arrow {
         display: none
      }

      .header-simple #Top_bar #menu ul li ul li a span {
         padding: 0
      }

      .header-simple #Top_bar #menu ul li ul li a span:after {
         display: none !important
      }

      .header-simple #Top_bar .menu>li>ul.mfn-megamenu a.mfn-megamenu-title {
         text-transform: uppercase;
         font-weight: 400
      }

      .header-simple #Top_bar .menu>li>ul.mfn-megamenu>li>ul {
         display: block !important;
         position: inherit;
         left: auto;
         top: auto
      }

      .header-simple #Top_bar #menu ul li ul li ul {
         border-left: 0 !important;
         padding: 0;
         top: 0
      }

      .header-simple #Top_bar #menu ul li ul li ul li a {
         padding: 0 20px 0 40px
      }

      .rtl.header-simple #Top_bar #menu {
         left: 1px;
         right: auto
      }

      .rtl.header-simple #Top_bar a.responsive-menu-toggle {
         left: 10px;
         right: auto
      }

      .rtl.header-simple #Top_bar #menu ul li.submenu .menu-toggle {
         left: 0;
         right: auto
      }

      .rtl.header-simple #Top_bar #menu ul li ul {
         left: auto !important;
         right: 0 !important
      }

      .rtl.header-simple #Top_bar #menu ul li ul li a {
         padding: 0 30px 0 20px
      }

      .rtl.header-simple #Top_bar #menu ul li ul li ul li a {
         padding: 0 40px 0 20px
      }

      .menu-highlight #Top_bar .menu>li {
         margin: 0 2px
      }

      .menu-highlight:not(.header-creative) #Top_bar .menu>li>a {
         padding: 0;
         -webkit-border-radius: 5px;
         border-radius: 5px
      }

      .menu-highlight #Top_bar .menu>li>a:after {
         display: none
      }

      .menu-highlight #Top_bar .menu>li>a span:not(.description) {
         line-height: 50px
      }

      .menu-highlight #Top_bar .menu>li>a span.description {
         display: none
      }

      .menu-highlight.header-stack #Top_bar .menu>li>a {
         margin: 10px 0 !important
      }

      .menu-highlight.header-stack #Top_bar .menu>li>a span:not(.description) {
         line-height: 40px
      }

      .menu-highlight.header-simple #Top_bar #menu ul li,
      .menu-highlight.header-creative #Top_bar #menu ul li {
         margin: 0
      }

      .menu-highlight.header-simple #Top_bar #menu ul li>a,
      .menu-highlight.header-creative #Top_bar #menu ul li>a {
         -webkit-border-radius: 0;
         border-radius: 0
      }

      .menu-highlight:not(.header-fixed):not(.header-simple) #Top_bar.is-sticky .menu>li>a {
         margin: 10px 0 !important;
         padding: 5px 0 !important
      }

      .menu-highlight:not(.header-fixed):not(.header-simple) #Top_bar.is-sticky .menu>li>a span {
         line-height: 30px !important
      }

      .header-modern.menu-highlight.menuo-right .menu_wrapper {
         margin-right: 20px
      }

      .menu-line-below #Top_bar .menu>li>a:not(.menu-toggle):after {
         top: auto;
         bottom: -4px
      }

      .menu-line-below #Top_bar.is-sticky .menu>li>a:not(.menu-toggle):after {
         top: auto;
         bottom: -4px
      }

      .menu-line-below-80 #Top_bar:not(.is-sticky) .menu>li>a:not(.menu-toggle):after {
         height: 4px;
         left: 10%;
         top: 50%;
         margin-top: 20px;
         width: 80%
      }

      .menu-line-below-80-1 #Top_bar:not(.is-sticky) .menu>li>a:not(.menu-toggle):after {
         height: 1px;
         left: 10%;
         top: 50%;
         margin-top: 20px;
         width: 80%
      }

      .menu-link-color #Top_bar .menu>li>a:not(.menu-toggle):after {
         display: none !important
      }

      .menu-arrow-top #Top_bar .menu>li>a:after {
         background: none repeat scroll 0 0 rgba(0, 0, 0, 0) !important;
         border-color: #ccc transparent transparent;
         border-style: solid;
         border-width: 7px 7px 0;
         display: block;
         height: 0;
         left: 50%;
         margin-left: -7px;
         top: 0 !important;
         width: 0
      }

      .menu-arrow-top #Top_bar.is-sticky .menu>li>a:after {
         top: 0 !important
      }

      .menu-arrow-bottom #Top_bar .menu>li>a:after {
         background: none !important;
         border-color: transparent transparent #ccc;
         border-style: solid;
         border-width: 0 7px 7px;
         display: block;
         height: 0;
         left: 50%;
         margin-left: -7px;
         top: auto;
         bottom: 0;
         width: 0
      }

      .menu-arrow-bottom #Top_bar.is-sticky .menu>li>a:after {
         top: auto;
         bottom: 0
      }

      .menuo-no-borders #Top_bar .menu>li>a span {
         border-width: 0 !important
      }

      .menuo-no-borders #Header_creative #Top_bar .menu>li>a span {
         border-bottom-width: 0
      }

      .menuo-no-borders.header-plain #Top_bar a#header_cart,
      .menuo-no-borders.header-plain #Top_bar a#search_button,
      .menuo-no-borders.header-plain #Top_bar .wpml-languages,
      .menuo-no-borders.header-plain #Top_bar a.action_button {
         border-width: 0
      }

      .menuo-right #Top_bar .menu_wrapper {
         float: right
      }

      .menuo-right.header-stack:not(.header-center) #Top_bar .menu_wrapper {
         margin-right: 150px
      }

      body.header-creative {
         padding-left: 50px
      }

      body.header-creative.header-open {
         padding-left: 250px
      }

      body.error404,
      body.under-construction,
      body.template-blank,
      body.under-construction.header-rtl.header-creative.header-open {
         padding-left: 0 !important;
         padding-right: 0 !important
      }

      .header-creative.footer-fixed #Footer,
      .header-creative.footer-sliding #Footer,
      .header-creative.footer-stick #Footer.is-sticky {
         box-sizing: border-box;
         padding-left: 50px
      }

      .header-open.footer-fixed #Footer,
      .header-open.footer-sliding #Footer,
      .header-creative.footer-stick #Footer.is-sticky {
         padding-left: 250px
      }

      .header-rtl.header-creative.footer-fixed #Footer,
      .header-rtl.header-creative.footer-sliding #Footer,
      .header-rtl.header-creative.footer-stick #Footer.is-sticky {
         padding-left: 0;
         padding-right: 50px
      }

      .header-rtl.header-open.footer-fixed #Footer,
      .header-rtl.header-open.footer-sliding #Footer,
      .header-rtl.header-creative.footer-stick #Footer.is-sticky {
         padding-right: 250px
      }

      #Header_creative {
         background-color: #fff;
         position: fixed;
         width: 250px;
         height: 100%;
         left: -200px;
         top: 0;
         z-index: 9002;
         -webkit-box-shadow: 2px 0 4px 2px rgba(0, 0, 0, .15);
         box-shadow: 2px 0 4px 2px rgba(0, 0, 0, .15)
      }

      #Header_creative .container {
         width: 100%
      }

      #Header_creative .creative-wrapper {
         opacity: 0;
         margin-right: 50px
      }

      #Header_creative a.creative-menu-toggle {
         display: block;
         width: 34px;
         height: 34px;
         line-height: 34px;
         font-size: 22px;
         text-align: center;
         position: absolute;
         top: 10px;
         right: 8px;
         border-radius: 3px
      }

      .admin-bar #Header_creative a.creative-menu-toggle {
         top: 42px
      }

      #Header_creative #Top_bar {
         position: static;
         width: 100%
      }

      #Header_creative #Top_bar .top_bar_left {
         width: 100% !important;
         float: none
      }

      #Header_creative #Top_bar .logo {
         float: none;
         text-align: center;
         margin: 15px 0
      }

      #Header_creative #Top_bar #menu {
         background-color: transparent
      }

      #Header_creative #Top_bar .menu_wrapper {
         float: none;
         margin: 0 0 30px
      }

      #Header_creative #Top_bar .menu>li {
         width: 100%;
         float: none;
         position: relative
      }

      #Header_creative #Top_bar .menu>li>a {
         padding: 0;
         text-align: center
      }

      #Header_creative #Top_bar .menu>li>a:after {
         display: none
      }

      #Header_creative #Top_bar .menu>li>a span {
         border-right: 0;
         border-bottom-width: 1px;
         line-height: 38px
      }

      #Header_creative #Top_bar .menu li ul {
         left: 100%;
         right: auto;
         top: 0;
         box-shadow: 2px 2px 2px 0 rgba(0, 0, 0, 0.03);
         -webkit-box-shadow: 2px 2px 2px 0 rgba(0, 0, 0, 0.03)
      }

      #Header_creative #Top_bar .menu>li>ul.mfn-megamenu {
         margin: 0;
         width: 700px !important
      }

      #Header_creative #Top_bar .menu>li>ul.mfn-megamenu>li>ul {
         left: 0
      }

      #Header_creative #Top_bar .menu li ul li a {
         padding-top: 9px;
         padding-bottom: 8px
      }

      #Header_creative #Top_bar .menu li ul li ul {
         top: 0
      }

      #Header_creative #Top_bar .menu>li>a span.description {
         display: block;
         font-size: 13px;
         line-height: 28px !important;
         clear: both
      }

      .menuo-arrows #Top_bar .menu>li.submenu>a>span:after {
         content: unset !important
      }

      #Header_creative #Top_bar .top_bar_right {
         width: 100% !important;
         float: left;
         height: auto;
         margin-bottom: 35px;
         text-align: center;
         padding: 0 20px;
         top: 0;
         -webkit-box-sizing: border-box;
         -moz-box-sizing: border-box;
         box-sizing: border-box
      }

      #Header_creative #Top_bar .top_bar_right:before {
         content: none
      }

      #Header_creative #Top_bar .top_bar_right .top_bar_right_wrapper {
         flex-wrap: wrap;
         justify-content: center
      }

      #Header_creative #Top_bar .top_bar_right .top-bar-right-icon,
      #Header_creative #Top_bar .top_bar_right .wpml-languages,
      #Header_creative #Top_bar .top_bar_right .top-bar-right-button,
      #Header_creative #Top_bar .top_bar_right .top-bar-right-input {
         min-height: 30px;
         margin: 5px
      }

      #Header_creative #Top_bar .search_wrapper {
         left: 100%;
         top: auto
      }

      #Header_creative #Top_bar .banner_wrapper {
         display: block;
         text-align: center
      }

      #Header_creative #Top_bar .banner_wrapper img {
         max-width: 100%;
         height: auto;
         display: inline-block
      }

      #Header_creative #Action_bar {
         display: none;
         position: absolute;
         bottom: 0;
         top: auto;
         clear: both;
         padding: 0 20px;
         box-sizing: border-box
      }

      #Header_creative #Action_bar .contact_details {
         width: 100%;
         text-align: center;
         margin-bottom: 20px
      }

      #Header_creative #Action_bar .contact_details li {
         padding: 0
      }

      #Header_creative #Action_bar .social {
         float: none;
         text-align: center;
         padding: 5px 0 15px
      }

      #Header_creative #Action_bar .social li {
         margin-bottom: 2px
      }

      #Header_creative #Action_bar .social-menu {
         float: none;
         text-align: center
      }

      #Header_creative #Action_bar .social-menu li {
         border-color: rgba(0, 0, 0, .1)
      }

      #Header_creative .social li a {
         color: rgba(0, 0, 0, .5)
      }

      #Header_creative .social li a:hover {
         color: #000
      }

      #Header_creative .creative-social {
         position: absolute;
         bottom: 10px;
         right: 0;
         width: 50px
      }

      #Header_creative .creative-social li {
         display: block;
         float: none;
         width: 100%;
         text-align: center;
         margin-bottom: 5px
      }

      .header-creative .fixed-nav.fixed-nav-prev {
         margin-left: 50px
      }

      .header-creative.header-open .fixed-nav.fixed-nav-prev {
         margin-left: 250px
      }

      .menuo-last #Header_creative #Top_bar .menu li.last ul {
         top: auto;
         bottom: 0
      }

      .header-open #Header_creative {
         left: 0
      }

      .header-open #Header_creative .creative-wrapper {
         opacity: 1;
         margin: 0 !important
      }

      .header-open #Header_creative .creative-menu-toggle,
      .header-open #Header_creative .creative-social {
         display: none
      }

      .header-open #Header_creative #Action_bar {
         display: block
      }

      body.header-rtl.header-creative {
         padding-left: 0;
         padding-right: 50px
      }

      .header-rtl #Header_creative {
         left: auto;
         right: -200px
      }

      .header-rtl #Header_creative .creative-wrapper {
         margin-left: 50px;
         margin-right: 0
      }

      .header-rtl #Header_creative a.creative-menu-toggle {
         left: 8px;
         right: auto
      }

      .header-rtl #Header_creative .creative-social {
         left: 0;
         right: auto
      }

      .header-rtl #Footer #back_to_top.sticky {
         right: 125px
      }

      .header-rtl #popup_contact {
         right: 70px
      }

      .header-rtl #Header_creative #Top_bar .menu li ul {
         left: auto;
         right: 100%
      }

      .header-rtl #Header_creative #Top_bar .search_wrapper {
         left: auto;
         right: 100%
      }

      .header-rtl .fixed-nav.fixed-nav-prev {
         margin-left: 0 !important
      }

      .header-rtl .fixed-nav.fixed-nav-next {
         margin-right: 50px
      }

      body.header-rtl.header-creative.header-open {
         padding-left: 0;
         padding-right: 250px !important
      }

      .header-rtl.header-open #Header_creative {
         left: auto;
         right: 0
      }

      .header-rtl.header-open #Footer #back_to_top.sticky {
         right: 325px
      }

      .header-rtl.header-open #popup_contact {
         right: 270px
      }

      .header-rtl.header-open .fixed-nav.fixed-nav-next {
         margin-right: 250px
      }

      #Header_creative.active {
         left: -1px
      }

      .header-rtl #Header_creative.active {
         left: auto;
         right: -1px
      }

      #Header_creative.active .creative-wrapper {
         opacity: 1;
         margin: 0
      }

      .header-creative .vc_row[data-vc-full-width] {
         padding-left: 50px
      }

      .header-creative.header-open .vc_row[data-vc-full-width] {
         padding-left: 250px
      }

      .header-open .vc_parallax .vc_parallax-inner {
         left: auto;
         width: calc(100% - 250px)
      }

      .header-open.header-rtl .vc_parallax .vc_parallax-inner {
         left: 0;
         right: auto
      }

      #Header_creative.scroll {
         height: 100%;
         overflow-y: auto
      }

      #Header_creative.scroll:not(.dropdown) .menu li ul {
         display: none !important
      }

      #Header_creative.scroll #Action_bar {
         position: static
      }

      #Header_creative.dropdown {
         outline: none
      }

      #Header_creative.dropdown #Top_bar .menu_wrapper {
         float: left;
         width: 100%
      }

      #Header_creative.dropdown #Top_bar #menu ul li {
         position: relative;
         float: left
      }

      #Header_creative.dropdown #Top_bar #menu ul li a:not(.menu-toggle):after {
         display: none
      }

      #Header_creative.dropdown #Top_bar #menu ul li a span {
         line-height: 38px;
         padding: 0
      }

      #Header_creative.dropdown #Top_bar #menu ul li.submenu .menu-toggle {
         display: block;
         position: absolute;
         right: 0;
         top: 0;
         width: 38px;
         height: 38px;
         line-height: 38px;
         font-size: 26px;
         font-weight: 300;
         text-align: center;
         cursor: pointer;
         color: #444;
         opacity: 0.33;
         z-index: 203
      }

      #Header_creative.dropdown #Top_bar #menu ul li.submenu .menu-toggle:after {
         content: "+";
         position: static
      }

      #Header_creative.dropdown #Top_bar #menu ul li.hover>.menu-toggle:after {
         content: "-"
      }

      #Header_creative.dropdown #Top_bar #menu ul.sub-menu li:not(:last-of-type) a {
         border-bottom: 0
      }

      #Header_creative.dropdown #Top_bar #menu ul.mfn-megamenu li .menu-toggle {
         display: none
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul {
         position: relative !important;
         left: 0 !important;
         top: 0;
         padding: 0;
         margin-left: 0 !important;
         width: auto !important;
         background-image: none
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li {
         width: 100% !important
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li a {
         padding: 0 10px;
         text-align: center
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li a .menu-arrow {
         display: none
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li a span {
         padding: 0
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li a span:after {
         display: none !important
      }

      #Header_creative.dropdown #Top_bar .menu>li>ul.mfn-megamenu a.mfn-megamenu-title {
         text-transform: uppercase;
         font-weight: 400
      }

      #Header_creative.dropdown #Top_bar .menu>li>ul.mfn-megamenu>li>ul {
         display: block !important;
         position: inherit;
         left: auto;
         top: auto
      }

      #Header_creative.dropdown #Top_bar #menu ul li ul li ul {
         border-left: 0 !important;
         padding: 0;
         top: 0
      }

      #Header_creative {
         transition: left .5s ease-in-out, right .5s ease-in-out
      }

      #Header_creative .creative-wrapper {
         transition: opacity .5s ease-in-out, margin 0s ease-in-out .5s
      }

      #Header_creative.active .creative-wrapper {
         transition: opacity .5s ease-in-out, margin 0s ease-in-out
      }
      }

      <blade media|%20only%20screen%20and%20(min-width%3A768px)%20%7B%0D>#Top_bar.is-sticky {
         position: fixed !important;
         width: 100%;
         left: 0;
         top: -60px;
         height: 60px;
         z-index: 701;
         background: #fff;
         opacity: .97;
         -webkit-box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.1);
         -moz-box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.1);
         box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.1)
      }

      .layout-boxed.header-boxed #Top_bar.is-sticky {
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%)
      }

      #Top_bar.is-sticky .top_bar_left,
      #Top_bar.is-sticky .top_bar_right,
      #Top_bar.is-sticky .top_bar_right:before {
         background: none;
         box-shadow: unset
      }

      #Top_bar.is-sticky .logo {
         width: auto;
         margin: 0 30px 0 20px;
         padding: 0
      }

      #Top_bar.is-sticky #logo,
      #Top_bar.is-sticky .custom-logo-link {
         padding: 5px 0 !important;
         height: 50px !important;
         line-height: 50px !important
      }

      .logo-no-sticky-padding #Top_bar.is-sticky #logo {
         height: 60px !important;
         line-height: 60px !important
      }

      #Top_bar.is-sticky #logo img.logo-main {
         display: none
      }

      #Top_bar.is-sticky #logo img.logo-sticky {
         display: inline;
         max-height: 35px
      }

      .logo-sticky-width-auto #Top_bar.is-sticky #logo img.logo-sticky {
         width: auto
      }

      #Top_bar.is-sticky .menu_wrapper {
         clear: none
      }

      #Top_bar.is-sticky .menu_wrapper .menu>li>a {
         padding: 15px 0
      }

      #Top_bar.is-sticky .menu>li>a,
      #Top_bar.is-sticky .menu>li>a span {
         line-height: 30px
      }

      #Top_bar.is-sticky .menu>li>a:after {
         top: auto;
         bottom: -4px
      }

      #Top_bar.is-sticky .menu>li>a span.description {
         display: none
      }

      #Top_bar.is-sticky .secondary_menu_wrapper,
      #Top_bar.is-sticky .banner_wrapper {
         display: none
      }

      .header-overlay #Top_bar.is-sticky {
         display: none
      }

      .sticky-dark #Top_bar.is-sticky,
      .sticky-dark #Top_bar.is-sticky #menu {
         background: rgba(0, 0, 0, .8)
      }

      .sticky-dark #Top_bar.is-sticky .menu>li:not(.current-menu-item)>a {
         color: #fff
      }

      .sticky-dark #Top_bar.is-sticky .top_bar_right .top-bar-right-icon {
         color: rgba(255, 255, 255, .9)
      }

      .sticky-dark #Top_bar.is-sticky .top_bar_right .top-bar-right-icon svg .path {
         stroke: rgba(255, 255, 255, .9)
      }

      .sticky-dark #Top_bar.is-sticky .wpml-languages a.active,
      .sticky-dark #Top_bar.is-sticky .wpml-languages ul.wpml-lang-dropdown {
         background: rgba(0, 0, 0, 0.1);
         border-color: rgba(0, 0, 0, 0.1)
      }

      .sticky-white #Top_bar.is-sticky,
      .sticky-white #Top_bar.is-sticky #menu {
         background: rgba(255, 255, 255, .8)
      }

      .sticky-white #Top_bar.is-sticky .menu>li:not(.current-menu-item)>a {
         color: #222
      }

      .sticky-white #Top_bar.is-sticky .top_bar_right .top-bar-right-icon {
         color: rgba(0, 0, 0, .8)
      }

      .sticky-white #Top_bar.is-sticky .top_bar_right .top-bar-right-icon svg .path {
         stroke: rgba(0, 0, 0, .8)
      }

      .sticky-white #Top_bar.is-sticky .wpml-languages a.active,
      .sticky-white #Top_bar.is-sticky .wpml-languages ul.wpml-lang-dropdown {
         background: rgba(255, 255, 255, 0.1);
         border-color: rgba(0, 0, 0, 0.1)
      }
      }

      <blade media|%20only%20screen%20and%20(max-width%3A1239px)%20%7B%0D>#Top_bar #menu {
         display: none;
         height: auto;
         width: 300px;
         bottom: auto;
         top: 100%;
         right: 1px;
         position: absolute;
         margin: 0
      }

      #Top_bar a.responsive-menu-toggle {
         display: block
      }

      #Top_bar #menu>ul {
         width: 100%;
         float: left
      }

      #Top_bar #menu ul li {
         width: 100%;
         padding-bottom: 0;
         border-right: 0;
         position: relative
      }

      #Top_bar #menu ul li a {
         padding: 0 25px;
         margin: 0;
         display: block;
         height: auto;
         line-height: normal;
         border: none
      }

      #Top_bar #menu ul li a:not(.menu-toggle):after {
         display: none
      }

      #Top_bar #menu ul li a span {
         border: none;
         line-height: 44px;
         display: inline;
         padding: 0
      }

      #Top_bar #menu ul li a span.description {
         margin: 0 0 0 5px
      }

      #Top_bar #menu ul li.submenu .menu-toggle {
         display: block;
         position: absolute;
         right: 15px;
         top: 0;
         width: 44px;
         height: 44px;
         line-height: 44px;
         font-size: 30px;
         font-weight: 300;
         text-align: center;
         cursor: pointer;
         color: #444;
         opacity: 0.33;
         transform: unset
      }

      #Top_bar #menu ul li.submenu .menu-toggle:after {
         content: "+";
         position: static
      }

      #Top_bar #menu ul li.hover>.menu-toggle:after {
         content: "-"
      }

      #Top_bar #menu ul li.hover a {
         border-bottom: 0
      }

      #Top_bar #menu ul li a span:after {
         display: none !important
      }

      #Top_bar #menu ul.mfn-megamenu li .menu-toggle {
         display: none
      }

      .menuo-arrows.keyboard-support #Top_bar .menu>li.submenu>a:not(.menu-toggle):after,
      .menuo-arrows:not(.keyboard-support) #Top_bar .menu>li.submenu>a:not(.menu-toggle)::after {
         display: none !important
      }

      #Top_bar #menu ul li ul {
         position: relative !important;
         left: 0 !important;
         top: 0;
         padding: 0;
         margin-left: 0 !important;
         width: auto !important;
         background-image: none !important;
         box-shadow: 0 0 0 0 transparent !important;
         -webkit-box-shadow: 0 0 0 0 transparent !important
      }

      #Top_bar #menu ul li ul li {
         width: 100% !important
      }

      #Top_bar #menu ul li ul li a {
         padding: 0 20px 0 35px
      }

      #Top_bar #menu ul li ul li a .menu-arrow {
         display: none
      }

      #Top_bar #menu ul li ul li a span {
         padding: 0
      }

      #Top_bar #menu ul li ul li a span:after {
         display: none !important
      }

      #Top_bar .menu>li>ul.mfn-megamenu a.mfn-megamenu-title {
         text-transform: uppercase;
         font-weight: 400
      }

      #Top_bar .menu>li>ul.mfn-megamenu>li>ul {
         display: block !important;
         position: inherit;
         left: auto;
         top: auto
      }

      #Top_bar #menu ul li ul li ul {
         border-left: 0 !important;
         padding: 0;
         top: 0
      }

      #Top_bar #menu ul li ul li ul li a {
         padding: 0 20px 0 45px
      }

      #Header #menu>ul>li.current-menu-item>a,
      #Header #menu>ul>li.current_page_item>a,
      #Header #menu>ul>li.current-menu-parent>a,
      #Header #menu>ul>li.current-page-parent>a,
      #Header #menu>ul>li.current-menu-ancestor>a,
      #Header #menu>ul>li.current_page_ancestor>a {
         background: rgba(0, 0, 0, .02)
      }

      .rtl #Top_bar #menu {
         left: 1px;
         right: auto
      }

      .rtl #Top_bar a.responsive-menu-toggle {
         left: 20px;
         right: auto
      }

      .rtl #Top_bar #menu ul li.submenu .menu-toggle {
         left: 15px;
         right: auto;
         border-left: none;
         border-right: 1px solid #eee;
         transform: unset
      }

      .rtl #Top_bar #menu ul li ul {
         left: auto !important;
         right: 0 !important
      }

      .rtl #Top_bar #menu ul li ul li a {
         padding: 0 30px 0 20px
      }

      .rtl #Top_bar #menu ul li ul li ul li a {
         padding: 0 40px 0 20px
      }

      .header-stack .menu_wrapper a.responsive-menu-toggle {
         position: static !important;
         margin: 11px 0 !important
      }

      .header-stack .menu_wrapper #menu {
         left: 0;
         right: auto
      }

      .rtl.header-stack #Top_bar #menu {
         left: auto;
         right: 0
      }

      .admin-bar #Header_creative {
         top: 32px
      }

      .header-creative.layout-boxed {
         padding-top: 85px
      }

      .header-creative.layout-full-width #Wrapper {
         padding-top: 60px
      }

      #Header_creative {
         position: fixed;
         width: 100%;
         left: 0 !important;
         top: 0;
         z-index: 1001
      }

      #Header_creative .creative-wrapper {
         display: block !important;
         opacity: 1 !important
      }

      #Header_creative .creative-menu-toggle,
      #Header_creative .creative-social {
         display: none !important;
         opacity: 1 !important
      }

      #Header_creative #Top_bar {
         position: static;
         width: 100%
      }

      #Header_creative #Top_bar .one {
         display: flex
      }

      #Header_creative #Top_bar #logo,
      #Header_creative #Top_bar .custom-logo-link {
         height: 50px;
         line-height: 50px;
         padding: 5px 0
      }

      #Header_creative #Top_bar #logo img.logo-sticky {
         max-height: 40px !important
      }

      #Header_creative #logo img.logo-main {
         display: none
      }

      #Header_creative #logo img.logo-sticky {
         display: inline-block
      }

      .logo-no-sticky-padding #Header_creative #Top_bar #logo {
         height: 60px;
         line-height: 60px;
         padding: 0
      }

      .logo-no-sticky-padding #Header_creative #Top_bar #logo img.logo-sticky {
         max-height: 60px !important
      }

      #Header_creative #Action_bar {
         display: none
      }

      #Header_creative #Top_bar .top_bar_right:before {
         content: none
      }

      #Header_creative.scroll {
         overflow: visible !important
      }
      }

      body {
         --mfn-clients-tiles-hover: #6d3579;
         --mfn-icon-box-icon: #6d3579;
         --mfn-sliding-box-bg: #6d3579;
         --mfn-woo-body-color: #626262;
         --mfn-woo-heading-color: #626262;
         --mfn-woo-themecolor: #6d3579;
         --mfn-woo-bg-themecolor: #6d3579;
         --mfn-woo-border-themecolor: #6d3579
      }

      #Header_wrapper,
      #Intro {
         background-color: #f38caa
      }

      #Subheader {
         background-color: rgba(247, 247, 247, 0)
      }

      .header-classic #Action_bar,
      .header-fixed #Action_bar,
      .header-plain #Action_bar,
      .header-split #Action_bar,
      .header-shop #Action_bar,
      .header-shop-split #Action_bar,
      .header-stack #Action_bar {
         background-color: #292b33
      }

      #Sliding-top {
         background-color: #6d3579
      }

      #Sliding-top a.sliding-top-control {
         border-right-color: #6d3579
      }

      #Sliding-top.st-center a.sliding-top-control,
      #Sliding-top.st-left a.sliding-top-control {
         border-top-color: #6d3579
      }

      #Footer {
         background-color: #392946
      }

      .grid .post-item,
      .masonry:not(.tiles) .post-item,
      .photo2 .post .post-desc-wrapper {
         background-color: transparent
      }

      .portfolio_group .portfolio-item .desc {
         background-color: transparent
      }

      .woocommerce ul.products li.product,
      .shop_slider .shop_slider_ul li .item_wrapper .desc {
         background-color: transparent
      }

      body,
      ul.timeline_items,
      .icon_box a .desc,
      .icon_box a:hover .desc,
      .feature_list ul li a,
      .list_item a,
      .list_item a:hover,
      .widget_recent_entries ul li a,
      .flat_box a,
      .flat_box a:hover,
      .story_box .desc,
      .content_slider.carousel ul li a .title,
      .content_slider.flat.description ul li .desc,
      .content_slider.flat.description ul li a .desc,
      .post-nav.minimal a i {
         color: #626262
      }

      .post-nav.minimal a svg {
         fill: #626262
      }

      .themecolor,
      .opening_hours .opening_hours_wrapper li span,
      .fancy_heading_icon .icon_top,
      .fancy_heading_arrows .icon-right-dir,
      .fancy_heading_arrows .icon-left-dir,
      .fancy_heading_line .title,
      .button-love a.mfn-love,
      .format-link .post-title .icon-link,
      .pager-single>span,
      .pager-single a:hover,
      .widget_meta ul,
      .widget_pages ul,
      .widget_rss ul,
      .widget_mfn_recent_comments ul li:after,
      .widget_archive ul,
      .widget_recent_comments ul li:after,
      .widget_nav_menu ul,
      .woocommerce ul.products li.product .price,
      .shop_slider .shop_slider_ul li .item_wrapper .price,
      .woocommerce-page ul.products li.product .price,
      .widget_price_filter .price_label .from,
      .widget_price_filter .price_label .to,
      .woocommerce ul.product_list_widget li .quantity .amount,
      .woocommerce .product div.entry-summary .price,
      .woocommerce .product .woocommerce-variation-price .price,
      .woocommerce .star-rating span,
      #Error_404 .error_pic i,
      .style-simple #Filters .filters_wrapper ul li a:hover,
      .style-simple #Filters .filters_wrapper ul li.current-cat a,
      .style-simple .quick_fact .title,
      .mfn-cart-holder .mfn-ch-content .mfn-ch-product .woocommerce-Price-amount,
      .woocommerce .comment-form-rating p.stars a:before,
      .wishlist .wishlist-row .price,
      .search-results .search-item .post-product-price,
      .progress_icons.transparent .progress_icon.themebg {
         color: #6d3579
      }

      .mfn-wish-button.loved:not(.link) .path {
         fill: #6d3579;
         stroke: #6d3579
      }

      .themebg,
      #comments .commentlist>li .reply a.comment-reply-link,
      #Filters .filters_wrapper ul li a:hover,
      #Filters .filters_wrapper ul li.current-cat a,
      .fixed-nav .arrow,
      .offer_thumb .slider_pagination a:before,
      .offer_thumb .slider_pagination a.selected:after,
      .pager .pages a:hover,
      .pager .pages a.active,
      .pager .pages span.page-numbers.current,
      .pager-single span:after,
      .portfolio_group.exposure .portfolio-item .desc-inner .line,
      .Recent_posts ul li .desc:after,
      .Recent_posts ul li .photo .c,
      .slider_pagination a.selected,
      .slider_pagination .slick-active a,
      .slider_pagination a.selected:after,
      .slider_pagination .slick-active a:after,
      .testimonials_slider .slider_images,
      .testimonials_slider .slider_images a:after,
      .testimonials_slider .slider_images:before,
      #Top_bar .header-cart-count,
      #Top_bar .header-wishlist-count,
      .mfn-footer-stickymenu ul li a .header-wishlist-count,
      .mfn-footer-stickymenu ul li a .header-cart-count,
      .widget_categories ul,
      .widget_mfn_menu ul li a:hover,
      .widget_mfn_menu ul li.current-menu-item:not(.current-menu-ancestor)>a,
      .widget_mfn_menu ul li.current_page_item:not(.current_page_ancestor)>a,
      .widget_product_categories ul,
      .widget_recent_entries ul li:after,
      .woocommerce-account table.my_account_orders .order-number a,
      .woocommerce-MyAccount-navigation ul li.is-active a,
      .style-simple .accordion .question:after,
      .style-simple .faq .question:after,
      .style-simple .icon_box .desc_wrapper .title:before,
      .style-simple #Filters .filters_wrapper ul li a:after,
      .style-simple .trailer_box:hover .desc,
      .tp-bullets.simplebullets.round .bullet.selected,
      .tp-bullets.simplebullets.round .bullet.selected:after,
      .tparrows.default,
      .tp-bullets.tp-thumbs .bullet.selected:after {
         background-color: #6d3579
      }

      .Latest_news ul li .photo,
      .Recent_posts.blog_news ul li .photo,
      .style-simple .opening_hours .opening_hours_wrapper li label,
      .style-simple .timeline_items li:hover h3,
      .style-simple .timeline_items li:nth-child(even):hover h3,
      .style-simple .timeline_items li:hover .desc,
      .style-simple .timeline_items li:nth-child(even):hover,
      .style-simple .offer_thumb .slider_pagination a.selected {
         border-color: #6d3579
      }

      a {
         color: #6d3579
      }

      a:hover {
         color: #6d3579
      }

      *::-moz-selection {
         background-color: #6d3579;
         color: white
      }

      *::selection {
         background-color: #6d3579;
         color: white
      }

      .blockquote p.author span,
      .counter .desc_wrapper .title,
      .article_box .desc_wrapper p,
      .team .desc_wrapper p.subtitle,
      .pricing-box .plan-header p.subtitle,
      .pricing-box .plan-header .price sup.period,
      .chart_box p,
      .fancy_heading .inside,
      .fancy_heading_line .slogan,
      .post-meta,
      .post-meta a,
      .post-footer,
      .post-footer a span.label,
      .pager .pages a,
      .button-love a .label,
      .pager-single a,
      #comments .commentlist>li .comment-author .says,
      .fixed-nav .desc .date,
      .filters_buttons li.label,
      .Recent_posts ul li a .desc .date,
      .widget_recent_entries ul li .post-date,
      .tp_recent_tweets .twitter_time,
      .widget_price_filter .price_label,
      .shop-filters .woocommerce-result-count,
      .woocommerce ul.product_list_widget li .quantity,
      .widget_shopping_cart ul.product_list_widget li dl,
      .product_meta .posted_in,
      .woocommerce .shop_table .product-name .variation>dd,
      .shipping-calculator-button:after,
      .shop_slider .shop_slider_ul li .item_wrapper .price del,
      .woocommerce .product .entry-summary .woocommerce-product-rating .woocommerce-review-link,
      .woocommerce .product.style-default .entry-summary .product_meta .tagged_as,
      .woocommerce .tagged_as,
      .wishlist .sku_wrapper,
      .woocommerce .column_product_rating .woocommerce-review-link,
      .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta .woocommerce-review__verified,
      .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta .woocommerce-review__dash,
      .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta .woocommerce-review__published-date,
      .testimonials_slider .testimonials_slider_ul li .author span,
      .testimonials_slider .testimonials_slider_ul li .author span a,
      .Latest_news ul li .desc_footer,
      .share-simple-wrapper .icons a {
         color: #a8a8a8
      }

      h1,
      h1 a,
      h1 a:hover,
      .text-logo #logo {
         color: #0b0525
      }

      h2,
      h2 a,
      h2 a:hover {
         color: #0b0525
      }

      h3,
      h3 a,
      h3 a:hover {
         color: #0b0525
      }

      h4,
      h4 a,
      h4 a:hover,
      .style-simple .sliding_box .desc_wrapper h4 {
         color: #0b0525
      }

      h5,
      h5 a,
      h5 a:hover {
         color: #0b0525
      }

      h6,
      h6 a,
      h6 a:hover,
      a.content_link .title {
         color: #0b0525
      }

      .woocommerce #customer_login h2 {
         color: #0b0525
      }

      .woocommerce .woocommerce-order-details__title,
      .woocommerce .wc-bacs-bank-details-heading,
      .woocommerce .woocommerce-customer-details h2,
      .woocommerce #respond .comment-reply-title,
      .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta .woocommerce-review__author {
         color: #0b0525
      }

      .dropcap,
      .highlight:not(.highlight_image) {
         background-color: #6d3579
      }

      .button-default .button_theme,
      .button-default button,
      .button-default input[type="button"],
      .button-default input[type="reset"],
      .button-default input[type="submit"],
      .button-flat .button_theme,
      .button-flat button,
      .button-flat input[type="button"],
      .button-flat input[type="reset"],
      .button-flat input[type="submit"],
      .button-round .button_theme,
      .button-round button,
      .button-round input[type="button"],
      .button-round input[type="reset"],
      .button-round input[type="submit"],
      .woocommerce #respond input#submit,
      .woocommerce a.button:not(.default),
      .woocommerce button.button,
      .woocommerce input.button,
      .woocommerce #respond input#submit:hover,
      .woocommerce a.button:not(.default):hover,
      .woocommerce button.button:hover,
      .woocommerce input.button:hover {
         background-color: #6d3579
      }

      .button-stroke .button_theme,
      .button-stroke .button_theme .button_icon i,
      .button-stroke button,
      .button-stroke input[type="submit"],
      .button-stroke input[type="reset"],
      .button-stroke input[type="button"],
      .button-stroke .woocommerce #respond input#submit,
      .button-stroke .woocommerce a.button:not(.default),
      .button-stroke .woocommerce button.button,
      .button-stroke.woocommerce input.button {
         border-color: #6d3579;
         color: #6d3579
      }

      .button-stroke .button_theme:hover,
      .button-stroke button:hover,
      .button-stroke input[type="submit"]:hover,
      .button-stroke input[type="reset"]:hover,
      .button-stroke input[type="button"]:hover {
         background-color: #6d3579;
         color: white
      }

      .button-default .single_add_to_cart_button,
      .button-flat .single_add_to_cart_button,
      .button-round .single_add_to_cart_button,
      .button-default .woocommerce .button:disabled,
      .button-flat .woocommerce .button:disabled,
      .button-round .woocommerce .button:disabled,
      .button-default .woocommerce .button.alt,
      .button-flat .woocommerce .button.alt,
      .button-round .woocommerce .button.alt {
         background-color: #6d3579
      }

      .button-stroke .single_add_to_cart_button:hover,
      .button-stroke #place_order:hover {
         background-color: #6d3579
      }

      a.mfn-link {
         color: #656B6F
      }

      a.mfn-link-2 span,
      a:hover.mfn-link-2 span:before,
      a.hover.mfn-link-2 span:before,
      a.mfn-link-5 span,
      a.mfn-link-8:after,
      a.mfn-link-8:before {
         background: #6d3579
      }

      a:hover.mfn-link {
         color: #6d3579
      }

      a.mfn-link-2 span:before,
      a:hover.mfn-link-4:before,
      a:hover.mfn-link-4:after,
      a.hover.mfn-link-4:before,
      a.hover.mfn-link-4:after,
      a.mfn-link-5:before,
      a.mfn-link-7:after,
      a.mfn-link-7:before {
         background: #6d3579
      }

      a.mfn-link-6:before {
         border-bottom-color: #6d3579
      }

      a.mfn-link svg .path {
         stroke: #6d3579
      }

      .column_column ul,
      .column_column ol,
      .the_content_wrapper:not(.is-elementor) ul,
      .the_content_wrapper:not(.is-elementor) ol {
         color: #737E86
      }

      hr.hr_color,
      .hr_color hr,
      .hr_dots span {
         color: #6d3579;
         background: #6d3579
      }

      .hr_zigzag i {
         color: #6d3579
      }

      .highlight-left:after,
      .highlight-right:after {
         background: #6d3579
      }

      <blade media|%20only%20screen%20and%20(max-width%3A767px)%20%7B%0D>.highlight-left .wrap:first-child,
      .highlight-right .wrap:last-child {
         background: #6d3579
      }
      }

      #Header .top_bar_left,
      .header-classic #Top_bar,
      .header-plain #Top_bar,
      .header-stack #Top_bar,
      .header-split #Top_bar,
      .header-shop #Top_bar,
      .header-shop-split #Top_bar,
      .header-fixed #Top_bar,
      .header-below #Top_bar,
      #Header_creative,
      #Top_bar #menu,
      .sticky-tb-color #Top_bar.is-sticky {
         background-color: #281e36
      }

      #Top_bar .wpml-languages a.active,
      #Top_bar .wpml-languages ul.wpml-lang-dropdown {
         background-color: #281e36
      }

      #Top_bar .top_bar_right:before {
         background-color: #e3e3e3
      }

      #Header .top_bar_right {
         background-color: #f5f5f5
      }

      #Top_bar .top_bar_right .top-bar-right-icon,
      #Top_bar .top_bar_right .top-bar-right-icon svg .path {
         color: #333333;
         stroke: #333333
      }

      #Top_bar .menu>li>a,
      #Top_bar #menu ul li.submenu .menu-toggle {
         color: #ffffff
      }

      #Top_bar .menu>li.current-menu-item>a,
      #Top_bar .menu>li.current_page_item>a,
      #Top_bar .menu>li.current-menu-parent>a,
      #Top_bar .menu>li.current-page-parent>a,
      #Top_bar .menu>li.current-menu-ancestor>a,
      #Top_bar .menu>li.current-page-ancestor>a,
      #Top_bar .menu>li.current_page_ancestor>a,
      #Top_bar .menu>li.hover>a {
         color: #f38caa
      }

      #Top_bar .menu>li a:not(.menu-toggle):after {
         background: #f38caa
      }

      .menuo-arrows #Top_bar .menu>li.submenu>a>span:not(.description)::after {
         border-top-color: #ffffff
      }

      #Top_bar .menu>li.current-menu-item.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current_page_item.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current-menu-parent.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current-page-parent.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current-menu-ancestor.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current-page-ancestor.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.current_page_ancestor.submenu>a>span:not(.description)::after,
      #Top_bar .menu>li.hover.submenu>a>span:not(.description)::after {
         border-top-color: #f38caa
      }

      .menu-highlight #Top_bar #menu>ul>li.current-menu-item>a,
      .menu-highlight #Top_bar #menu>ul>li.current_page_item>a,
      .menu-highlight #Top_bar #menu>ul>li.current-menu-parent>a,
      .menu-highlight #Top_bar #menu>ul>li.current-page-parent>a,
      .menu-highlight #Top_bar #menu>ul>li.current-menu-ancestor>a,
      .menu-highlight #Top_bar #menu>ul>li.current-page-ancestor>a,
      .menu-highlight #Top_bar #menu>ul>li.current_page_ancestor>a,
      .menu-highlight #Top_bar #menu>ul>li.hover>a {
         background: #F2F2F2
      }

      .menu-arrow-bottom #Top_bar .menu>li>a:after {
         border-bottom-color: #f38caa
      }

      .menu-arrow-top #Top_bar .menu>li>a:after {
         border-top-color: #f38caa
      }

      .header-plain #Top_bar .menu>li.current-menu-item>a,
      .header-plain #Top_bar .menu>li.current_page_item>a,
      .header-plain #Top_bar .menu>li.current-menu-parent>a,
      .header-plain #Top_bar .menu>li.current-page-parent>a,
      .header-plain #Top_bar .menu>li.current-menu-ancestor>a,
      .header-plain #Top_bar .menu>li.current-page-ancestor>a,
      .header-plain #Top_bar .menu>li.current_page_ancestor>a,
      .header-plain #Top_bar .menu>li.hover>a,
      .header-plain #Top_bar .wpml-languages:hover,
      .header-plain #Top_bar .wpml-languages ul.wpml-lang-dropdown {
         background: #F2F2F2;
         color: #f38caa
      }

      .header-plain #Top_bar .top_bar_right .top-bar-right-icon:hover {
         background: #F2F2F2
      }

      .header-plain #Top_bar,
      .header-plain #Top_bar .menu>li>a span:not(.description),
      .header-plain #Top_bar .top_bar_right .top-bar-right-icon,
      .header-plain #Top_bar .top_bar_right .top-bar-right-button,
      .header-plain #Top_bar .top_bar_right .top-bar-right-input,
      .header-plain #Top_bar .wpml-languages {
         border-color: #f2f2f2
      }

      #Top_bar .menu>li ul {
         background-color: #F2F2F2
      }

      #Top_bar .menu>li ul li a {
         color: #5f5f5f
      }

      #Top_bar .menu>li ul li a:hover,
      #Top_bar .menu>li ul li.hover>a {
         color: #2e2e2e
      }

      .overlay-menu-toggle {
         color: #6d3579 !important;
         background: transparent
      }

      #Overlay {
         background: rgba(1, 205, 97, 0.95)
      }

      #overlay-menu ul li a,
      .header-overlay .overlay-menu-toggle.focus {
         color: #dce9e0
      }

      #overlay-menu ul li.current-menu-item>a,
      #overlay-menu ul li.current_page_item>a,
      #overlay-menu ul li.current-menu-parent>a,
      #overlay-menu ul li.current-page-parent>a,
      #overlay-menu ul li.current-menu-ancestor>a,
      #overlay-menu ul li.current-page-ancestor>a,
      #overlay-menu ul li.current_page_ancestor>a {
         color: #ffffff
      }

      #Top_bar .responsive-menu-toggle,
      #Header_creative .creative-menu-toggle,
      #Header_creative .responsive-menu-toggle {
         color: #6d3579;
         background: transparent
      }

      .mfn-footer-stickymenu {
         background-color: #281e36
      }

      .mfn-footer-stickymenu ul li a,
      .mfn-footer-stickymenu ul li a .path {
         color: #333333;
         stroke: #333333
      }

      #Side_slide {
         background-color: #191919;
         border-color: #191919
      }

      #Side_slide,
      #Side_slide #menu ul li.submenu .menu-toggle,
      #Side_slide .search-wrapper input.field,
      #Side_slide a:not(.action_button) {
         color: #A6A6A6
      }

      #Side_slide .extras .extras-wrapper a svg .path {
         stroke: #A6A6A6
      }

      #Side_slide #menu ul li.hover>.menu-toggle,
      #Side_slide a.active,
      #Side_slide a:not(.action_button):hover {
         color: #FFFFFF
      }

      #Side_slide .extras .extras-wrapper a:hover svg .path {
         stroke: #FFFFFF
      }

      #Side_slide #menu ul li.current-menu-item>a,
      #Side_slide #menu ul li.current_page_item>a,
      #Side_slide #menu ul li.current-menu-parent>a,
      #Side_slide #menu ul li.current-page-parent>a,
      #Side_slide #menu ul li.current-menu-ancestor>a,
      #Side_slide #menu ul li.current-page-ancestor>a,
      #Side_slide #menu ul li.current_page_ancestor>a,
      #Side_slide #menu ul li.hover>a,
      #Side_slide #menu ul li:hover>a {
         color: #FFFFFF
      }

      #Action_bar .contact_details {
         color: #bbbbbb
      }

      #Action_bar .contact_details a {
         color: #6d3579
      }

      #Action_bar .contact_details a:hover {
         color: #6d3579
      }

      #Action_bar .social li a,
      #Header_creative .social li a,
      #Action_bar:not(.creative) .social-menu a {
         color: #bbbbbb
      }

      #Action_bar .social li a:hover,
      #Header_creative .social li a:hover,
      #Action_bar:not(.creative) .social-menu a:hover {
         color: #FFFFFF
      }

      #Subheader .title {
         color: #000000
      }

      #Subheader ul.breadcrumbs li,
      #Subheader ul.breadcrumbs li a {
         color: rgba(0, 0, 0, 0.6)
      }

      .mfn-footer,
      .mfn-footer .widget_recent_entries ul li a {
         color: #cccccc
      }

      .mfn-footer a:not(.button, .icon_bar, .mfn-btn, .mfn-option-btn) {
         color: #ffffff
      }

      .mfn-footer a:not(.button, .icon_bar, .mfn-btn, .mfn-option-btn):hover {
         color: #6d3579
      }

      .mfn-footer h1,
      .mfn-footer h1 a,
      .mfn-footer h1 a:hover,
      .mfn-footer h2,
      .mfn-footer h2 a,
      .mfn-footer h2 a:hover,
      .mfn-footer h3,
      .mfn-footer h3 a,
      .mfn-footer h3 a:hover,
      .mfn-footer h4,
      .mfn-footer h4 a,
      .mfn-footer h4 a:hover,
      .mfn-footer h5,
      .mfn-footer h5 a,
      .mfn-footer h5 a:hover,
      .mfn-footer h6,
      .mfn-footer h6 a,
      .mfn-footer h6 a:hover {
         color: #ffffff
      }

      .mfn-footer .themecolor,
      .mfn-footer .widget_meta ul,
      .mfn-footer .widget_pages ul,
      .mfn-footer .widget_rss ul,
      .mfn-footer .widget_mfn_recent_comments ul li:after,
      .mfn-footer .widget_archive ul,
      .mfn-footer .widget_recent_comments ul li:after,
      .mfn-footer .widget_nav_menu ul,
      .mfn-footer .widget_price_filter .price_label .from,
      .mfn-footer .widget_price_filter .price_label .to,
      .mfn-footer .star-rating span {
         color: #6d3579
      }

      .mfn-footer .themebg,
      .mfn-footer .widget_categories ul,
      .mfn-footer .Recent_posts ul li .desc:after,
      .mfn-footer .Recent_posts ul li .photo .c,
      .mfn-footer .widget_recent_entries ul li:after,
      .mfn-footer .widget_mfn_menu ul li a:hover,
      .mfn-footer .widget_product_categories ul {
         background-color: #6d3579
      }

      .mfn-footer .Recent_posts ul li a .desc .date,
      .mfn-footer .widget_recent_entries ul li .post-date,
      .mfn-footer .tp_recent_tweets .twitter_time,
      .mfn-footer .widget_price_filter .price_label,
      .mfn-footer .shop-filters .woocommerce-result-count,
      .mfn-footer ul.product_list_widget li .quantity,
      .mfn-footer .widget_shopping_cart ul.product_list_widget li dl {
         color: #a8a8a8
      }

      .mfn-footer .footer_copy .social li a,
      .mfn-footer .footer_copy .social-menu a {
         color: #65666C
      }

      .mfn-footer .footer_copy .social li a:hover,
      .mfn-footer .footer_copy .social-menu a:hover {
         color: #FFFFFF
      }

      .mfn-footer .footer_copy {
         border-top-color: rgba(255, 255, 255, 0.1)
      }

      #Sliding-top,
      #Sliding-top .widget_recent_entries ul li a {
         color: #cccccc
      }

      #Sliding-top a {
         color: #6d3579
      }

      #Sliding-top a:hover {
         color: #6d3579
      }

      #Sliding-top h1,
      #Sliding-top h1 a,
      #Sliding-top h1 a:hover,
      #Sliding-top h2,
      #Sliding-top h2 a,
      #Sliding-top h2 a:hover,
      #Sliding-top h3,
      #Sliding-top h3 a,
      #Sliding-top h3 a:hover,
      #Sliding-top h4,
      #Sliding-top h4 a,
      #Sliding-top h4 a:hover,
      #Sliding-top h5,
      #Sliding-top h5 a,
      #Sliding-top h5 a:hover,
      #Sliding-top h6,
      #Sliding-top h6 a,
      #Sliding-top h6 a:hover {
         color: #ffffff
      }

      #Sliding-top .themecolor,
      #Sliding-top .widget_meta ul,
      #Sliding-top .widget_pages ul,
      #Sliding-top .widget_rss ul,
      #Sliding-top .widget_mfn_recent_comments ul li:after,
      #Sliding-top .widget_archive ul,
      #Sliding-top .widget_recent_comments ul li:after,
      #Sliding-top .widget_nav_menu ul,
      #Sliding-top .widget_price_filter .price_label .from,
      #Sliding-top .widget_price_filter .price_label .to,
      #Sliding-top .star-rating span {
         color: #6d3579
      }

      #Sliding-top .themebg,
      #Sliding-top .widget_categories ul,
      #Sliding-top .Recent_posts ul li .desc:after,
      #Sliding-top .Recent_posts ul li .photo .c,
      #Sliding-top .widget_recent_entries ul li:after,
      #Sliding-top .widget_mfn_menu ul li a:hover,
      #Sliding-top .widget_product_categories ul {
         background-color: #6d3579
      }

      #Sliding-top .Recent_posts ul li a .desc .date,
      #Sliding-top .widget_recent_entries ul li .post-date,
      #Sliding-top .tp_recent_tweets .twitter_time,
      #Sliding-top .widget_price_filter .price_label,
      #Sliding-top .shop-filters .woocommerce-result-count,
      #Sliding-top ul.product_list_widget li .quantity,
      #Sliding-top .widget_shopping_cart ul.product_list_widget li dl {
         color: #a8a8a8
      }

      blockquote,
      blockquote a,
      blockquote a:hover {
         color: #444444
      }

      .portfolio_group.masonry-hover .portfolio-item .masonry-hover-wrapper .hover-desc,
      .masonry.tiles .post-item .post-desc-wrapper .post-desc .post-title:after,
      .masonry.tiles .post-item.no-img,
      .masonry.tiles .post-item.format-quote,
      .blog-teaser li .desc-wrapper .desc .post-title:after,
      .blog-teaser li.no-img,
      .blog-teaser li.format-quote {
         background: #ffffff
      }

      .image_frame .image_wrapper .image_links a {
         background: #ffffff;
         color: #161922;
         border-color: #ffffff
      }

      .image_frame .image_wrapper .image_links a.loading:after {
         border-color: #161922
      }

      .image_frame .image_wrapper .image_links a .path {
         stroke: #161922
      }

      .image_frame .image_wrapper .image_links a.mfn-wish-button.loved .path {
         fill: #161922;
         stroke: #161922
      }

      .image_frame .image_wrapper .image_links a.mfn-wish-button.loved:hover .path {
         fill: #0089f7;
         stroke: #0089f7
      }

      .image_frame .image_wrapper .image_links a:hover {
         background: #ffffff;
         color: #0089f7;
         border-color: #ffffff
      }

      .image_frame .image_wrapper .image_links a:hover .path {
         stroke: #0089f7
      }

      .image_frame {
         border-color: #f8f8f8
      }

      .image_frame .image_wrapper .mask::after {
         background: rgba(0, 0, 0, 0.15)
      }

      .counter .icon_wrapper i {
         color: #6d3579
      }

      .quick_fact .number-wrapper .number {
         color: #6d3579
      }

      .progress_bars .bars_list li .bar .progress {
         background-color: #6d3579
      }

      a:hover.icon_bar {
         color: #6d3579 !important
      }

      a.content_link,
      a:hover.content_link {
         color: #6d3579
      }

      a.content_link:before {
         border-bottom-color: #6d3579
      }

      a.content_link:after {
         border-color: #6d3579
      }

      .mcb-item-contact_box-inner,
      .mcb-item-info_box-inner,
      .column_column .get_in_touch,
      .google-map-contact-wrapper {
         background-color: #6d3579
      }

      .google-map-contact-wrapper .get_in_touch:after {
         border-top-color: #6d3579
      }

      .timeline_items li h3:before,
      .timeline_items:after,
      .timeline .post-item:before {
         border-color: #6d3579
      }

      .how_it_works .image_wrapper .number {
         background: #6d3579
      }

      .trailer_box .desc .subtitle,
      .trailer_box.plain .desc .line {
         background-color: #6d3579
      }

      .trailer_box.plain .desc .subtitle {
         color: #6d3579
      }

      .icon_box .icon_wrapper,
      .icon_box a .icon_wrapper,
      .style-simple .icon_box:hover .icon_wrapper {
         color: #6d3579
      }

      .icon_box:hover .icon_wrapper:before,
      .icon_box a:hover .icon_wrapper:before {
         background-color: #6d3579
      }

      .list_item.lists_1 .list_left {
         background-color: #6d3579
      }

      .list_item .list_left {
         color: #6d3579
      }

      .feature_list ul li .icon i {
         color: #6d3579
      }

      .feature_list ul li:hover,
      .feature_list ul li:hover a {
         background: #6d3579
      }

      .ui-tabs .ui-tabs-nav li a,
      .accordion .question>.title,
      .faq .question>.title,
      table th,
      .fake-tabs>ul li a {
         color: #444444
      }

      .ui-tabs .ui-tabs-nav li.ui-state-active a,
      .accordion .question.active>.title>.acc-icon-plus,
      .accordion .question.active>.title>.acc-icon-minus,
      .accordion .question.active>.title,
      .faq .question.active>.title>.acc-icon-plus,
      .faq .question.active>.title,
      .fake-tabs>ul li.active a {
         color: #6d3579
      }

      .ui-tabs .ui-tabs-nav li.ui-state-active a:after,
      .fake-tabs>ul li a:after,
      .fake-tabs>ul li a .number {
         background: #6d3579
      }

      body.table-hover:not(.woocommerce-page) table tr:hover td {
         background: #6d3579
      }

      .pricing-box .plan-header .price sup.currency,
      .pricing-box .plan-header .price>span {
         color: #6d3579
      }

      .pricing-box .plan-inside ul li .yes {
         background: #6d3579
      }

      .pricing-box-box.pricing-box-featured {
         background: #6d3579
      }

      .alert_warning {
         background: #fef8ea
      }

      .alert_warning,
      .alert_warning a,
      .alert_warning a:hover,
      .alert_warning a.close .icon {
         color: #8a5b20
      }

      .alert_warning .path {
         stroke: #8a5b20
      }

      .alert_error {
         background: #fae9e8
      }

      .alert_error,
      .alert_error a,
      .alert_error a:hover,
      .alert_error a.close .icon {
         color: #962317
      }

      .alert_error .path {
         stroke: #962317
      }

      .alert_info {
         background: #efefef
      }

      .alert_info,
      .alert_info a,
      .alert_info a:hover,
      .alert_info a.close .icon {
         color: #57575b
      }

      .alert_info .path {
         stroke: #57575b
      }

      .alert_success {
         background: #eaf8ef
      }

      .alert_success,
      .alert_success a,
      .alert_success a:hover,
      .alert_success a.close .icon {
         color: #6d3579
      }

      .alert_success .path {
         stroke: #6d3579
      }

      input[type="date"],
      input[type="email"],
      input[type="number"],
      input[type="password"],
      input[type="search"],
      input[type="tel"],
      input[type="text"],
      input[type="url"],
      select,
      textarea,
      .woocommerce .quantity input.qty,
      .wp-block-search input[type="search"],
      .dark input[type="email"],
      .dark input[type="password"],
      .dark input[type="tel"],
      .dark input[type="text"],
      .dark select,
      .dark textarea {
         color: #626262;
         background-color: rgba(255, 255, 255, 1);
         border-color: #EBEBEB
      }

      .wc-block-price-filter__controls input {
         border-color: #EBEBEB !important
      }

      ::-webkit-input-placeholder {
         color: #929292
      }

      ::-moz-placeholder {
         color: #929292
      }

      :-ms-input-placeholder {
         color: #929292
      }

      input[type="date"]:focus,
      input[type="email"]:focus,
      input[type="number"]:focus,
      input[type="password"]:focus,
      input[type="search"]:focus,
      input[type="tel"]:focus,
      input[type="text"]:focus,
      input[type="url"]:focus,
      select:focus,
      textarea:focus {
         color: #1982c2;
         background-color: rgba(233, 245, 252, 1);
         border-color: #d5e5ee
      }

      .wc-block-price-filter__controls input:focus {
         border-color: #d5e5ee !important
      }

      select:focus {
         background-color: #e9f5fc !important
      }

      :focus::-webkit-input-placeholder {
         color: #929292
      }

      :focus::-moz-placeholder {
         color: #929292
      }

      .select2-container--default .select2-selection--single {
         background-color: rgba(255, 255, 255, 1);
         border-color: #EBEBEB
      }

      .select2-dropdown {
         background-color: #FFFFFF;
         border-color: #EBEBEB
      }

      .select2-container--default .select2-selection--single .select2-selection__rendered {
         color: #626262
      }

      .select2-container--default.select2-container--open .select2-selection--single {
         border-color: #EBEBEB
      }

      .select2-container--default .select2-search--dropdown .select2-search__field {
         color: #626262;
         background-color: rgba(255, 255, 255, 1);
         border-color: #EBEBEB
      }

      .select2-container--default .select2-search--dropdown .select2-search__field:focus {
         color: #1982c2;
         background-color: rgba(233, 245, 252, 1) !important;
         border-color: #d5e5ee
      }

      .select2-container--default .select2-results__option[data-selected="true"],
      .select2-container--default .select2-results__option--highlighted[data-selected] {
         background-color: #6d3579;
         color: white
      }

      .woocommerce span.onsale,
      .shop_slider .shop_slider_ul li .item_wrapper span.onsale {
         background-color: #6d3579
      }

      .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
         border-color: #6d3579 !important
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__wrapper .zoomImg {
         background-color: #ffffff
      }

      .mfn-wish-button .path {
         stroke: rgba(0, 0, 0, 0.15)
      }

      .mfn-wish-button:hover .path {
         stroke: rgba(0, 0, 0, 0.3)
      }

      .mfn-wish-button.loved:not(.link) .path {
         stroke: rgba(0, 0, 0, 0.3);
         fill: rgba(0, 0, 0, 0.3)
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger,
      .woocommerce div.product div.images .mfn-wish-button,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger,
      .woocommerce .mfn-product-gallery-grid .mfn-wish-button {
         background-color: #ffffff
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger:hover,
      .woocommerce div.product div.images .mfn-wish-button:hover,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger:hover,
      .woocommerce .mfn-product-gallery-grid .mfn-wish-button:hover {
         background-color: #ffffff
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger:before,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger:before {
         border-color: #161922
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger:after,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger:after {
         background-color: #161922
      }

      .woocommerce div.product div.images .mfn-wish-button path,
      .woocommerce .mfn-product-gallery-grid .mfn-wish-button path {
         stroke: #161922
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger:hover:before,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger:hover:before {
         border-color: #0089f7
      }

      .woocommerce div.product div.images .woocommerce-product-gallery__trigger:hover:after,
      .woocommerce .mfn-product-gallery-grid .woocommerce-product-gallery__trigger:hover:after {
         background-color: #0089f7
      }

      .woocommerce div.product div.images .mfn-wish-button:hover path,
      .woocommerce .mfn-product-gallery-grid .mfn-wish-button:hover path {
         stroke: #0089f7
      }

      .woocommerce div.product div.images .mfn-wish-button.loved path,
      .woocommerce .mfn-product-gallery-grid .mfn-wish-button.loved path {
         stroke: #0089f7;
         fill: #0089f7
      }

      #mfn-gdpr {
         background-color: #eef2f5;
         border-radius: 5px;
         box-shadow: 0 15px 30px 0 rgba(1, 7, 39, .13)
      }

      #mfn-gdpr .mfn-gdpr-content,
      #mfn-gdpr .mfn-gdpr-content h1,
      #mfn-gdpr .mfn-gdpr-content h2,
      #mfn-gdpr .mfn-gdpr-content h3,
      #mfn-gdpr .mfn-gdpr-content h4,
      #mfn-gdpr .mfn-gdpr-content h5,
      #mfn-gdpr .mfn-gdpr-content h6,
      #mfn-gdpr .mfn-gdpr-content ol,
      #mfn-gdpr .mfn-gdpr-content ul {
         color: #626262
      }

      #mfn-gdpr .mfn-gdpr-content a,
      #mfn-gdpr a.mfn-gdpr-readmore {
         color: #161922
      }

      #mfn-gdpr .mfn-gdpr-content a:hover,
      #mfn-gdpr a.mfn-gdpr-readmore:hover {
         color: #0089f7
      }

      #mfn-gdpr .mfn-gdpr-button {
         background-color: #006edf;
         color: #ffffff;
         border-color: transparent
      }

      #mfn-gdpr .mfn-gdpr-button:hover {
         background-color: #0089f7;
         color: #ffffff;
         border-color: transparent
      }

      <blade media|%20only%20screen%20and%20(min-width%3A768px)%20%7B%0D>.header-semi #Top_bar:not(.is-sticky) {
         background-color: rgba(40, 30, 54, 0.8)
      }
      }

      <blade media|%20only%20screen%20and%20(max-width%3A767px)%20%7B%0D>#Top_bar {
         background-color: #281e36 !important
      }

      #Action_bar {
         background-color: #FFFFFF !important
      }

      #Action_bar .contact_details {
         color: #222222
      }

      #Action_bar .contact_details a {
         color: #6d3579
      }

      #Action_bar .contact_details a:hover {
         color: #6d3579
      }

      #Action_bar .social li a,
      #Action_bar .social-menu a {
         color: #bbbbbb !important
      }

      #Action_bar .social li a:hover,
      #Action_bar .social-menu a:hover {
         color: #777777 !important
      }
      }

      form input.display-none {
         display: none !important
      }
   </style>
   <style id="mfn-custom-inline-css" type="text/css">
      .logo {
         float: left !important;
      }

      .top_bar_right {
         display: none;
      }

      #Top_bar .menu>li>a span:not(.description) {
         padding: 0 12px;
      }

      .noptin-styles-basic {
         margin: 1em 0px;
      }

      li#menu-item-294 span {
         padding: 0px 9px !important;
      }

      img.scale-with-grid.wp-post-image {
         border: solid 1px !important;
      }
   </style>
   <script type="text/javascript" src="assets_web/EVA_files/jquery.min.js.download" id="jquery-core-js"></script>
   <script type="text/javascript" src="assets_web/EVA_files/jquery-migrate.min.js.download" id="jquery-migrate-js">
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/jquery.blockUI.min.js.download" id="jquery-blockui-js"
      defer="defer" data-wp-strategy="defer"></script>
   <script type="text/javascript" src="assets_web/EVA_files/add-to-cart.min.js.download" id="wc-add-to-cart-js"
      defer="defer" data-wp-strategy="defer"></script>
   <script type="text/javascript" src="assets_web/EVA_files/js.cookie.min.js.download" id="js-cookie-js" defer="defer"
      data-wp-strategy="defer"></script>
   <script type="text/javascript" src="assets_web/EVA_files/woocommerce.min.js.download" id="woocommerce-js"
      defer="defer" data-wp-strategy="defer"></script>
   <script type="text/javascript" src="assets_web/EVA_files/spin.min.js.download" id="bookly-spin.min.js-js"></script>
   <script type="text/javascript" id="bookly-globals-js-extra">
      /* <![CDATA[ */
      var BooklyL10nGlobal = {
         "csrf_token": "bc9b23705e",
         "ajax_url_backend": "https:\/\/evaclinics.com.sa\/wp-admin\/admin-ajax.php",
         "ajax_url_frontend": "https:\/\/evaclinics.com.sa\/wp-admin\/admin-ajax.php",
         "mjsTimeFormat": "h:mm a",
         "datePicker": {
            "format": "MMMM D, YYYY",
            "monthNames": ["\u064a\u0646\u0627\u064a\u0631", "\u0641\u0628\u0631\u0627\u064a\u0631",
               "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064a\u0644", "\u0645\u0627\u064a\u0648",
               "\u064a\u0648\u0646\u064a\u0648", "\u064a\u0648\u0644\u064a\u0648",
               "\u0623\u063a\u0633\u0637\u0633", "\u0633\u0628\u062a\u0645\u0628\u0631",
               "\u0623\u0643\u062a\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631",
               "\u062f\u064a\u0633\u0645\u0628\u0631"
            ],
            "daysOfWeek": ["\u0627\u0644\u0623\u062d\u062f", "\u0627\u0644\u0623\u062b\u0646\u064a\u0646",
               "\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621",
               "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621", "\u0627\u0644\u062e\u0645\u064a\u0633",
               "\u0627\u0644\u062c\u0645\u0639\u0629", "\u0627\u0644\u0633\u0628\u062a"
            ],
            "firstDay": 1,
            "monthNamesShort": ["\u064a\u0646\u0627\u064a\u0631", "\u0641\u0628\u0631\u0627\u064a\u0631",
               "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064a\u0644", "\u0645\u0627\u064a\u0648",
               "\u064a\u0648\u0646\u064a\u0648", "\u064a\u0648\u0644\u064a\u0648",
               "\u0623\u063a\u0633\u0637\u0633", "\u0633\u0628\u062a\u0645\u0628\u0631",
               "\u0623\u0643\u062a\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631",
               "\u062f\u064a\u0633\u0645\u0628\u0631"
            ],
            "dayNames": ["\u0627\u0644\u0623\u062d\u062f", "\u0627\u0644\u0625\u062b\u0646\u064a\u0646",
               "\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621",
               "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621", "\u0627\u0644\u062e\u0645\u064a\u0633",
               "\u0627\u0644\u062c\u0645\u0639\u0629", "\u0627\u0644\u0633\u0628\u062a"
            ],
            "dayNamesShort": ["\u0627\u0644\u0623\u062d\u062f", "\u0627\u0644\u0623\u062b\u0646\u064a\u0646",
               "\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621",
               "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621", "\u0627\u0644\u062e\u0645\u064a\u0633",
               "\u0627\u0644\u062c\u0645\u0639\u0629", "\u0627\u0644\u0633\u0628\u062a"
            ],
            "meridiem": {
               "am": "\u0635",
               "pm": "\u0645",
               "AM": "\u0635\u0628\u0627\u062d\u064b\u0627",
               "PM": "\u0645\u0633\u0627\u0621\u064b"
            },
            "direction": "rtl"
         },
         "dateRange": {
            "format": "MMMM D, YYYY",
            "applyLabel": "\u062a\u0637\u0628\u064a\u0642",
            "cancelLabel": "\u0625\u0644\u063a\u0627\u0621",
            "fromLabel": "\u0645\u0646",
            "toLabel": "\u0627\u0644\u0649",
            "customRangeLabel": "\u0646\u0637\u0627\u0642 \u0645\u062e\u0635\u0635",
            "tomorrow": "\u063a\u062f\u0627\u064b",
            "today": "\u0627\u0644\u064a\u0648\u0645",
            "anyTime": "\u0641\u064a \u0627\u064a \u0648\u0642\u062a",
            "yesterday": "\u0623\u0645\u0633",
            "last_7": "\u0627\u062e\u0631 7 \u0627\u064a\u0627\u0645",
            "last_30": "\u0622\u062e\u0631 30 \u064a\u0648\u0645\u064b\u0627",
            "next_7": "Next 7 days",
            "next_30": "Next 30 days",
            "thisMonth": "\u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631",
            "nextMonth": "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u0642\u0627\u062f\u0645",
            "lastMonth": "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u0645\u0627\u0636\u064a",
            "firstDay": 1
         },
         "l10n": {
            "apply": "\u062a\u0637\u0628\u064a\u0642",
            "cancel": "\u0625\u0644\u063a\u0627\u0621",
            "areYouSure": "\u0647\u0644 \u0623\u0646\u062a \u0645\u062a\u0623\u0643\u062f\u061f\n"
         },
         "addons": ["pro"],
         "cloud_products": "",
         "data": {}
      };
      /* ]]> */
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/ladda.min.js.download" id="bookly-ladda.min.js-js"></script>
   <script type="text/javascript" src="assets_web/EVA_files/moment.min.js.download" id="bookly-moment.min.js-js">
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/hammer.min.js.download" id="bookly-hammer.min.js-js">
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/jquery.hammer.min.js.download"
      id="bookly-jquery.hammer.min.js-js"></script>
   <script type="text/javascript" src="assets_web/EVA_files/qrcode.js.download" id="bookly-qrcode.js-js"></script>
   <script type="text/javascript" id="bookly-bookly.min.js-js-extra">
      /* <![CDATA[ */
      var BooklyL10n = {
         "ajaxurl": "https:\/\/evaclinics.com.sa\/wp-admin\/admin-ajax.php",
         "csrf_token": "bc9b23705e",
         "months": ["\u064a\u0646\u0627\u064a\u0631", "\u0641\u0628\u0631\u0627\u064a\u0631",
            "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064a\u0644", "\u0645\u0627\u064a\u0648",
            "\u064a\u0648\u0646\u064a\u0648", "\u064a\u0648\u0644\u064a\u0648",
            "\u0623\u063a\u0633\u0637\u0633", "\u0633\u0628\u062a\u0645\u0628\u0631",
            "\u0623\u0643\u062a\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631",
            "\u062f\u064a\u0633\u0645\u0628\u0631"
         ],
         "days": ["\u0627\u0644\u0623\u062d\u062f", "\u0627\u0644\u0625\u062b\u0646\u064a\u0646",
            "\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621",
            "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621", "\u0627\u0644\u062e\u0645\u064a\u0633",
            "\u0627\u0644\u062c\u0645\u0639\u0629", "\u0627\u0644\u0633\u0628\u062a"
         ],
         "daysShort": ["\u0627\u0644\u0623\u062d\u062f", "\u0627\u0644\u0623\u062b\u0646\u064a\u0646",
            "\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621",
            "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621", "\u0627\u0644\u062e\u0645\u064a\u0633",
            "\u0627\u0644\u062c\u0645\u0639\u0629", "\u0627\u0644\u0633\u0628\u062a"
         ],
         "monthsShort": ["\u064a\u0646\u0627\u064a\u0631", "\u0641\u0628\u0631\u0627\u064a\u0631",
            "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064a\u0644", "\u0645\u0627\u064a\u0648",
            "\u064a\u0648\u0646\u064a\u0648", "\u064a\u0648\u0644\u064a\u0648",
            "\u0623\u063a\u0633\u0637\u0633", "\u0633\u0628\u062a\u0645\u0628\u0631",
            "\u0623\u0643\u062a\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631",
            "\u062f\u064a\u0633\u0645\u0628\u0631"
         ],
         "show_more": "\u0623\u0638\u0647\u0631 \u0627\u0644\u0645\u0632\u064a\u062f",
         "sessionHasExpired": "Your session has expired. Please press \"Ok\" to refresh the page"
      };
      /* ]]> */
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/bookly.min.js.download" id="bookly-bookly.min.js-js">
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/intlTelInput.min.js.download"
      id="bookly-intlTelInput.min.js-js"></script>
   <script type="text/javascript" id="bookly-customer-profile.js-js-extra">
      /* <![CDATA[ */
      var BooklyCustomerProfileL10n = {
         "csrf_token": "bc9b23705e",
         "show_more": "\u0623\u0638\u0647\u0631 \u0627\u0644\u0645\u0632\u064a\u062f"
      };
      /* ]]> */
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/customer-profile.js.download"
      id="bookly-customer-profile.js-js"></script>
   <script type="text/javascript" id="wc-cart-fragments-js-extra">
      /* <![CDATA[ */
      var wc_cart_fragments_params = {
         "ajax_url": "\/wp-admin\/admin-ajax.php",
         "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
         "cart_hash_key": "wc_cart_hash_418e0a8e5dbf7dfe8aeafc8cf401a3db",
         "fragment_name": "wc_fragments_418e0a8e5dbf7dfe8aeafc8cf401a3db",
         "request_timeout": "5000"
      };
      /* ]]> */
   </script>
   <script type="text/javascript" src="assets_web/EVA_files/cart-fragments.min.js.download" id="wc-cart-fragments-js"
      defer="defer" data-wp-strategy="defer"></script>
   <link rel="https://api.w.org/" href="https://evaclinics.com.sa/wp-json/">
   <link rel="alternate" title="JSON" type="application/json" href="https://evaclinics.com.sa/wp-json/wp/v2/pages/2">
   <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://evaclinics.com.sa/xmlrpc.php?rsd">
   <link rel="stylesheet" href="assets_web/EVA_files/rtl.css" type="text/css" media="screen">
   <meta name="generator" content="WordPress 6.6">
   <meta name="generator" content="WooCommerce 9.1.2">
   <link rel="canonical" href="https://evaclinics.com.sa/">
   <link rel="shortlink" href="https://evaclinics.com.sa/">
   <link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed"
      href="https://evaclinics.com.sa/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fevaclinics.com.sa%2F">
   <link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed"
      href="https://evaclinics.com.sa/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fevaclinics.com.sa%2F&amp;format=xml">
   <!-- Google Tag Manager -->
   <script>
      (function (w, d, s, l, i) {
         w[l] = w[l] || [];
         w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
         });
         var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
         j.async = true;
         j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
         f.parentNode.insertBefore(j, f);
      })(window, document, 'script', 'dataLayer', 'GTM-PNPG28D7');
   </script>
   <!-- End Google Tag Manager -->
   <noscript>
      <style>
         .woocommerce-product-gallery {
            opacity: 1 !important;
         }
      </style>
   </noscript>
   <meta name="generator"
      content="Elementor 3.23.1; features: e_optimized_css_loading, e_font_icon_svg, additional_custom_breakpoints, e_optimized_control_loading, e_lazyload; settings: css_print_method-external, google_font-enabled, font_display-swap">
   <style>
      .e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
      .e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
         background-image: none !important;
      }

      <blade media|%20screen%20and%20(max-height%3A%201024px)%20%7B%0D>.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
      .e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
         background-image: none !important;
      }
      }

      <blade media|%20screen%20and%20(max-height%3A%20640px)%20%7B%0D>.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
      .e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
         background-image: none !important;
      }
      }
   </style>
   <meta name="generator"
      content="Powered by Slider Revolution 6.7.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
   <style id="wp-fonts-local" type="text/css">
      <blade font|-face%7Bfont-family%3AInter%3Bfont-style%3Anormal%3Bfont-weight%3A300%20900%3Bfont-display%3Afallback%3Bsrc%3Aurl(%26%2339%3Bhttps%3A%2F%2Fevaclinics.com.sa%2Fwp-content%2Fplugins%2Fwoocommerce%2Fassets%2Ffonts%2FInter-VariableFont_slnt%2Cwght.woff2%26%2339%3B)%20format(%26%2339%3Bwoff2%26%2339%3B)%3Bfont-stretch%3Anormal%3B%7D%0D><blade font|-face%7Bfont-family%3ACardo%3Bfont-style%3Anormal%3Bfont-weight%3A400%3Bfont-display%3Afallback%3Bsrc%3Aurl(%26%2339%3Bhttps%3A%2F%2Fevaclinics.com.sa%2Fwp-content%2Fplugins%2Fwoocommerce%2Fassets%2Ffonts%2Fcardo_normal_400.woff2%26%2339%3B)%20format(%26%2339%3Bwoff2%26%2339%3B)%3B%7D%0D>
   </style>
   <script>
      function setREVStartSize(e) {
         //window.requestAnimationFrame(function() {
         window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
         window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
         try {
            var pw = document.getElementById(e.c).parentNode.offsetWidth,
               newh;
            pw = pw === 0 || isNaN(pw) || (e.l == "fullwidth" || e.layout == "fullwidth") ? window.RSIW : pw;
            e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
            e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
            e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
            e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
            e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
            e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
            e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
            if (e.layout === "fullscreen" || e.l === "fullscreen")
               newh = Math.max(e.mh, window.RSIH);
            else {
               e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
               for (var i in e.rl)
                  if (e.gw[i] === undefined || e.gw[i] === 0) e.gw[i] = e.gw[i - 1];
               e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
               e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
               for (var i in e.rl)
                  if (e.gh[i] === undefined || e.gh[i] === 0) e.gh[i] = e.gh[i - 1];

               var nl = new Array(e.rl.length),
                  ix = 0,
                  sl;
               e.tabw = e.tabhide >= pw ? 0 : e.tabw;
               e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
               e.tabh = e.tabhide >= pw ? 0 : e.tabh;
               e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
               for (var i in e.rl) nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
               sl = nl[0];
               for (var i in nl)
                  if (sl > nl[i] && nl[i] > 0) {
                     sl = nl[i];
                     ix = i;
                  }
               var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
               newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
            }
            var el = document.getElementById(e.c);
            if (el !== null && el) el.style.height = newh + "px";
            el = document.getElementById(e.c + "_wrapper");
            if (el !== null && el) {
               el.style.height = newh + "px";
               el.style.display = "block";
            }
         } catch (e) {
            console.log("Failure at Presize of Slider:" + e)
         }
         //});
      };
   </script>
   <script attributionsrc="" type="text/javascript" async="" src="assets_web/EVA_files/f.txt"></script>
   <style id="custom-chaty-css">
      #chaty-widget-0 .Whatsapp-channel .color-element {
         fill: #49E670;
         color: #49E670;
      }

      #chaty-widget-0 .channel-icon-Whatsapp .color-element {
         fill: #49E670;
         color: #49E670;
      }

      #chaty-widget-0 .Whatsapp-channel .chaty-custom-icon {
         background-color: #49E670;
      }

      #chaty-widget-0 .Whatsapp-channel .chaty-svg {
         background-color: #49E670;
      }

      #chaty-widget-0 .channel-icon-Whatsapp .chaty-svg {
         background-color: #49E670;
      }

      .chaty-chat-view-0 .Whatsapp-channel .chaty-custom-icon {
         background-color: #49E670;
      }

      .chaty-chat-view-0 .Whatsapp-channel .chaty-svg {
         background-color: #49E670;
      }

      .chaty-chat-view-0 .channel-icon-Whatsapp .chaty-svg {
         background-color: #49E670;
      }

      #chaty-widget-0 .Phone-channel .color-element {
         fill: #03E78B;
         color: #03E78B;
      }

      #chaty-widget-0 .channel-icon-Phone .color-element {
         fill: #03E78B;
         color: #03E78B;
      }

      #chaty-widget-0 .Phone-channel .chaty-custom-icon {
         background-color: #03E78B;
      }

      #chaty-widget-0 .Phone-channel .chaty-svg {
         background-color: #03E78B;
      }

      #chaty-widget-0 .channel-icon-Phone .chaty-svg {
         background-color: #03E78B;
      }

      .chaty-chat-view-0 .Phone-channel .chaty-custom-icon {
         background-color: #03E78B;
      }

      .chaty-chat-view-0 .Phone-channel .chaty-svg {
         background-color: #03E78B;
      }

      .chaty-chat-view-0 .channel-icon-Phone .chaty-svg {
         background-color: #03E78B;
      }

      #chaty-widget-0 .Link-channel .color-element {
         fill: #1E88E5;
         color: #1E88E5;
      }

      #chaty-widget-0 .channel-icon-Link .color-element {
         fill: #1E88E5;
         color: #1E88E5;
      }

      #chaty-widget-0 .Link-channel .chaty-custom-icon {
         background-color: #1E88E5;
      }

      #chaty-widget-0 .Link-channel .chaty-svg {
         background-color: #1E88E5;
      }

      #chaty-widget-0 .channel-icon-Link .chaty-svg {
         background-color: #1E88E5;
      }

      .chaty-chat-view-0 .Link-channel .chaty-custom-icon {
         background-color: #1E88E5;
      }

      .chaty-chat-view-0 .Link-channel .chaty-svg {
         background-color: #1E88E5;
      }

      .chaty-chat-view-0 .channel-icon-Link .chaty-svg {
         background-color: #1E88E5;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel>a {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel>a .chaty-custom-icon {
         display: block;
         width: 54px;
         height: 54px;
         line-height: 54px;
         font-size: 27px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel button {
         width: 54px;
         height: 54px;
         margin: 0;
         padding: 0;
         outline: none;
         border-radius: 50%;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel .chaty-svg {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel .chaty-svg img {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel span.chaty-icon {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel a {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-channel-list .chaty-channel .chaty-svg .chaty-custom-channel-icon {
         width: 54px;
         height: 54px;
         line-height: 54px;
         display: block;
         font-size: 27px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-cta-button {
         background-color: #A886CD;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-cta-button button {
         background-color: #A886CD;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel>a {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel>a .chaty-custom-icon {
         display: block;
         width: 54px;
         height: 54px;
         line-height: 54px;
         font-size: 27px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel button {
         width: 54px;
         height: 54px;
         margin: 0;
         padding: 0;
         outline: none;
         border-radius: 50%;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel .chaty-svg {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel .chaty-svg img {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel span.chaty-icon {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel a {
         width: 54px;
         height: 54px;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel .chaty-svg .chaty-custom-channel-icon {
         width: 54px;
         height: 54px;
         line-height: 54px;
         display: block;
         font-size: 27px;
      }

      #chaty-widget-0 .chaty-i-trigger .ch-pending-msg {
         background-color: #dd0000;
         color: #ffffff;
      }

      #chaty-widget-0 .chaty-i-trigger .chaty-channel .chaty-svg .widget-fa-icon {
         line-height: 54px;
         font-size: 27px;
      }

      #chaty-widget-0 .chaty-channel-list {
         height: 186px;
      }

      #chaty-widget-0 .chaty-channel-list {
         width: 62px;
      }

      #chaty-widget-0 .chaty-open .chaty-channel-list .chaty-channel:nth-child(1) {
         -webkit-transform: translateY(-124px);
         transform: translateY(-124px);
      }

      #chaty-widget-0 .chaty-open .chaty-channel-list .chaty-channel:nth-child(2) {
         -webkit-transform: translateY(-62px);
         transform: translateY(-62px);
      }

      #chaty-widget-0 .chaty-open .chaty-channel-list .chaty-channel:nth-child(3) {
         -webkit-transform: translateY(-0px);
         transform: translateY(-0px);
      }

      #chaty-widget-0 .chaty-open .chaty-channel-list .chaty-channel:nth-child(4) {
         -webkit-transform: translateY(--62px);
         transform: translateY(--62px);
      }

      #chaty-widget-0 .chaty-widget {
         bottom: 25px
      }

      #chaty-widget-0 .chaty-widget {
         right: 25px;
         left: auto;
      }

      .chaty-outer-forms.pos-right.chaty-form-0 {
         right: 25px;
         left: auto;
      }

      .chaty-outer-forms.active.chaty-form-0 {
         -webkit-transform: translateY(-94px);
         transform: translateY(-94px)
      }

      #chaty-widget-0.chaty:not(.form-open) .chaty-widget.chaty-open+.chaty-chat-view {
         -webkit-transform: translateY(-94px);
         transform: translateY(-94px)
      }

      #chaty-widget-0 .chaty-tooltip:after {
         background-color: #ffffff;
         color: #333333
      }

      #chaty-widget-0 .chaty-tooltip.pos-top:before {
         border-top-color: #ffffff;
      }

      #chaty-widget-0 .chaty-tooltip.pos-left:before {
         border-left-color: #ffffff;
      }

      #chaty-widget-0 .chaty-tooltip.pos-right:before {
         border-right-color: #ffffff;
      }

      #chaty-widget-0 .on-hover-text {
         background-color: #ffffff;
         color: #333333
      }

      #chaty-widget-0 .chaty-tooltip.pos-top .on-hover-text:before {
         border-top-color: #ffffff;
      }

      #chaty-widget-0 .chaty-tooltip.pos-left .on-hover-text:before {
         border-left-color: #ffffff;
      }

      #chaty-widget-0 .chaty-tooltip.pos-right .on-hover-text:before {
         border-right-color: #ffffff;
      }

      .chaty-outer-forms.chaty-form-0 .chaty-agent-body {
         max-height: calc(100vh - 220px);
         overflow-y: auto;
      }

      #chaty-form-0-chaty-chat-view .chaty-view-header {
         background-color: ;
      }

      #chaty-form-0-chaty-chat-view .chaty-view-header {
         color: ;
      }

      #chaty-form-0-chaty-chat-view .chaty-view-header svg {
         fill: ;
      }

      .chaty-outer-forms.chaty-contact-form-box.chaty-form-0 .chaty-contact-inputs {
         max-height: calc(100vh - 230px);
         overflow-y: auto;
      }

      #chaty-form-0-Whatsapp .chaty-whatsapp-body {
         max-height: calc(100vh - NaNpx);
         overflow-y: auto;
      }

      #chaty-widget-0,
      #chaty-widget-0 .chaty-tooltip:after {
         font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Oxygen-Sans, Ubuntu, Cantarell, Helvetica Neue, sans-serif
      }
   </style>
   <style id="custom-advance-chaty-css"></style>
   <style type="text/css">
      #screenShotContainer {
         cursor: crosshair;
         left: 0;
         position: absolute;
         top: 0
      }

      #toolPanel {
         background: #fff;
         border-radius: 6px;
         box-sizing: content-box;
         height: 24px;
         left: 0;
         min-width: 392px;
         padding: 6px 14px;
         position: absolute;
         top: 0;
         z-index: 9999
      }

      #toolPanel .item-panel {
         float: left;
         height: 24px;
         margin-right: 15px;
         width: 24px
      }

      #toolPanel .item-panel:last-child {
         margin-right: 0
      }

      #toolPanel .square {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHfSURBVHgB7ZpNboJAFMffY2hK/EhYWl3U3sSeQG/gEeoNxBvYI/QGeoLak9SVdSeNxlKFeR2atPEjDGiaCNP3S1jAvCHzG4ZhwR+AYRiGyS8I5+DUmnBpnMAH3/fhRLILO7WWEFZXdekAkAu5AJUwjaJIDiCYTzP1yFJklep9RPAgxxCBJ9ezQVqdSCsogmyMGmMLr6pA2+WLtk7XGL+rahm/QoFAlPfhaj5Jard1nZVs//iG9GiHNIQLEwnhElJHLeW9MRLF+wxM4BxEubEQ5Tr9HHal7kHOsCuN4e4Y1bHQ1VuJLW7TPdyNw8/tCHJGGEaHq80F5+Y2qT5ZOAiOPz3C1s5eEbDgn8HCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCpsPCplN8YSGO/2M7H+9J5Zof4nHuCfeCX7aAHuQMi6h9cEkbWNOGWojkGBG7v+eAPatU9+V2O1Yze3IK7q+xhHhAoMOHoI1laGNLdqXWIrKeoUBEkbzTpfK0wTS5WU3FdTWelBYUAEQYyPWb9gmnJvHkZjkpgnQsG65mXmodZOU7lYeeeo/bGEeDcgCpDUqNZYQon3Tpu13Oiw+7rusEzsWlg4wJWoZhGKYofAHzGYh5VvrALQAAAABJRU5ErkJggg==");
         background-size: cover
      }

      #toolPanel .square-active,
      #toolPanel .square:active,
      #toolPanel .square:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGzSURBVHgB7ZpBSsNAFIb/GYq6zA3Um+gJ9Abisoi0nqDJCVSKdCOIN2hPYI/gDfQGVtyUQjO+qRaaNDOZFqGT5/sWhWTmlfmGycsiPyAIgiDEi8I2DMwRds0UE9yoCTYkXLhvTtDCBeY4p6oEMWBIWmGIGTKSfw8pCRN+MD36TREzmtbXVlndtHrhJsguCZD2C9/Ss7qHNzSJHKe4VmPXcMtXS7K9irv3tJN32DU59ZGc+okurVFTnwHGrjK/MOgPi2S4Uini4ZWaaUKSnZV7ds2XrgLtGqDjbDtxuRsPERuttdOW4NEcuqa7hQ8qXj37+EDD0fhniDB3RJg7IswdEeaOCHNHhLkjwtwRYe6IMHdEmDsizB0R5o4Ic0eEuSPC3Gm+cF7xHfsLn67pbuH2IvdUDH7N0EV8nJWuvYE1f8bDYAS1CIksr7sYmAnt6oi2auMU3J9j0FmsqYg3luGPLdn0ncYLmoTG8e/pdAz7sHmnHLXptojIfLKWsOhh36Rreaj4CIpUhYdLbYJ2jpQqbJOII1z601SHdAqffem7VbaLDz+ZBNMIpNthCVpBEAShKXwDKrBaATx5xUUAAAAASUVORK5CYII=")
      }

      #toolPanel .round {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAVoSURBVHgB7Zq9UiNHEMd7ZiWBETbrq3IVB8neG4jM2UHmzFzo6LgnAEcOBU9geIITkS9DhI4QT2De4NaBT1Q5sKhDcMdqpt2zaxntaPZL2pWWK/0iGM3s6q/u+epugAULFix4QjCYBdXvGlCzGhy5wxmuITA7eDn2JLIbCXgF3sAF7+8rKJhiBNu2zT9/tcc4/AjAGwBopx+MHRpzKoTowKdrF3ImX8HL69uWxZr02G3IA8S2kHhCwjuQE/kIzlvoGNgRAt/kYfHpBCvX9epNmosHSV0R0WUMXHql+9gINjC0aU436Iskuj2953jQ7/4MUzC54OV1x+L8gp7gmD5GgB49vA0gL0X1Uxt6vV7i8yzYDryEvY7p6Qohdya19mSCfRe2zkyLkRLKGZwMKnfHiSKjn++LR2RNxphj6NFjTL4a3Gaf25kFW/VN+vWxZXwYg6OphBqorG4cIkLT/KncE/3rU8hANsG+ZcmNNRDQlcBfQf+vYvZRsjjn7MJkbbL0ThZL87QdAzdTbqyDp7J6v1WYWAXNV1lb2qJftj32duRn6rtBSlJb2FrZeD++QOGp6Hf3YIZY9ectw6LmiurdVpqpZEEKeH3zV5qfP4Qa6dcWd92fYMagd9vmtdUXJLox0mxbsrIsvdvfk8YnW9h3Zf4+9FI1Z5Ub57g4ZcJ2bP7w+Q99TqeZz4lzmE5Qb/U2KXBnbmIVPbdnMVokNdQ2ljQ0XjCtyvpxUW09RRzqs+LRIknb1VG4lW1XVtV3jiZWMJ2k9kf/V648uP1wCCVB1mrHJDLkaUlWjhaslnoGu6NNdJY9gjJBrk1n9JNwI3kknfGjhkQKpj13W28TAjpQMkxWVnfxqP4xLi31va5Vhrk7hm9leT7aFAQezMQI1u+28hJKCmO8o7U0ovqaBdc3xwaU0Z2HiGpVP3LafhzNgFGwxaWjNfVK6c5DfLdWwYVHrFotvWAUuktg4dHEaWEM3dH/afV2TP14xOjwso5wAyWHLPxnqIGZI6VmwSjDnRn7B54YDNiaqT39ffgLIcKl+fwuBhOiW5SOwcZpGOHSqAk2LwClQp+zyIxGMwqme6artThQenhoZ2EwMO4sRsECQO/sxB3I544f0wpbWHjhbWqI2aX9gFzYJSyvvgslxXTRicpExl0etAH4EkqL/t1UBtJMpGCUcK417ZbSrYMQ7V64ESOD85GC5dJSS2uiwNnKAZSMrPf2aJemA7nuGhTP2i+dlRGb2v/ncRed2JMWHcj1kE6prMxXNpp6coBxPI4bkxiXpkj/hR4M4OBtef3i6zFiMcTL/cR5v7sTNyzxLG2wMkions3Vtendfm5aw68SSCAx1SIfbl1r6Ztv6c/vR1/JZXUdvY/nMAcs/uw38s3R76MMcyLvrt8ljU2XTItIbRAt0f+Q+KvmCa9vvGXaNuSnfvrdF6nGp+mkVmwpKb0CYwfyPWvl+WzcW9WTGMVCz0/9pCRTQlylMSgfe2H4aKq6i0QoqGghnpnqSbImxFOlS4eo+cxrdQqlMP1cbVOG/oBVv6Z05sf8wrnKqvzZL5zBOxI75kUc2JtBv9vO8siJiloCS5uLWgiXHns0VSWdEvqwsk9rxkF04cyMilr+J6buYoQWveIylXi1DnjLuxbwl4EHmYNw/gKl5uxMy5ZGqKxuHlNIdD+5p1rw6AaGFONmo4sfOhRxdBJ+uOAJtPUMKveH0+Sm8yo9dILEeXGlh+oANIkL6+Qj+D/8uS0pp6ylWScnP6FDiikffiwjfJ3F6kG5Il6pu7hcum8VUVYxkwLxKu2jkvJVKoXDg2LSteDleCMpukh7qcvBuvKKrPVasGDBgqfIvzowNmTgJi8YAAAAAElFTkSuQmCC");
         background-size: cover
      }

      #toolPanel .round-active,
      #toolPanel .round:active,
      #toolPanel .round:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAASrSURBVHgB7VrrUdtAEN6TB5Pn4BKUDuwKAhUEKsD8jJMMUAFQgfEQw8+YCoAKgAqgA5QKYn4SYl1272Kw7qGHJVlHRt+Mx/b5LN2n3dvbF0CNGjVqvCAwWASGvA0TaOPdfGjACr63xDiHMY7f46db8CCAL+wWSkY5hPu8BUvQRRKfIBREW6n/y+AKH8Qp/Mb3XRZAwSiW8BFfRQnu4YJXoQgwOEcNGMA3dgUFoRjCRRNVQVJ/gK0iJJ6PMKnusiC6k2J2gPMCvGMwM9bCsRaOtcXnJDA4hB7bhRyYn3Cf+9CES/zkW2aM8UUqeQ3v8X2LjWOvd4LXC1FDSEsYbMbMDHB/r80r7fkIkwozOLMYozEufADvUBpJJG2YkmdCe3zLPTbm2dvZCR/zTVzEyPhbCAe5iJpwxPfR2u8Zf2N4EvTYKWRANsIkWU+osXoV2p8bpZ2jJHGO9zVJO0T1ziBpL+1EsWdJjVXQmfkaOqU6DZ9xvz7gPeiYUuHhmmhtKZFewkN+B6qBIrJfWRcWie98ZDBqZMg6aMgSt1I6CR/zPujW+HzhZAl0T3rQUfjieEyBZMJ9sX+i5yzt2TfoCFSFR1xP9DwHsUayMQlIJrwMP7QxhoaiSEucFaS6ZCRVNJKlHE+YnpjuLh4II1I1yEjSMTgLWmuClOMJe7Ad+c5ECLcPruAPnvnSo3tGgpTthKWpX4+MceWJVg1SbfLqZkFSJh/fAjvhpiHy8TBqcQ0mKVMsboGdsH7WjZzYuyqkAbuIjFHiwQI7Yd1YXYOrCBXN4yLcNMJMmHJQ+swrcBUTzeVsGTmAjXCoeVVjJ9V5CulSBpGxCWQgDMpkBqVnE3ND9byYOTFhIxw161ykUt1GCD8j3z1zyshMWM9k/IKXhxXTYPp4+D+BmTCH6gKDecE0iRq3oU3CY+ViPrgOdRuGZqHZJBwo331wHbqzYTxZzIQb2mQ/ziGvHDLQia7PU4T2NGyCTMipYdc6uApToGNJKsYFD9E/NOAjuIvo2pjdDbYTDpUIhGJjF9VaqnM3MqYn+Z5gJ/yoVRdaqDo74Boyxu12wuSQ66qx7aCU1ZTORVygE+9pTbSUjltSHnIi60fGQpEBsSK58nDMLw3JgM4i+jFiIcu1d5Ex0sgeW4v7W7IvPTEm7s4qVW26d9NY1EssDiQTpsqcmhkkNWpCH6pCUxQHfGV0kCZJka6YJlsbbgwu5ghVe7EllyEnst3IGAX/PfYhzd/TVw9lVf4GVBeOSpiy4aTcCEuqMWlVV/lljHraSZuCKqYgnrPvIhF9TMg1RW3a134rrSBOkBc2qbC0mCc8VckyNUiqdM2m0CzfMGMra5/H/E0tnnjiJksdABXc8nTSEdFX6ORMRFnU1jizoKaWKeL6Lp4xAkrgpyFPJCkiW8JAYILvtnZFJnq91uZNG+fvxDvih1qV0QQujIsMO9lM6EkPTD40H5IxwEL8fp7adDGthyTtCZ6NrKTWQy4aTg+K6LkshvAUcm+TtItJFhRIdIpiCU/x3Ea4mVHqVAkktb+At7j/S2irKIewCipsyXpV+19FYJpSvRfZRUoaUh6t6oCkRo0aNVzDX2qpg7pu/G77AAAAAElFTkSuQmCC")
      }

      #toolPanel .right-top {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGcSURBVHgB7dk/TsMwFMfx33M6RCoLG4Kl3KRH4Ah0ZOMKnABu0HIDbkC5AUfIAnTMQFGl/jF5MkMRKpIT59mu3met6qev0liNAyillFJKKRUEQVp5NkIIq0WFFuSCm9DCmOdm4ghhVES7yeZzMff5koGQoqBpwFg2stZM4UksGJZqJEAs2BDdWWsrRCa+aZWem9aabwXQ+MDH1Xb5fgkPAwhbeeyuZng+ba7IGAHJ3cOefmKvEViSwYdj7SM6Si74UKwBTbZbO0NHSQX/F7tevs0QQDLBErFuvQRIxbo1I5OMdetGJB3r1o4kRqxbP4JYsW6GsJixbo6g2LFulpAUYt08iSGJxLqZfQ8IGVuWr82z8f7JyRyeej0A6OXKNgcIg4JuQVRvBl8PqGuvo6PeglP6Ge/rJTjVWBY8OOVYFjQ49VgWLDiHWBYkOJdY1jk4p1jWKTi3WNY6OMdY1io411jm/V/aDC/uc41l/g8P1l79XSSPWOYdTPT7lWdOsayAJ1ucvBiD0+YFd0Vmd7NZfjxBKaWUUkopdfS+ASmNvgIGrsXnAAAAAElFTkSuQmCC");
         background-size: cover
      }

      #toolPanel .right-top-active,
      #toolPanel .right-top:active,
      #toolPanel .right-top:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAF3SURBVHgB7dpBSsNAFMbxb4roRvAK9SY9gkewSymCR9ATVBfq0noSewSPkCP0ANJxvropaISXvLx5A+8HbUpDAn8yCWESIIQQQgghBBUJ1l7zHBpuUocB7ILXJfQUH+XXHDo67LHEbdpKNprByhneoBeLw75mh32K2AVn7OCAXTDwUE6gDpX5v2jlMmwzFj1rO6zSJQROYE1ydX3OPEcXUGQ5pGV+Yq+hzGdwX2zGO0byF9x/ZJcleIORfAX/F7tKGyjwE2wQSz6CjWKpfrBhLNUNNo6lesEVYqlOcKVYsg+uGEu2wZVjyS7YQSzZBDuJpemDNWO/8Fm+j2dOthCadgJgiiPLCYQ97spnh3M8YplEU0fTBTsaxsemCXYaS/rBjmNJN9h5LOkFNxBLOsGNxNL44IZiaVxwY7E0PLjBWBoW3Ggsye+lX/IajcaSPDjj6o9/m4glefDvR57NxJL86WEqgXvcl+VFWT5JXzkIIYQQQgghtOkb2FSXUxZQW5sAAAAASUVORK5CYII=")
      }

      #toolPanel .brush {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALESURBVHgB7ZlLbtswEECHpOykcQoIBQok6UY9QZsT1D5BkhMkOUpPEPQEcU+QLLtzdt26J6g2RQt0US0qRLBCMTMGHMiybJPyjwT4VtJoCPOZ1FCiADwej8fj8Xg8m4GB5YjOuytQxZkC+MgYxNjh4ZNUXyD7E0MD7BUOw1Dkr+6wi92aqzGH/CJP/w7BEDuFUTbIDwY0qguyEpTumUrbJ6wnO8FYmoNNzJHF8wSguMaD+2qLAlqDVuetzp8zxp4RXiBbAOtB+ms8iqJz3MduX1ZaJ1IWpzqFTIANaMqOY/n/e94+fI/S5dx9xoHhtW/Lfmr3U9pAdoJMf19hxtdyjAE7Aw12K7ygQDGurutkJ0ip+pVQBBrsTnhZNS7YDewfRXPbCn5TDilQWpV6N8J6S08kBB/MSM9pi1PaUuEF96xSKq5kT0vPbatirNKfQYPtLkvLCpSUCedswBiLKi1jOcovgnbrtk62kKqn+2y9PWHdaoyjOUd6BlNZYjvCpkuPhnQTWWLz93CDdZYkivbeKebUFqKmssRmhZvIvpDUdm4VWWJzU3oV2QXVeBVZYjPClsoS6xe2WJZYr7DlssT6hB2QJdYj7IgssbqwQ7LEasKOyRLNhR2UJZoJOypLmAs7LEsY71oG4s13V2UJo5cH8fr43GVZwkhYSea0LGEkzJj6NB3BvWGHZAnD92Fe2SlUTskS+sJhFGJ3w3JIjmS9sKWyhL5wls3uIec1nyktliUC3UTOeXc6oh5eDlES0lbEg6DLc3ZpqyyhLYxPKB/K5wpYKDont7h53mU5i6A9iU9jkyyh/aQlDk5+YnYEBtgmS+gJY8ES+egfGGCjLKE3pbMsBLG8vtG3Idw8f1CF+lHsPfYhTRKwDJMpfYfZ55PzshwXavgUZENI7BOsYvS2FBwedZkSSd5KYxfkPB6Px+Px2MUzbTi7WUXRE4wAAAAASUVORK5CYII=");
         background-size: cover
      }

      #toolPanel .brush-active,
      #toolPanel .brush:active,
      #toolPanel .brush:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJySURBVHgB7ZnRbdswEIZ/qUFbBH3ICN6g7gR1J0g6QZPHon1oR+gEQZEGeUwyQbpBMoKzgTaIXxMgZu58cGDLknwnWfYR4AfQtiiS9meSR9oEEolEIpFIJBL9kME75+GYPuUhAob0XFDOGI/4i99ZgRb4FT4NB3iHGxIdVdwtKH3Fj2wMIz6FWfYtbunVsKHUhNIXq7Q/YZ3sHLN0Dk/Uy07wjBPqnv+l/ANKtzTPNV/ODD893CS72Iv/whV96m8rZZ7wSRPIfPSwVpb5mR1TILsuleP6v6Bg98IW2TnV0odQsFvhpgA1pTnbFIwCrko5AyjYnfC6aJzjlMoMauvy/WVUkXo3wrqlZzArU5aur+tUuGnOytZxkWXpurpcL8cfKNjusrQuQOX0HOh+WJmPBXgrCVyiSjajut91e+vtCWuj8QX1ZrX0KkZZqbINrEuPRrqFLNP/HG6zzrLEI+2c6gJRS1mmX+E2suvoICvV+6KLbFM07iArTfSBU1lpZtM4lpWmNolzWWluU0QgK01ugkhkpdmuRCQrTXchMllpvi0RyspbtCFSWXkbKxHLMva9dMSyjE34LBwhYlnG2sNRyzI24Tf4XMq5jkmWsQkHwz+FDmUZvTALyOHVIuPasg5lGb3wXsV/yFXD2bEss2coO1q6ynD3+lokB7PTejnZcynL6IVzfFy6DjS8L8IlnQGNMD/XqdrGOJJlLD08XLmerjmldybL6LaWMmQfYMGhLKPr4fc0fKeqkgWlOxru99in48yTbAJn6H88nIcbejxayCkwlwu0PH2g5FCwjO3X0lkYzQ689kk2ArlEIpFIJBK+eAGdRGPGDQz7SwAAAABJRU5ErkJggg==")
      }

      #toolPanel .mosaicPen {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAOtJREFUaAXtmckNwjAQRcNSBg3QCkVRIXQBZxogghlxQ7Zl8YKSSG8kX2bx8r4PtmYYNAlIQAJLJXCOjT1jvGYet1j/FKNom6L348zN7xrx3tC1N7GSdwz/I8ahEq+6pyJfXaAzcIm83EvRtkXvipweYG6xVEAFIAGvEASIy1UAI4QTqAAEiMtVACOEE6xegdb58w2eb3Fqf/1XrF4BD0DvF61XAUqQ1qsAJUjrVYASpPUqQAnSehWgBGm9ClCCtH7fmOAesWwuTPEnaCzTFRq7sr6Ssq2T7Z2pPiS/zpOdomx3aRKQgAQWSOANmudym8Lt+O8AAAAASUVORK5CYII=");
         background-size: cover
      }

      #toolPanel .mosaicPen:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAXxJREFUaAXtWU1Kw0AUfm90UeyuIih4Add6ATeinkP0TIrnqOLGC+gtFASxu0o2zpgpSUngvaTtS6YtfFkl37zf78tiZh4RHjAABsDAOhlgLfnBS3btvX8MIRxpNilwJv50O+72+2IwlvLtSmDEiuIPtfVlcGZ6X8a+ZhvoxP/5hxw7ruHFh9pAhfkxDfhucr73IQVowkZP0xDXfy6HZ012TWv7z9O3EOhUs3Hawhxfsfi5f88vrQ2swnzPNdfCtzZQs97ADzSwblGgABQwMoBfyEig2R0KmCk0BoACRgLN7uqBptwKmzN0FGByNRRr3fpfSD3QROLiScpyGClV1NhbRJwyhma79QqgAU3aVDgUSMW0lgcKaMykwqFAKqa1PFBAYyYVDgX6ZHr0+iteqVdzbqwCs+KzcF8tVnpXt9NxMkL5cCHez0uOi2D5vf7sadsSi7GywpkoMPOXaJODagNxrBMnI03DBS1ol3gs3jl302VMxAIDYAAMdMfAP+EdVKaWg/p6AAAAAElFTkSuQmCC")
      }

      #toolPanel .mosaicPen-active,
      #toolPanel .mosaicPen:active {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAV9JREFUaAXtmU1KBDEQhauiC9GdIih4Add6BhnmHOKhxHOoeAY9hjAgLkfcTGo6Mo2ZpivW2F3GgZdNJ5VKVfK9XuSHCAUEQAAEahJgLfnx0+c0xngnIqeaz1/Ymfg17ISbt6u9+758u33GZFtN/kTr38TOTC+b+K/5Cp3HRbxtbGdr9lVDXcA3ef4gkv2+wVbb++Tg0urb9Tt6nD+L0EXX3rZDW9G/wyavxx2nx7CAcRJ5RcECvMha40IBKykvPyjgRdYaFwpYSXn5QQEvsta4UMBKystP3U6PmfDwYS6/jddspYtl63+hogLpJDXkMDKEfBF71rn1CmABmZpVqlCgCvYsKRTIYFSpQoEq2LOkUCCDUaUKBapgz5L+cwXS1X65qNvp9DJCzeNCup8vh9B7fzqM6CPbnq+rfWHmWWvpftUFpGed9DJSelzoBvNop8mHEK49YiMmCIAACAwnsARsm0C5E2sdIAAAAABJRU5ErkJggg==")
      }

      #toolPanel .separateLine {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAA2CAYAAADgQzjYAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAApSURBVHgB7cixEQAABARBr3H6NEJ9IFWA6C+6WcgUWQ6F7aucCATCLzSr6QQMe0nWygAAAABJRU5ErkJggg==");
         background-size: cover;
         width: 1px
      }

      #toolPanel .text {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANiSURBVHgB7ZnfUdtAEMZ37zAQlMyIh8zw5yGmA5egVBA6wB0QKiDpADqADuwK4hLoAL8k8BY9xEyIo7usTAzW6Yyc094lk7nfDMx4Ldn+dKvdT3sAkUgkEolE/hYIgRFbe6eIOqOvHheduxPI8xz+V2Sy35fJnp7/iWT3DAITdIXl1t41fWN3IZTTKh+EXGUBoUj2e4bYklTcv+hDQIIJlqCPbXEU8A4CEm6FNWT2NzBbe7mTQSDCCN4kQfV0fkRpPIRABBEspTh67n0EPII0TSEA/gWn3VJIv+koOU2CrLJ3wXI6rQnRSp/Uj1TPZgEXAVK6LkRpPSDZo2oUM+i87oFn/Are3OnOhFQgod9vx2QvP5qHi07He1p7FSzQVn31Zfn/57fbEV2MisNChGPwjFfBiGgKyIvJ7cX8hdb63Hg/9d2T/Qm2W8nB4guFODBP0xpPwSPeBNusJKK6rAQmn6+sxctjT/a3woaV1KDHD/etcZiCoRkTP7begye8CJavdg8t6Ty0Has2Ni5CFi8/K6yw9gSkCm1/2M/HuQa4NKLeihe/4FnvrVpJSuersvcuO0VgEax4sQuWUmZmDKHWfio83NthipeHlK5byaKAUdNZoYoXr2CbldR6+Fw6z7EVL4H80xBWwVYriXqw0smW4kWve9zFi1Vwk5Vs/DGW4sU9DeETbB/jrLa6vymLF63q1WKMexqyBkzYxjg09O7JZPcT/BHYnSXzE7NRroKcZWjPNoi3DNkZ0aNicvMWGGBJ6SVWkhG+US7PPWyxktxwFa/2KU29l+7f68UQ3YE59d9W+0VU8btGiGUfqnXRerCSlSJDV1GdFHertyMbtK36gZ6aFv00S/FiSGk3K9n4qevrNWEc+1DtBLewko2Q8/Ixym0lWAjRrwVXtZIr4GOU26pomb23HOOoyc0BMCKT/a/0yYtOi+zql21wxH2FLVaSbOAImOEe5ToLtlpJcyrJAPco1zmlQ6Tz43fN/Hi1OFJP3nbpyU4rbLWSGtlX9/GjGachbildYH1HUKkL8MSSUa7T9qqT4HISYURGLL13GUtGueCAk2Dqj+NqRHtL5zmqKM6oYo+ffgOcgwNuRSvtpnJ6X1q/N3TFhtPJDcvDeSOzBxXISKx12yYSiUQikci/zS+amzngvBJLrAAAAABJRU5ErkJggg==");
         background-size: cover
      }

      #toolPanel .text-active,
      #toolPanel .text:active,
      #toolPanel .text:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALxSURBVHgB7ZnfcRoxEMa/498zqSDnDijhOkg6CK+Jk0mowE4FNsMQv5IOSAVxCXQQOgh5tRMUifPZ3GnhjLS7ftFvxnhOcMCHVrufVkAikUgkEomXIoM2N+YCBoX9W+MOE0yyDRTpQZO5GWOLy8frAf7Yxy9QpANdLhrX73BlhlBET/DcjOxj3hgdoo8xFNGc4c+gv8EbKKIpuCBHXQKbmQJK6AguBeU4/C3eQgkdwR2bnI6jlrzkBZdCxi2vGqKrM8vyggeEEGMNR5NeaxSwIC84I4R0sbTjt7Uxl7zK0iWKrOArk++E7OOEvs/W+IevxB3iYS0ruE+G8/fd/0/ZrX1s+mi6VjMiKzjzBGxwni0er7aYNp4fStdkOcG0lVyi/ulL776u57dZkZxhPzy3D+FccZ6tyOQlWJMlBRe1q8zuf8t1W2eLH97YQG7LKCN4ZlyyymtjhhDmuMcCislLRjC1A+rgmnyt63g0Q10wefELdrXXt5KrXe09jFry4hc8ILeB06P3uLWtlLz4BVNWstMQQ6GUvHgFU1YSVsjxcC6hkxd7N4RXcJ/0wks8Bzp5jbiTF6/gNivZjv/jMHdD+ATTbZznzW5FaUxWjVHWbghfI55u44zwzfzEKWztj1Y/D6lauddggPPkoSDGRjaJnQZ1+FMaGRbBPCFNWUlOGFu5PII1mulMySv+9NDV3gF+NUY38GvqqeTee97hLPa0MX4N01ZycmI58pmZSzur+36aJXnFh3SolWzjLyGMYenECY6xkm240BVo5cYJ7pEnCqeZjWMItHLjktbcuGSV773bGh+yM3AyN7/h1u8Tzq6+QiDhM0xZScOwdpswt3LDBVNW0t/txMPcyo1Zw0Xt6lBXMhbmVm6YYLoryT+7FYzdkDDBHbL2LiAF3Q0JOl4NDel6LaxOBKU41MoNIEywW6/7SIZzRc86r/rnThFAWB12CaO/s36v4ZzVx4xlr9rKjXV29zZhSSXIRCKRSCQSovwHybzXUxgaB2wAAAAASUVORK5CYII=")
      }

      #toolPanel .save {
         background-size: cover
      }

      #toolPanel .save,
      #toolPanel .save:active,
      #toolPanel .save:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAK8SURBVHgB7ZpRTtswGMf/tgsrpUzRnlqeshtwhPYG2xF2grGnPVJuUE6wM+wEYyeAPe6J8LCBtIdFKmhdS+PZliaaVK0TJ3ZK8E8CtV+b2L/Yce3PATwej+cJweCaIAgoffWR7XbfJKz7HQ93MRzSgmPYrHMBgpCLf4zhaAEM4RACl7R7IWP0ajm0WPAQ05trOILimeGFm44XbjpeuOl44abjhZuOF246Xjg3YiGv/lxTslwjYbrXf8/m+1ds3vlNO4cncESq3L3+MQwoLhyEAaFkDHB1lQnByIW0LCNVLiUnJi1t2KVJKg9lW1rJijIyYaNuXVw4jmKO5DQbtiW9RlaWd4o4LpwANGrh5P5mrApcrUSl0ptkH+5+jmCA8SgtC7QpbUNWnRclsCVtS1adGyWpWtqmrDo/KqAqaduyqgxURFlpF7KSSveWktnknL04kLsZg+W4qPSA7ByAc/6NUpKaIXGOMd19eexCVlL5ZtpGaUoC8cFRKi5jBCvTRBuyEr2wwW7fWumM7NpYEdmC9dPuHpru9skKt7qHsssWGqmLtmzR+m3ePaxgt09Ij/JKF+7GBvWzngBYN3pnsXXPZnGS8dBJu5KVOEvxbPiddiYrcZrTWpbmYqFJwT+4lJU4f8ZDCQbBWL5ODNazZXEurKhB9D8+TZtiehtlQ60Wf43tIVyJaOYIOVqYn6feceIsLauDUfpp+T0Hv9Qdo72HheBXOfF/jJAB2+9/ETMaOdpGqAcxw1IXPlwOEvAz3YH6B9NEHprO/l4QQkJsMaJ1I5Fc1N5u+i4t0rKM0LfZXPQ2IX/TE8g66sk1Ss/vf1yKLw7FAj7ClqFaFmQIUcc838+dAEjmk1vOup9bFNeigJ64F3qoEXnxRfbkbLHz5x0mv6K8x5V6uLQtlmeogWl7Gtc5efF4PB6PpyL+AYIPPUb9sB23AAAAAElFTkSuQmCC")
      }

      #toolPanel .close {
         background-size: cover
      }

      #toolPanel .close,
      #toolPanel .close:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAG2SURBVHgB7dpBboMwEIVhiLquyqLXibhZ6c1QLtIDdEFPAOUtkKIEkMee95zF/FKUKk0FX4xU7LhpoiiKoiiKoqhOP33/gUdTudzzuFjePF2vX+/LMuGBn5tKlZxHm/rGaf005/UA969dlmXobrfvRhiAc9sO969d2rbrxvEv5e9NI/wYDqwc6T2stWQwPsH1YE+jqUIfYXFOqaOLki/prd++H9ZL+QnIvLzPsJ/jODSGzGCkRHtiURYYKdDeWJQNRkw0A4uKwIiBZmFRMRh5oplY5AJGHmg2FrmBUQlagUWuYJSDVmGROxhZ0EosooBRClqNRTQwOkPjWY1FVDA6Qu/FxiI6GKWgFVgkAaMztAqLihYALL3N85LzO+8kI5yyUqFaLqKDLcsyCjQVfPZ/Fs/qlRNEA6fcVNRYLqKALXdQarQ7OOd2UYl2BZfcG6vQbmCPiYAC7QL2nPWw0cVgxhSPiS4CM+ezLHQ2WDF5Z6CzwMqVCm+0GVxjWcYTbQLXwG55oYt2ACDl5P0QLdwBIMMiHGvvS3lL2TsA1NitR7R1B4A5XNrTC2xbepXziKIoiqIoOuwfOs4hnf5I1CMAAAAASUVORK5CYII=")
      }

      #toolPanel .undo,
      #toolPanel .undo-disabled {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMVSURBVHgB7ZrPbtNAEMa/3bVj3CQUNWmjtqoa7vTEiT4AvbSvyUNwoZyQEOXSikNEJTi0ARqQkBunTuwd1hEtdkOzzl850f5u9nq8/ry7s+MZAwaDwWAwGAxzgmFSVqqbgL2FiHsILhrIORYmoFCqPQsl3+8fCAlZrDlofz9FjuEYE8vdfnEn9hbCLnLOGCO8XhKudSCZrAy28SZyzoiCH68Jlx8QQ/l+iyR+is7FCXJOZqeVWq/JG0gKIkEf8752b8kkOF6vagrvDRgz6kYRjlEKf2JetDYC4FMXY6IVbDkbL6UQdeQIRsxjJJvhTfQBuLoexVYMb96uwGH7yBsMDjFW4Zaok4smut1OVlPNtrTqqWkbIKcQo7KQxSOUy5WsNpoRvoqIFSXjbAe5hQkunR0Kdxrx82qvRhbUG1Rv8pCIOSnjvtNib1Dq/cK8CIKCiFb2CXwzeVoCJ/Cb2m1xhFi6WhauOCTGB/dgwY/hzTeOFiu1o6To/stvr73SeXDNlE7idyl0v3KL1dXd0yNNVLfsMmTvem6RFvXcJrNFYqtkggp+B732j2F2IwiOiUXvNrjt11QHqZEmYIsKxa6uw+nhd7ld3Eo+BzEZqf7Ph1mNKDhGObJeu0HWakFNo1qyJUuH04S4C8b/xQichKDQOxtmM/bXkoqb3/UdRRJpe5gngZOK8OJtSmcyxggnUGuW+COPRDyl+Tk6l+8xVxwrvY7Vc6w+asD3H3RcEyUA+gStBgLkPtNxy/hTekExgpcdI3jZMYKXHSN42TGClx0jeKFYQWngXKs19BN1sQVH6RpXnNfSmSy0YAv20+RxBHmps1lgweslKe7Vo0P7i85qYQXHNeqBk0GgzZpOnvEYRrWqzTGNjI+SgHiusqSp8oqUpLIuLW1ObUaC478E+BH5fPqC0U8Jp4iribjpZSrGz0awW9hTKduZiL1PvyB/c/0a8DJlTGc7pWdMPLJ/xWYuyE+Wpn2I0Pn9v5LMtJAkPVUfPqNO8S3wbaRc+OQ/pg1jFk6r9UQFF59zW7M2GAwGg8FguOMPg6ATjq272toAAAAASUVORK5CYII=");
         background-size: cover
      }

      #toolPanel .undo:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAKwSURBVHgB7ZphbtowFMef7aajjTTxZVJLv2QnGL0BnID1BvQEYydoe4K2N2hPwG4AO8G2Eyz70FFpXyINOiaw356RJlHDcBJIlkT+SfkQO8/4j59fbL8AOBwOh8PhcOSEgG2pHbX4/ssuXQHOfn6GKsMPjt8Jv4F/L7rvQcHhkBLun1wzzm6WyxiHDhScPUhK7SjYE7yPgE2zijH2EQoOS/S0f9IUiH2yClYaYng7H4+q49KL+Qr4yRSLABEHfF8GsZpYI7yYr4DrBEXA8VzOML/oXJtGEEURpMQqWBw2tAu/hWIR0jWUUl3B9DFMYrhZsJ6z2o2LS8hhdjab/IjtYZvnsOeF9J+kdp8cCBR4A89/1YxrsFlwFEYI5DbFpk6i+1Cv1+M8HCtoeeTaCmBAMdlsdBG0vByDlhSCBKpr6npruRwRrtTT90ubffz3MC04OGcDWlwEq5WqKyeP95Ajwj8eGKIj6T29tkXw+EtLioZKYRsRwzXN3PHDxgXkiJR4bhTV+e+Drs0u2Vpai95/cUoONDSrGIPLXDcPi9fR835QH1o2s+SbBwpkcjJqk2vfmlVxfnC38HujA2+sFpCS+fihRwKfRXDaLYWQIxLADJaBzSbZ5mENwj/qAvIOif0yH9uj5E6hQCoE/7pcRHM7gOno279Mthb8X0khOLVLlxUnuOo4wVXHCa46TnDVcYKrjhNcMoKVkg0bB02pBQshAqPIeqRc7hFG7Bj31uxleQXTXnglBcTwg82stIJ1jtoskxKGVjvIEj0Ku4dOOdgFpWnN9MpdnMRaNoL10Qvng3WJ8yxAwFBJjJUSysSluRC9/MRCpICfxU2bljpKL0YWWBsmDztKl6ZESXmzPiWzG3Tb+kxceb9Ok4jVZHpMW8sgaE23/OTB4XA4HA6HIzf+AELL5fDBKGTPAAAAAElFTkSuQmCC")
      }

      #toolPanel .confirm {
         background-size: cover
      }

      #toolPanel .confirm,
      #toolPanel .confirm:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALrSURBVHgB7ZlNctpAEIV7RPhx8IIjeGviVMEJHG5grxKchcUJQk4QcgI7JzAsAtk5N8CcAKfKga2PwAJVDJQ06Ra2y4hBaIRURlR/O3pGo3makfSeAGAYhmEYhmEYhmEYELBD5O9+mpAyjsF2etbR56aqz84IfjvsfBMSGs8Fx6mpRBuwAyyJJWilFbyBhJMfts/BK5awoafqn+gtjfdsCQyj763jan8fv6s2VMckdkvPxYquty5A/lgldt6eQHL9zoGRhS5O/sDT1LKKVdPv2MQJXi1W3FrFT+V1xydqS/us7H168q8SZIzErHChf1WYZnN9lVhbQOXhsHofZJzErPAsu9fdVCyRCMH5YecKQJY8ZW2xxNYLzg9+XaCxMBercoTW8VRXLLHVgskyorj6UoMjK+iTbyEEWytY6Y8JB2phxRJbKXiVWLKM1lG1CRuw8rVEr4FZOnNiz4ybh7L+vRKWeRgQTW/dzx/roBRML/hUVqIpFwW3kw2V8fvqDcRMmDCgi3JLp9L0oJiLJWRKXLuTiZGwYUAXpWAp8LG/WCnglb+mlYcYoHEljv/yIj/SGhfP6hAhSsGZ6fQSRXqfhLjNoRu1aP8w4J98wqAUPCrXRunJpBK36CjCgC6+4SE3xAlJ9dWnCdGFgZBEFQZ08X0P00kdPLnESSy2yBKZeZo0hCSqMKDLWuPhKzqTu4AQRBkGdAnktGgSAs26a9pfIsB0zb0GUYcBXQJbS/Kvwhanyy2yPjf564kjDOii5aVdt4Xm3Vsn37tOdFxhQBft8OCad0d+9dZJzN6grTQJcYYBXUJ/09r/22lIAcurKgzTOvzYevoZdxjQZaOPeKtESxC/Qdp/hIH/70j4sHTSVxLrnhs2ZP+ufSkN8SVofzcMROyPdYjkM21+0G7iUOcBurbi8Mc6RPLFwyqembRN/fq4D6hXFuvOAyKEvLeQ8kSAcYxbt4D38kiC08tOJs1NfDfDMAzDMAyTBP4D55plBOlQMmwAAAAASUVORK5CYII=")
      }

      .__screenshot-lock-scroll {
         height: 100% !important;
         margin: 0;
         overflow: hidden !important
      }

      .ico-panel {
         border-left: 6px solid transparent;
         border-right: 6px solid transparent;
         border-top: 6px solid #fff;
         height: 0;
         left: 23px;
         position: absolute;
         top: 0;
         transform: rotate(180deg);
         width: 0;
         z-index: 9999
      }

      .ico-panel img {
         height: 100%;
         width: 100%
      }

      #optionPanel {
         background: #fff;
         border-radius: 5px;
         box-sizing: content-box;
         height: 20px;
         left: 0;
         padding: 10px;
         position: absolute;
         top: 6px;
         z-index: 9999
      }

      #optionPanel .brush-select-panel {
         float: left;
         height: 20px
      }

      #optionPanel .brush-select-panel .item-panel {
         float: left;
         height: 20px;
         margin-right: 18px;
         width: 20px
      }

      #optionPanel .brush-select-panel .item-panel:first-child {
         margin-left: 2px
      }

      #optionPanel .brush-select-panel .item-panel:last-child {
         margin-right: 0
      }

      #optionPanel .brush-select-panel .brush-small {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAKlJREFUeNrs18EKgkAUhWEnwmW1amObHqKeo0ftOfIh3OSmlba0xXSEK4SICAoz4X/gINwL8sE4C533Pok5myTyAAQIECBAgAAB/jdwO/cFO3dsH3v1qmY2LtWHWr/9KyxQOag3Nf2ZnQ17V6vQR3zp4bqktgv+DWYjuxO3eELKkd0zBmCuNgPzxnbBgZXd1kL9WIslbnAbx38xQIAAAQIECBDgqoFfAQYAhLQbgzDvXkAAAAAASUVORK5CYII=");
         background-size: cover
      }

      #optionPanel .brush-select-panel .brush-small-active,
      #optionPanel .brush-select-panel .brush-small:active,
      #optionPanel .brush-select-panel .brush-small:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAALhJREFUeNpi/P//P8NgBkwMgxyMOnDUgaMOHHXgqANHHTjqwFEHDm0HslBqAB+jGIhSBeIOIHaBCu8B4gogvv3p/yuKzGektMEKdKA6kDoBxAJoUh+A2ALowJsDHcVtWBzHABVro9RwaoTgRxCFQ/oLMAR5R3MxAbAHj9yuweDAamiGYMCSSaoHgwNvgHIrEK8D4s9QvA4qdmPAM8loVTfqwFEHjjpw1IGjDhx14KgDRx04pB0IEGAAHeMoHW2kl/cAAAAASUVORK5CYII=")
      }

      #optionPanel .brush-select-panel .brush-medium {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAS9JREFUeNrs2EsLgkAQB/BWupQQHXpczbp36/EB6ptH1M2D17RLhx6XQG9lszCBxEa5zoTQDPxvjv52RR1UWZbVqlxOreIlQAEKUID/Dqx/e2BL9d4t0MP0IS7kBkkgZ0iMub82XrMjLdBQGjXTdgO6jRlpC2QDiX51ixVkClkacMbNhyywR/0COIGMLfrG2MsK9C1xeaTPBdTHzgkezHmR6zoFd88lAOpzDDmAHuHrzeMA9giBXQ5ggxDY5ADeq/4tTgmvm3IAL4TAEwcwJgTGHMAdTillK8FzsTwkawLgGkcylm+xXnlQAhcU2T3baWYLCS36QuzlmahzpX/mrCAHnPE+zYRXhO1strzMRK0n5D0OEQNIJzdMPEf+CGHWL3klf7cEKEABClCApeohwADD8zb9WRTsHgAAAABJRU5ErkJggg==");
         background-size: cover
      }

      #optionPanel .brush-select-panel .brush-medium-active,
      #optionPanel .brush-select-panel .brush-medium:active,
      #optionPanel .brush-select-panel .brush-medium:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAU9JREFUeNpi/P//P8NgBkwMgxyMOnDUgaMOHHXgSHcgC7EK+RjFsAmzAXEAFFsCsRQQ/wLiJ0B8HojXA/FGqBgK+PT/FVH2MhJb1WFxYCAQdwGxCgGtd4C4HIjXkeNAcqKYGYg7oRaqEKEepGYtVA8zzaIYCbQBcRkZ+mB6ymmZSULIdByyI0NI0UBKGgRliLtALENhxnwKxErANPiL2iEYSgXHgYA0EIfRIooDqFi8BdDCgaZUdKAJLRwoQUUHStLCgb8YBgCQ4sDnVLT3OS0ceImKDjxDCwduoKIDN9DCgauhrRRKwVOoWTTJJEVUcGAhEP+kVV0M8nk3BY7rJiX0yG1uVQLxFDL0TYXqpXmT/y8Q50JbJXeIUH8HWo/nQPWSBChpUcOa/KHQ1rUxtCEAywhnoU3+1XRp8o/26kYdOOrAUQeOOnDUgVgBQIABAPYuSgtJpajwAAAAAElFTkSuQmCC")
      }

      #optionPanel .brush-select-panel .brush-big {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAaNJREFUeNrcmMFKw0AQhpOqRdGUCloD2lMv1T6B6RMI4sOK4BM0b1Clh56skFahpVaUaln/wBQkzKYmTbJTB75TSPJlN7uzM7ZSypIc9sYIVuxa0nsdUAcuqIIDUKZrczADExCAJ/CW5OFTNUolaIMGaIGThB80BF3QByoPwVPQptFaJ8JR7YDnrAS3gAfOM/69HoEPFusI7oIrcJzTGngB9+AzjWAod5PBlP5lym+jkqsEt8E1qBW0m4Q2d+A7KljS3OAVKGfRuzzuQkmzWpsG9uQmvTtW0KatxFS0yUEr2ChgUcRFlRy0ghcC0m9LJ+hQXjUdYQqtcIJ1QYeYM07QFSTocoKHggSrnOC+IEGHEywLEtyJyySi4rfgXJDXFyf4LkhwxgmOBQmOOcFAkGDACQ4ECQ44wamQURySC7vNPAgQ7MYdt/pUxJiKCTloBRUV1abCj3YduEwSVvw9A3I9bqHqUl2HSsGiYqSbuY0t3JexR62Po5zkXqn18ZG2N7PsMlxaQptH0TrBs7Jpv/mrMte/bGByx/LiWsBSQ7zgjwADAPqYqQ1c9nN+AAAAAElFTkSuQmCC");
         background-size: cover
      }

      #optionPanel .brush-select-panel .brush-big-active,
      #optionPanel .brush-select-panel .brush-big:active,
      #optionPanel .brush-select-panel .brush-big:hover {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAhRJREFUeNrUmLtPAkEQh+/UghCxw06JNuCjJURBK+OjsNVEW4KF6P+iYKGF9rYWhmClKKGg8wGNRu2kA4M25PyNGRKFPb0Fjlsm+SKG3MyXLLezs7phGJrK0acpHgP1D0P6sOyzY2AJRMAE8AEPf1cBz+ABZEAKPMkkLxtv33/1+hJbFOwHayAOZuh5i/WoSBYkwSmo2SG4ABIg0OaqFcAOuLAiaOU36AKHIN0BOY1zpDmnq92XxAsuQcyG33+Mc3tbFaQHr0DQxpc0yDW8soJucAb8XdhJ/FzLLSO4B0Jd3O5CXNOSIL2tUQf25CjX/lOQ/t93sHEkeK81FVznruBUBLgRmApuK9B+42aC1FtnFRCkFjouElyW6K12hs6HkCbBsEKnrLBIcEohwUmR4IhCgj6RoEchwcGeOfL/FKwo5PUuEnxVSPBFJHivkOCdSDCjkOC1SDDF05fTYbBLk+AjuFFAMMsuwm3mQAHB5K/G3DAX02HxtkPjZasz8zQN9mZzcY2Haqdit/HWQdRJaOI/cUDumAd6S1MdnWpzXZTLma2cmWAVrIJiF+SKXKsqe7NQAvMgb6NcnmuUWrn6oKBXaQ4c2SBHOSNcQ2tVkOIDbIHFDi15kXNRzk+Z49Z/keaxYIN3e9m2SM9sco605QlK8oZVaxhTV3iZaGMfpTT8XZmPTAU+hJxr7V4B98KJWsn4EmAAKPJ2SXt/mW0AAAAASUVORK5CYII=")
      }

      #optionPanel .right-panel {
         align-items: center;
         display: flex;
         float: left;
         margin-left: 39px
      }

      #optionPanel .right-panel .color-panel {
         background: #fff;
         border: 1px solid #e5e6e5;
         border-radius: 5px;
         display: flex;
         flex-wrap: wrap;
         justify-content: center;
         position: absolute;
         right: 28px;
         top: -225px;
         width: 72px
      }

      #optionPanel .right-panel .color-panel .color-item {
         height: 20px;
         margin-bottom: 5px;
         width: 62px
      }

      #optionPanel .right-panel .color-panel .color-item:first-child {
         background: #f53440;
         margin-top: 5px
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(2) {
         background: #f65e95
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(3) {
         background: #d254cf
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(4) {
         background: #12a9d7
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(5) {
         background: #30a345
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(6) {
         background: #facf50
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(7) {
         background: #f66632
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(8) {
         background: #989998
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(9) {
         background: #000
      }

      #optionPanel .right-panel .color-panel .color-item:nth-child(10) {
         background: #feffff;
         border: 1px solid #e5e6e5
      }

      #optionPanel .right-panel .color-select-panel {
         background: #f53340;
         border: 1px solid #e5e6e5;
         height: 20px;
         width: 62px
      }

      #optionPanel .right-panel .pull-down-arrow {
         background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAQCAYAAAABOs/SAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAANNJREFUeNq01TEKwjAUxvHXOAhKJ3Fwc9PVzbWipxCdHLyMV9AD6A2EegRdvYBOnd3E70ELIcT2JU0C/1BI4AeB8pKUhlMiOqAtKijuGqEj2ne61D/jY1V2QZ+IaI7maKywrdETzdAVDSKi/Lp3tGP4hRYRcRPlly1Uech4FgG3onygtEvvwDijNxtqwiHxCp3YUBscAm9E/8FtcBFaB/vgYrQJdsGdUAkswZ1RKVyH6+hDivJKMCTa/CY9DV26DBlX2MTJB/WFK/yEvmjjM05/AgwANuZSRB8r5twAAAAASUVORK5CYII=");
         background-size: cover;
         height: 8px;
         margin-left: 10px;
         width: 15px
      }

      #cutBoxSizePanel {
         align-items: center;
         background: rgba(0, 0, 0, .4);
         border-radius: 3px;
         color: #fff;
         display: flex;
         font-size: 14px;
         height: 25px;
         justify-content: center;
         width: 85px
      }

      #cutBoxSizePanel,
      #textInputPanel {
         left: 0;
         position: absolute;
         top: 0;
         z-index: 9999
      }

      #textInputPanel {
         border: none;
         box-sizing: border-box;
         font-weight: 700;
         margin: 0;
         min-height: 20px;
         min-width: 20px;
         outline: none;
         padding: 0
      }

      .hidden-screen-shot-scroll {
         height: 100vh;
         overflow: hidden;
         width: 100vw
      }
   </style>
   <style id="svelte-trnmqx">
      .bookly-calendar-overlay.svelte-trnmqx {
         position: absolute;
         width: 100%;
         height: 100%;
         top: 0;
         left: 0;
         right: 0;
         bottom: 0;
         background-color: rgba(255, 255, 255, 0.9);
         z-index: 2;
         cursor: wait
      }
   </style>
</head>