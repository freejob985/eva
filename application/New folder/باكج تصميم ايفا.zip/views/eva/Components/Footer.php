         <!-- mfn_hook_content_after --><!-- mfn_hook_content_after -->
         <footer id="Footer" class="clearfix mfn-footer " role="contentinfo">
            <div class="widgets_wrapper ">
               <div class="container">
                  <div class="column mobile-one tablet-one-fourth one-fourth">
                     <div class="mcb-column-inner">
                        <aside id="text-2" class="widget widget_text">
                           <div class="textwidget">
                              <p><a href="https://evaclinics.com.sa//">الرئيسية</a></p>
                              <p><a href="https://evaclinics.com.sa//about-us/">عن ايفا</a></p>
                              <p><a
                                 href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%a3%d9%82%d8%b3%d8%a7%d9%85-%d9%88%d8%a7%d9%84%d8%ae%d8%af%d9%85%d8%a7%d8%aa/">الأقسام
                                 والخدمات</a>
                              </p>
                              <p><a
                                 href="https://evaclinics.com.sa/%d8%a7%d9%84%d8%a3%d8%b7%d8%a8%d8%a7%d8%a1/">الأطباء</a>
                              </p>
                              <p><a
                                 href="https://evaclinics.com.sa/%d8%a7%d9%84%d9%81%d8%b1%d9%88%d8%b9-2/">الفروع</a>
                              </p>
                           </div>
                        </aside>
                     </div>
                  </div>
                  <div class="column mobile-one tablet-one-fourth one-fourth">
                     <div class="mcb-column-inner">
                        <aside id="text-3" class="widget widget_text">
                           <div class="textwidget">
                              <p>البوم الصور</p>
                              <p><a href="https://evaclinics.com.sa/shop/">المتجر</a></p>
                              <p>شركاء النجاح</p>
                              <p><a href="https://evaclinics.com.sa/%d8%a7%d8%aa%d8%b5%d9%84-%d8%a8%d9%86%d8%a7/">اتصل
                                 بنا</a>
                              </p>
                           </div>
                        </aside>
                     </div>
                  </div>
                  <div class="column mobile-one tablet-one-fourth one-fourth">
                     <div class="mcb-column-inner">
                        <aside id="text-7" class="widget widget_text">
                           <h4>سجل ليصلك كل جديد</h4>
                           <div class="textwidget">
                              <p>
                                 <!-- Noptin Newsletter Plugin v3.4.10 - https://wordpress.org/plugins/newsletter-optin-box/ -->
                              </p>
                              <form id="noptin-form-1"
                                 class="noptin-newsletter-form noptin-form noptin-form-1 noptin-form-source-374 noptin-label-hide noptin-styles-basic noptin-template-normal"
                                 method="post" novalidate="" data-id="1">
                                 <div class="noptin-form-fields">
                                    <div id="noptin-form-1__email--wrapper"
                                       class="noptin-form-field-wrapper noptin-form-field-email">
                                       <p> <label class="noptin-label" for="noptin-form-1__field-email">Email
                                          Address</label><br>
                                          <input name="noptin_fields[email]" id="noptin-form-1__field-email"
                                             type="email" value=""
                                             class="noptin-text noptin-form-field noptin-form-field__has-no-placeholder"
                                             placeholder="Email Address" required="">
                                       </p>
                                    </div>
                                    <div id="noptin-form-1__submit--wrapper"
                                       class="noptin-form-field-wrapper noptin-form-field-submit">
                                       <p> <button type="submit" id="noptin-form-1__submit"
                                          class="noptin-form-submit btn button btn-primary button-primary wp-element-button"
                                          name="noptin-submit">سجل الان</button></p>
                                    </div>
                                 </div>
                                 <p><input type="hidden" name="noptin_nonce" value="b6a566a291"><input
                                    type="hidden" name="conversion_page"
                                    value="https://evaclinics.com.sa/about-us/"><input type="hidden"
                                    name="action" value="noptin_process_ajax_subscriber"><input
                                    type="hidden" name="noptin_process_request" value="1"><input
                                    type="hidden" name="noptin_timestamp" value="1723083376"><input
                                    type="hidden" name="noptin_element_id" value="1"><input type="hidden"
                                    name="noptin_unique_id"
                                    value="noptin_frm_3938c4b9ed232ca3ac95a516c929af1e"><input type="hidden"
                                    name="source" value="374"><input type="hidden" name="form_action"
                                    value="subscribe"> <label style="display: none !important;">Leave this
                                    field empty if you’re not a robot: <input type="text" name="noptin_ign"
                                       value="" tabindex="-1" autocomplete="off"></label>
                                 </p>
                                 <div class="noptin-form-notice noptin-response" role="alert"></div>
                                 <div class="noptin-loader"><span></span></div>
                              </form>
                              <p>
                                 <!-- / Noptin Newsletter Plugin -->
                              </p>
                           </div>
                        </aside>
                     </div>
                  </div>
                  <div class="column mobile-one tablet-one-fourth one-fourth">
                     <div class="mcb-column-inner">
                        <aside id="text-6" class="widget widget_text">
                           <div class="textwidget">
                              <p><img decoding="async" class="wp-image-240 aligncenter"
                                 src="./عن ايفا – EVA_files/eva2(1).png" alt="" width="195"
                                 srcset="https://evaclinics.com.sa/wp-content/uploads/2024/07/eva2.png 323w, https://evaclinics.com.sa/wp-content/uploads/2024/07/eva2-300x214.png 300w, https://evaclinics.com.sa/wp-content/uploads/2024/07/eva2-105x75.png 105w"
                                 sizes="(max-width:767px) 323px, 323px"></p>
                              <h4 style="text-align: center;">920024041</h4>
                           </div>
                        </aside>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer_copy">
               <div class="container">
                  <div class="column one mobile-one">
                     <div class="mcb-column-inner">
                        <a id="back_to_top" class="footer_button" href="https://evaclinics.com.sa/about-us/"
                           aria-label="Back to top icon"><i class="icon-up-open-big"></i></a>
                        <div class="copyright">
                           All Rights Reserved 
                        </div>
                        <ul class="social">
                           <li class="facebook"><a href="https://www.facebook.com/EvaClinicssa" title="Facebook"
                              aria-label="Facebook icon"><i class="icon-facebook"></i></a></li>
                           <li class="twitter"><a href="https://evaclinics.com.sa/about-us/#" title="X (Twitter)"
                              aria-label="X (Twitter) icon"><i class="icon-x-twitter"></i></a></li>
                           <li class="youtube"><a href="http://www.youtube.com/@evaclinicssa" title="YouTube"
                              aria-label="YouTube icon"><i class="icon-play"></i></a></li>
                           <li class="instagram"><a href="https://www.instagram.com/evaclinics.sa"
                              title="Instagram" aria-label="Instagram icon"><i class="icon-instagram"></i></a>
                           </li>
                           <li class="snapchat"><a href="https://snapchat.com/t/VniZXXoE" title="Snapchat"
                              aria-label="Snapchat icon"><i class="icon-snapchat"></i></a></li>
                           <li class="tiktok"><a href="https://www.tiktok.com/@evaclinics" title="TikTok"
                              aria-label="TikTok icon"><i class="icon-tiktok"></i></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
         <!-- End Footer Template -->
      </div>
      <div id="body_overlay"></div>
      <div id="Side_slide" class="left dark" data-width="250" aria-expanded="false" role="banner"
         aria-label="responsive menu">
         <div class="close-wrapper"><a href="https://evaclinics.com.sa/about-us/#" aria-label="menu close icon"
            class="close"><i class="icon-cancel-fine"></i></a></div>
         <div class="extras">
            <div class="extras-wrapper" role="navigation" aria-label="extras menu">
               <a
                  class="top-bar-right-icon myaccount_button top-bar-right-icon-user toggle-login-modal logged-out"
                  href="https://evaclinics.com.sa/my-account/">
                  <svg width="26" viewBox="0 0 26 26"
                     aria-label="user icon">
                     <defs>
                        <style>
                           .path {
                           fill: none;
                           stroke: #333333;
                           stroke-width: 1.5px;
                           }
                        </style>
                     </defs>
                     <circle class="path" cx="13" cy="9.7" r="4.1"></circle>
                     <path class="path"
                        d="M19.51,18.1v2.31h-13V18.1c0-2.37,2.92-4.3,6.51-4.3S19.51,15.73,19.51,18.1Z"></path>
                  </svg>
               </a>
            </div>
         </div>
         <div class="lang-wrapper" role="navigation" aria-label="language menu"></div>
         <div class="menu_wrapper" role="navigation" aria-label="main menu"></div>
         <ul class="social">
            <li class="facebook"><a href="https://www.facebook.com/EvaClinicssa" title="Facebook"
               aria-label="Facebook icon"><i class="icon-facebook"></i></a></li>
            <li class="twitter"><a href="https://evaclinics.com.sa/about-us/#" title="X (Twitter)"
               aria-label="X (Twitter) icon"><i class="icon-x-twitter"></i></a></li>
            <li class="youtube"><a href="http://www.youtube.com/@evaclinicssa" title="YouTube"
               aria-label="YouTube icon"><i class="icon-play"></i></a></li>
            <li class="instagram"><a href="https://www.instagram.com/evaclinics.sa" title="Instagram"
               aria-label="Instagram icon"><i class="icon-instagram"></i></a></li>
            <li class="snapchat"><a href="https://snapchat.com/t/VniZXXoE" title="Snapchat"
               aria-label="Snapchat icon"><i class="icon-snapchat"></i></a></li>
            <li class="tiktok"><a href="https://www.tiktok.com/@evaclinics" title="TikTok" aria-label="TikTok icon"><i
               class="icon-tiktok"></i></a></li>
         </ul>
      </div>

